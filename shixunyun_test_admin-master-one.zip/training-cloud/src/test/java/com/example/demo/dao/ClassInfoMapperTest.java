package com.example.demo.dao;

import com.example.demo.po.ClassInfo;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import javax.annotation.Resource;

@SpringBootTest
public class ClassInfoMapperTest {

    @Resource
    ClassInfoMapper classInfoMapper;

    @Test
    public void addClass() {
 /*         `relation_teacher_id` int DEFAULT NULL COMMENT '关联教师表id',
  `class_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '班级名称',
  `practice_title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '实训标题',
  `practice_content` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '实训内容',
  `counselor` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '辅导员名称',
  `counselor_telephone` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '辅导员电话'*/
        ClassInfo classInfo = new ClassInfo();
        classInfo.setRelationTeacherId(1);
        classInfo.setClassName("软件工程3");
        classInfo.setPracticeTitle("软件工程实训3");
        classInfo.setPracticeContent("软件工程实训内容");
        classInfo.setCounselor("张三");
        classInfo.setCounselorTelephone("123456789");
        classInfoMapper.insert(classInfo);
    }
}
