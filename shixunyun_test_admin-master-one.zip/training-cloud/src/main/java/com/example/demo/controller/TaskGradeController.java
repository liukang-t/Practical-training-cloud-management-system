package com.example.demo.controller;


import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import com.example.demo.beans.CommonResult;
import com.example.demo.service.TaskGradeService;
import com.example.demo.vo.TaskGradeVo;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

/**
 * <p>
 * 任务评分表 前端控制器
 * </p>
 *
 * @author hc1204
 * @since 2023-11-27
 */
@RestController
@RequestMapping("/taskGrade")
public class TaskGradeController {

    @Resource
    TaskGradeService taskGradeService;


    @GetMapping("/getTaskScoreList")
    public CommonResult getTaskScoreList(HttpServletRequest request, TaskGradeVo taskGradeVo) {
        //参数校验
        if (ObjectUtil.isNull(taskGradeVo)) {
            return CommonResult.error("参数不能为空");
        }
        if (ObjectUtil.isNull(taskGradeVo.getTaskId())) {
            return CommonResult.error("任务id不能为空");
        }
        if (ObjectUtil.isNull(taskGradeVo.getPage()) || taskGradeVo.getPage() < 1) {
            return CommonResult.error("页码不能为空");
        }
        if (ObjectUtil.isNull(taskGradeVo.getSize()) || taskGradeVo.getSize() < 1){
            return CommonResult.error("每页条数不能为空");
        }
        return taskGradeService.getTaskScoreList(request,taskGradeVo);
    }

    @PostMapping("/modifyTaskScore")
    public CommonResult modifyTaskScore(HttpServletRequest request,@RequestBody TaskGradeVo taskGradeVo){
        //参数校验
        if (ObjectUtil.isNull(taskGradeVo)){
            return CommonResult.error("参数不能为空");
        }
        if (ObjectUtil.isNull(taskGradeVo.getTaskId())){
            return CommonResult.error("任务id不能为空");
        }
        if (ObjectUtil.isNull(taskGradeVo.getStudentId())){
            return CommonResult.error("学生id不能为空");
        }
        if (StrUtil.isBlank(taskGradeVo.getScore())){
            return CommonResult.error("任务分数不能为空");
        }
        //业务逻辑
        return taskGradeService.modifyTaskScore(request,taskGradeVo);
    }
}

