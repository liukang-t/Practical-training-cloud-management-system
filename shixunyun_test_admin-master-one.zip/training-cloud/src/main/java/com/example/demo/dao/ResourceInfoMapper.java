package com.example.demo.dao;

import com.example.demo.po.ResourceInfo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 资源表 Mapper 接口
 * </p>
 *
 * @author mp
 * @since 2023-11-17
 */
public interface ResourceInfoMapper extends BaseMapper<ResourceInfo> {

}
