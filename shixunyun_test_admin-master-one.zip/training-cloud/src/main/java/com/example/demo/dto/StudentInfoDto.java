package com.example.demo.dto;

import com.example.demo.po.StudentInfo;
import lombok.Data;

@Data
public class StudentInfoDto extends StudentInfo {

    /**
     * 班级名称
     */
    private String className;

    /**
     * 学校名称
     */
    private String schoolName;

    /**
     * 院系名称
     */
    private String departmentName;
}
