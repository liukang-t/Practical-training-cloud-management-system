package com.example.demo.dto;

import com.example.demo.po.DiscussComment;
import com.example.demo.po.DiscussInfo;
import lombok.Data;

import java.util.List;

@Data
public class DiscussInfoDto extends DiscussInfo {

    private List<DiscussComment> children;
}
