package com.example.demo.config;

import cn.hutool.json.JSONObject;
import com.example.demo.dto.UserInfoDto;
import com.example.demo.utils.SessionUtil;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * 登录拦截器
 */
public class LoginInterceptor implements HandlerInterceptor {

    /**
     * 前置方法,在请求进入时,进行拦截,进行登录状态的判断
     * @param request
     * @param response
     * @param handler
     * @return
     * @throws Exception
     */
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
       //从请求中获取token
        String token = SessionUtil.getTokenFromRequest(request);
        //判断token是否为空 或空字符串
        if (token == null || token.trim() == ""){
            this.returnFalseMsg(response,"用户未登录",request);
            return false;
        }
        //判断session中的用户信息
        UserInfoDto userInfoDto = SessionUtil.getUserFromSession(request);
        if (userInfoDto == null){
            this.returnFalseMsg(response,"用户未登录",request);
            return false;
        }
        return true;
    }

    private void returnFalseMsg(HttpServletResponse response,String msg,HttpServletRequest request) throws IOException {
        //设置响应的状态 200 请求成功
        response.setStatus(200);
        //设置响应的数据类型
        response.setContentType("application/json;charset=utf-8");
        //获取响应的输出流
        PrintWriter writer = response.getWriter();
        //构建json对象
        JSONObject jsonObject = new JSONObject();
        //http状态码 401 未登录
        jsonObject.put("code",401);
        //响应的信息
        jsonObject.put("msg",msg);
        //请求的路径
        jsonObject.put("uri",request.getRequestURI());
        jsonObject.put("url",request.getRequestURL());
        //把对象放进输出流
        writer.println(jsonObject);
        //刷新
        writer.flush();
        //关闭输出流
        writer.close();
    }
}
