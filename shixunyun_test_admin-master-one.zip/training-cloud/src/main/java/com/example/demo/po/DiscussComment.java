package com.example.demo.po;

import com.baomidou.mybatisplus.annotation.*;

import java.util.Date;
import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 评论表
 * </p>
 *
 * @author mp
 * @since 2023-12-04
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class DiscussComment implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 评论id
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 关联讨论id
     */
    @TableField("relation_discuss_id")
    private Integer relationDiscussId;

    /**
     * 评论内容
     */
    @TableField("content")
    private String content;

    /**
     * 图片地址（多个以英文逗号分隔）
     */
    @TableField("img_url")
    private String imgUrl;

    /**
     * 回复的id
     */
    @TableField("reply_id")
    private Integer replyId;

    /**
     * 回复的人的id
     */
    @TableField("reply_people_id")
    private Integer replyPeopleId;

    /**
     * 回复的人的姓名
     */
    @TableField("user_parent_nick")
    private String userParentNick;

    /**
     * 回复的评论内容
     */
    @TableField("user_parent_content")
    private String userParentContent;

    /**
     * 创建人
     */
    @TableField("create_by")
    private Integer createBy;

    /**
     * 创建人姓名
     */
    @TableField("create_by_name")
    private String createByName;

    /**
     * 创建时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    @TableField(value = "create_time", fill = FieldFill.INSERT)
    private Date createTime;

    /**
     * 更新时间
     */
    @TableField(value = "update_time", fill = FieldFill.UPDATE)
    private Date updateTime;

    /**
     * 点赞数
     */
    @TableField("like_num")
    private Integer likeNum;

    /**
     * 头像
     */
    @TableField("user_avatar")
    private String userAvatar;

    /**
     * 逻辑删除：0=未删除，1=删除
     */
    @TableLogic
    @TableField(value = "deleted",fill = FieldFill.INSERT)
    private Integer deleted;


}
