package com.example.demo.controller;


import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.http.server.HttpServerRequest;
import com.example.demo.beans.CommonResult;
import com.example.demo.dto.UserInfoDto;
import com.example.demo.service.UserInfoService;
import com.example.demo.utils.SessionUtil;
import com.example.demo.utils.UploadFileUtil;
import com.example.demo.vo.UserInfoVo;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

/**
 * <p>
 * 用户表 前端控制器
 * </p>
 *
 * @author mp
 * @since 2023-10-25
 */
@RestController
@RequestMapping("/userInfo")
public class UserInfoController {

    @Resource
    private UserInfoService userInfoService;

    @PostMapping("/register")
    public CommonResult register(HttpServerRequest request, @RequestBody UserInfoVo userInfoVo) {
        //返回结果
        CommonResult result = null;
        //校验参数 ==
        if (ObjectUtil.isNull(userInfoVo)) {
            return CommonResult.error("参数不能为空");
        }
        if (StrUtil.isBlank(userInfoVo.getTeacherName())) {
            return CommonResult.error("用户名称不能为空");
        }
        if (StrUtil.isBlank(userInfoVo.getPassword())) {
            return CommonResult.error("用户密码不能为空");
        }
        if (StrUtil.isBlank(userInfoVo.getAccountNum())) {
            return CommonResult.error("用户账号不能为空");
        }
        try {
            result = userInfoService.register(request, userInfoVo);
        } catch (Exception e) {
            return CommonResult.error("注册失败");
        }
        return result;
    }

    @PostMapping("/login")
    public CommonResult login(HttpServletRequest request, @RequestBody UserInfoVo userInfoVo) {
        //校验参数
        if (ObjectUtil.isNull(userInfoVo)) {
            return CommonResult.error("参数不能为空");
        }
        if (StrUtil.isBlank(userInfoVo.getPassword())) {
            return CommonResult.error("用户密码不能为空");
        }
        if (StrUtil.isBlank(userInfoVo.getAccountNum())) {
            return CommonResult.error("用户账号不能为空");
        }
        return userInfoService.login(request, userInfoVo);
    }

    /**
     * 从用户请求的session中获取用户信息
     * @param request
     * @return
     */
    @GetMapping("/getUserByToken")
    public CommonResult getUserByToken(HttpServletRequest request){
        UserInfoDto userInfoDto = SessionUtil.getUserFromSession(request);
        String userAva = userInfoDto.getUserAva();
        //拼接头像路径 拼接上下载文件的请求接口
        String downloadUrl = UploadFileUtil.getDownloadUrl(userAva, "8084");
        userInfoDto.setUserAva(downloadUrl);
        return CommonResult.success("获取用户信息成功",userInfoDto);
    }

    @PostMapping("/logout")
    public CommonResult logout(HttpServletRequest request){
        //从请求中获取token
        String token = SessionUtil.getTokenFromRequest(request);
        //从请求中获取session
        HttpSession session = request.getSession();
        //在session移除缓存信息
        session.removeAttribute(token);
        //返回成功结果
        return CommonResult.success("退出成功");
    }

    @PostMapping("/changePassword")
    public CommonResult changePassword(HttpServletRequest request,@RequestBody UserInfoVo userInfoVo){
        //参数校验
        if (userInfoVo == null){
            return CommonResult.error("参数不能为空");
        }
        //判断密码是否为空 或 空字符串 使用trim去掉String头尾的空格
        if (userInfoVo.getNewPassword() == null || userInfoVo.getNewPassword().trim() == ""){
            return CommonResult.error("新密码不能为空");
        }
        if (userInfoVo.getOldPassword() == null || userInfoVo.getOldPassword().trim() == ""){
            return CommonResult.error("旧密码不能为空");
        }
        return userInfoService.changePassword(request,userInfoVo);
    }

    @PostMapping("/changeAvatar")
    public CommonResult changeAvatar(HttpServletRequest request,@RequestBody UserInfoVo userInfoVo){
        //参数校验
        if (ObjectUtil.isNull(userInfoVo)){
            return CommonResult.error("参数不能为空");
        }
        if (StrUtil.isBlank(userInfoVo.getAvatar())){
            return CommonResult.error("头像不能为空");
        }
        return userInfoService.changeAvatar(request,userInfoVo);
    }

    @PostMapping("/changeUserInfo")
    public CommonResult changeUserInfo(HttpServletRequest request,@RequestBody UserInfoVo userInfoVo){
        //参数校验
        if (ObjectUtil.isNull(userInfoVo)){
            return CommonResult.error("参数不能为空");
        }
        if (StrUtil.isBlank(userInfoVo.getNick())){
            return CommonResult.error("用户昵称不能为空");
        }
        if (ObjectUtil.isNull(userInfoVo.getGender())){
            return CommonResult.error("用户性别不能为空");
        }
        return userInfoService.changeUserInfo(request,userInfoVo);
    }
}

