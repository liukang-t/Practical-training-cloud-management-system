package com.example.demo.controller;


import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import com.example.demo.beans.CommonResult;
import com.example.demo.service.StudentInfoService;
import com.example.demo.vo.StudentInfoVo;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

/**
 * <p>
 * 学生 前端控制器
 * </p>
 *
 * @author mp
 * @since 2023-10-25
 */
@RestController
@RequestMapping("/studentInfo")
public class StudentInfoController {

    @Resource
    StudentInfoService studentInfoService;

    @PostMapping("/addStudent")
    public CommonResult addStudent(HttpServletRequest request, @RequestBody StudentInfoVo studentInfoVo) {
        CommonResult result = null;
        if (ObjectUtil.isNull(studentInfoVo)) {
            return CommonResult.error("参数不能为空");
        }
        if (StrUtil.isBlank(studentInfoVo.getStudentNumber())) {
            return CommonResult.error("学号不能为空");
        }
        if (StrUtil.isBlank(studentInfoVo.getStudentName())) {
            return CommonResult.error("学生姓名不能为空");
        }
        if (ObjectUtil.isNull(studentInfoVo.getRelationClassId())) {
            return CommonResult.error("关联的班级id不能为空");
        }
        try {
            result = studentInfoService.addStudent(request, studentInfoVo);
        } catch (Exception e) {
            CommonResult.error("插入学生信息失败");
        }
        return result;
    }

    @GetMapping("/getStudentList")
    public CommonResult getStudentList(HttpServletRequest request, StudentInfoVo studentInfoVo) {
        if (ObjectUtil.isNull(studentInfoVo)) {
            return CommonResult.error("参数不能为空");
        }
        if (ObjectUtil.isNull(studentInfoVo.getPage()) || studentInfoVo.getPage() <= 0) {
            return CommonResult.error("页码不能为空");
        }
        if (ObjectUtil.isNull(studentInfoVo.getSize()) || studentInfoVo.getSize() <= 0) {
            return CommonResult.error("页面查询条数不能为空");
        }
        return studentInfoService.selectStudentList(request, studentInfoVo);
    }

    @PostMapping("/modifyStudent")
    public CommonResult modifyStudent(HttpServletRequest request, @RequestBody StudentInfoVo studentInfoVo) {
        CommonResult result = null;
        if (ObjectUtil.isNull(studentInfoVo)) {
            return CommonResult.error("参数不能为空");
        }
        if (ObjectUtil.isNull(studentInfoVo.getId())) {
            return CommonResult.error("id不能为空");
        }
        if (StrUtil.isBlank(studentInfoVo.getStudentName())) {
            return CommonResult.error("学生姓名不能为空");
        }
        if (StrUtil.isBlank(studentInfoVo.getStudentNumber())) {
            return CommonResult.error("学号不能为空");
        }
        if (ObjectUtil.isNull(studentInfoVo.getRelationClassId())) {
            return CommonResult.error("关联的班级id不能为空");
        }
        try {
            result = studentInfoService.modifyStudent(request, studentInfoVo);
        } catch (Exception e) {
            return CommonResult.error("更新学生信息失败");
        }
        return result;
    }

    @PostMapping("/deleteStudent")
    public CommonResult deleteStudent(HttpServletRequest request, @RequestBody StudentInfoVo studentInfoVo) {
        CommonResult result = null;
        //校验参数
        if (ObjectUtil.isNull(studentInfoVo)) {
            return CommonResult.error("参数不能为空");
        }
        if (studentInfoVo.getIdList() == null || studentInfoVo.getIdList().size() <= 0) {
            return CommonResult.error("id列表不能为空");
        }
        try {
            result = studentInfoService.deleteStudent(request, studentInfoVo);
        } catch (Exception e) {
            return CommonResult.error("删除学生信息失败");
        }
        return result;
    }
}

