package com.example.demo.service;

import com.example.demo.beans.CommonResult;
import com.example.demo.po.DiscussInfo;
import com.baomidou.mybatisplus.extension.service.IService;
import com.example.demo.vo.DiscussInfoVo;

import javax.servlet.http.HttpServletRequest;

/**
 * <p>
 * 讨论表 服务类
 * </p>
 *
 * @author hc1204
 * @since 2023-12-04
 */
public interface DiscussInfoService extends IService<DiscussInfo> {

    CommonResult addDiscuss(HttpServletRequest request, DiscussInfoVo discussInfoVo);

    CommonResult getDiscussList(HttpServletRequest request, DiscussInfoVo discussInfoVo);

    CommonResult deleteDiscuss(HttpServletRequest request, DiscussInfoVo discussInfoVo) throws Exception;
}
