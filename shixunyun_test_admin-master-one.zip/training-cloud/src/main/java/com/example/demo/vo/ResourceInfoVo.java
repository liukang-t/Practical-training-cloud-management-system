package com.example.demo.vo;

import lombok.Data;

import java.util.List;

@Data
public class ResourceInfoVo extends BaseVo {


    /**
     * 资源名称
     */
    private String resourceName;

    /**
     * 资源链接
     */
    private String resourceUrl;

    /**
     * 关联班级id
     */
    private Integer relationClassId;

    /**
     * 资源详情
     */
    private String resourceDescription;


    private List<Integer> idList;
}
