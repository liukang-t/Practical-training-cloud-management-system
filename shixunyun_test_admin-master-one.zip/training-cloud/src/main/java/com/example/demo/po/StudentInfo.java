package com.example.demo.po;

import com.baomidou.mybatisplus.annotation.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 学生
 * </p>
 *
 * @author mp
 * @since 2023-10-25
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class StudentInfo implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 编号
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 创建人
     */
    @TableField("create_by")
    private Integer createBy;

    /**
     * 创建时间
     */
    @TableField(value = "create_time", fill = FieldFill.INSERT)
    private Date createTime;

    /**
     * 更新人
     */
    @TableField("update_by")
    private Integer updateBy;

    /**
     * 更新时间
     */
    @TableField(value = "update_time", fill = FieldFill.UPDATE)
    private Date updateTime;

    /**
     * 学生姓名
     */
    @TableField("student_name")
    private String studentName;

    /**
     * 年龄
     */
    @TableField("age")
    private Integer age;

    /**
     * 出生日期 2023-11-07
     */
    @JsonFormat(pattern = "yyyy-MM-dd")
    @TableField("birth")
    private Date birth;

    /**
     * 学号
     */
    @TableField("student_number")
    private String studentNumber;

    /**
     * 用户表id
     */
    @TableField("relation_user_id")
    private Integer relationUserId;

    /**
     * 删除 0-未删除 1-已删除
     */
    @TableField(value = "deleted",fill = FieldFill.INSERT)
    private Integer deleted;

    /**
     * 性别 1-男 2-女
     */
    @TableField("gender")
    private Integer gender;

    /**
     * 关联班级id
     */
    @TableField("relation_class_id")
    private Integer relationClassId;


}
