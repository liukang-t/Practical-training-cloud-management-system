package com.example.demo.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.demo.beans.CommonResult;
import com.example.demo.dao.ClassInfoMapper;
import com.example.demo.dao.DiscussCommentMapper;
import com.example.demo.dto.DiscussInfoDto;
import com.example.demo.dto.UserInfoDto;
import com.example.demo.po.ClassInfo;
import com.example.demo.po.DiscussComment;
import com.example.demo.po.DiscussInfo;
import com.example.demo.dao.DiscussInfoMapper;
import com.example.demo.service.DiscussInfoService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.demo.utils.SessionUtil;
import com.example.demo.utils.UploadFileUtil;
import com.example.demo.vo.DiscussInfoVo;
import org.springframework.stereotype.Service;
import org.springframework.web.util.HtmlUtils;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * <p>
 * 讨论表 服务实现类
 * </p>
 *
 * @author hc1204
 * @since 2023-12-04
 */
@Service
public class DiscussInfoServiceImpl extends ServiceImpl<DiscussInfoMapper, DiscussInfo> implements DiscussInfoService {

    @Resource
    private ClassInfoMapper classInfoMapper;

    @Resource
    private DiscussCommentMapper discussCommentMapper;

    @Override
    public CommonResult addDiscuss(HttpServletRequest request, DiscussInfoVo discussInfoVo) {
        //获取登录用户的身份信息
        UserInfoDto userInfoDto = SessionUtil.getUserFromSession(request);
        //创建答疑对象
        DiscussInfo discussInfo = new DiscussInfo();
        //根据用户的身份类型，设置身份信息
        if (userInfoDto.getUserType().equals(1)) {
            //教师
            discussInfo.setRelationTeacherId(userInfoDto.getTeacherInfo().getId());
            if (ObjectUtil.isNotNull(discussInfoVo.getRelationClassId())) {
                ClassInfo classInfo = classInfoMapper.selectById(discussInfoVo.getRelationClassId());
                if (ObjectUtil.isNull(classInfo)) {
                    return CommonResult.error("班级不存在");
                }
                discussInfo.setRelationClassId(discussInfoVo.getRelationClassId());
            }
        } else {
            //学生
            ClassInfo classInfo = classInfoMapper.selectById(userInfoDto.getStudentInfo().getRelationClassId());
            if (ObjectUtil.isNull(classInfo)) {
                return CommonResult.error("班级信息不存在");
            }
            discussInfo.setRelationClassId(classInfo.getId());
            discussInfo.setRelationTeacherId(classInfo.getRelationTeacherId());
        }
        //设置内容,对富文本内容进行转义 <p> ->  &ltp&gt  -> <p>
        String htmlEscape = HtmlUtils.htmlEscape(discussInfoVo.getContent());
        discussInfo.setContent(htmlEscape);
        if (StrUtil.isNotBlank(discussInfoVo.getImgUrl())) {
            String filePath = UploadFileUtil.getFilePath(discussInfoVo.getImgUrl());
            discussInfo.setImgUrl(filePath);
        }
        //设置创建人的id
        discussInfo.setCreateBy(userInfoDto.getId());
        discussInfo.setCreateByName(userInfoDto.getNick());
        if (StrUtil.isNotBlank(userInfoDto.getUserAva())) {
            String filePath = UploadFileUtil.getFilePath(userInfoDto.getUserAva());
            discussInfo.setUserAvatar(filePath);
        }
        boolean save = this.save(discussInfo);
        return save ? CommonResult.success("发布答疑成功") : CommonResult.error("发布答疑失败");
    }

    @Override
    public CommonResult getDiscussList(HttpServletRequest request, DiscussInfoVo discussInfoVo) {
        //获取用户身份信息
        UserInfoDto userInfoDto = SessionUtil.getUserFromSession(request);
        //创建查询条件构造器
        LambdaQueryWrapper<DiscussInfo> queryWrapper = new LambdaQueryWrapper<>();
        if (userInfoDto.getUserType().equals(1)) {
            //教师
            queryWrapper.eq(DiscussInfo::getRelationTeacherId, userInfoDto.getTeacherInfo().getId());
            //如果前端有传关联的班级id，则设置为查询条件
            if (ObjectUtil.isNotNull(discussInfoVo.getRelationClassId())) {
                queryWrapper.eq(DiscussInfo::getRelationClassId, discussInfoVo.getRelationClassId());
            }
        } else {
            //学生
            queryWrapper.eq(DiscussInfo::getRelationClassId, userInfoDto.getStudentInfo().getRelationClassId());
        }
        //创建分页条件构造器，进行分页查询
        Page<DiscussInfo> discussInfoPage = new Page<>(discussInfoVo.getPage(), discussInfoVo.getSize());
        IPage<DiscussInfo> page = this.page(discussInfoPage, queryWrapper);
        //判断是否有数据，如果有数据，则进行数据处理
        List<DiscussInfo> records = page.getRecords();
        ArrayList<DiscussInfoDto> discussInfoDtos = new ArrayList<>();
        if (CollUtil.isNotEmpty(records)) {
            for (int i = 0; i < records.size(); i++) {
                DiscussInfo discussInfo = records.get(i);
                //查询当前这个元素的回复列表
                LambdaQueryWrapper<DiscussComment> discussCommentLambdaQueryWrapper = new LambdaQueryWrapper<DiscussComment>()
                        .eq(DiscussComment::getRelationDiscussId, discussInfo.getId());
                List<DiscussComment> discussComments = discussCommentMapper.selectList(discussCommentLambdaQueryWrapper);
                //判断回复列表是否为空,如果不为空，则对内容进行反转义  &ltp&gt -> <p>
                if (CollUtil.isNotEmpty(discussComments)) {
                    for (int j = 0; j < discussComments.size(); j++) {
                        DiscussComment discussComment = discussComments.get(j);
                        discussComment.setContent(HtmlUtils.htmlUnescape(discussComment.getContent()));
                        //当这条回复 的被回复内容不为空时，对内容的html标签进行转义
                        if (StrUtil.isNotBlank(discussComment.getUserParentContent())) {
                            discussComment.setUserParentContent(HtmlUtils.htmlUnescape(discussComment.getUserParentContent()));
                        }
                        //附件的下载路径转换
                        if (StrUtil.isNotBlank(discussComment.getImgUrl())) {
                            String downloadUrl = UploadFileUtil.getDownloadUrl(discussComment.getImgUrl(), "8084");
                            discussComment.setImgUrl(downloadUrl);
                        }
                        //图片的下载路径转换
                        if (StrUtil.isNotBlank(discussComment.getUserAvatar())) {
                            String downloadUrl = UploadFileUtil.getDownloadUrl(discussComment.getUserAvatar(), "8084");
                            discussComment.setUserAvatar(downloadUrl);
                        }
                    }
                }
                //创建dto对象，放置回复列表
                DiscussInfoDto discussInfoDto = new DiscussInfoDto();
                discussInfoDto.setChildren(discussComments);
                //使用beanUtil进行属性复制
                BeanUtil.copyProperties(discussInfo, discussInfoDto, "content");
                discussInfoDto.setContent(HtmlUtils.htmlUnescape(discussInfo.getContent()));
                //对附件 和 头像 的下载路径转换
                if (StrUtil.isNotBlank(discussInfoDto.getImgUrl())) {
                    String downloadUrl = UploadFileUtil.getDownloadUrl(discussInfoDto.getImgUrl(), "8084");
                    discussInfoDto.setImgUrl(downloadUrl);
                }
                if (StrUtil.isNotBlank(discussInfoDto.getUserAvatar())) {
                    String downloadUrl = UploadFileUtil.getDownloadUrl(discussInfoDto.getUserAvatar(), "8084");
                    discussInfoDto.setUserAvatar(downloadUrl);
                }
                discussInfoDtos.add(discussInfoDto);
            }
        }
        //创建返回的对象，填充数据，返回给前端
        HashMap<String, Object> map = new HashMap<>();
        map.put("total", page.getTotal());
        map.put("list", discussInfoDtos);
        map.put("pages", page.getPages());
        return CommonResult.success("查询成功", map);
    }

    @Override
    public CommonResult deleteDiscuss(HttpServletRequest request, DiscussInfoVo discussInfoVo) throws Exception {
        //获取当前登录用户的信息
        UserInfoDto userInfoDto = SessionUtil.getUserFromSession(request);
        //根据要删除数据的类型 来执行操作
        if (discussInfoVo.getType().equals(1)) {
            //删除答疑的数据
            DiscussInfo discussInfo = this.getById(discussInfoVo.getId());
            if (ObjectUtil.isNull(discussInfo)) {
                return CommonResult.error("要删除的答疑信息不存在");
            }
            //判断信息的创建人是否为当前登录用户
            if (!discussInfo.getCreateBy().equals(userInfoDto.getId())) {
                return CommonResult.error("用户没有权限操作");
            }
            //删除答疑信息对应的回复内容
            //查询回复列表
            LambdaQueryWrapper<DiscussComment> queryWrapper = new LambdaQueryWrapper<DiscussComment>()
                    .eq(DiscussComment::getRelationDiscussId, discussInfoVo.getId());
            List<DiscussComment> discussComments = discussCommentMapper.selectList(queryWrapper);
            if (CollUtil.isNotEmpty(discussComments)) {
                //如果回复列表不为空，则删除答疑关联的回复信息
                // 用 update 代替 remove 实现逻辑删除操作
                LambdaUpdateWrapper<DiscussComment> updateWrapper = new LambdaUpdateWrapper<DiscussComment>()
                        .eq(DiscussComment::getRelationDiscussId, discussInfoVo.getId())
                        .set(DiscussComment::getDeleted, 1);
                int update = discussCommentMapper.update(new DiscussComment(), updateWrapper);
                if (update < 1) {
                    return CommonResult.error("删除关联的回复信息失败");
                }
            }
            boolean update = this.removeById(discussInfoVo.getId());
            if (!update) {
                throw new Exception("删除答疑信息失败");
            }
        } else {
            //删除回复
            DiscussComment discussComment = discussCommentMapper.selectById(discussInfoVo.getId());
            //如果要删除的回复记录不存在，返回失败结果
            if (ObjectUtil.isNull(discussComment)) {
                return CommonResult.error("回复信息不存在");
            }
            //判断是否有权限删除回复
            if (!discussComment.getCreateBy().equals(userInfoDto.getId())) {
                return CommonResult.error("用户没有权限删除");
            }
            //更新与这条回复关联的的回复信息
            LambdaQueryWrapper<DiscussComment> queryWrapper = new LambdaQueryWrapper<DiscussComment>()
                    .eq(DiscussComment::getReplyId, discussInfoVo.getId());
            List<DiscussComment> discussComments = discussCommentMapper.selectList(queryWrapper);
            ArrayList<Integer> idList = new ArrayList<>();
            if (CollUtil.isNotEmpty(discussComments)) {
                //如果不为空，则更新被回复内容
                for (DiscussComment item : discussComments) {
                    idList.add(item.getId());
                }
                //执行更新操作 更新被回复内容字段 <p>回复内容已经被删除</p>
                LambdaUpdateWrapper<DiscussComment> updateWrapper = new LambdaUpdateWrapper<DiscussComment>()
                        .in(DiscussComment::getId, idList)
                        .set(DiscussComment::getUserParentContent, "&lt;p&gt;回复内容已经被删除&lt;/p&gt;");
                int update = discussCommentMapper.update(new DiscussComment(), updateWrapper);
                if (update < 1) {
                    return CommonResult.error("更新被删除回复的关联数据失败");
                }
                //用更新代替逻辑删除的操作
                LambdaUpdateWrapper<DiscussComment> removeWapper = new LambdaUpdateWrapper<DiscussComment>()
                        .eq(DiscussComment::getId, discussInfoVo.getId())
                        .set(DiscussComment::getDeleted, 1);
                int remove = discussCommentMapper.update(new DiscussComment(), removeWapper);
                if (remove < 1){
                    throw new Exception("删除回复失败");
                }
            }
        }
        return CommonResult.success("删除成功");
    }
}
