package com.example.demo.utils;

import cn.hutool.core.net.NetUtil;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.UUID;

public class UploadFileUtil {
    private static final String saveUrl = "D:/test/image/";
    //保存到本机上的一个文件夹
    private static String host = "";
    //电脑的ip地址
    private static final String returnUrl = "/file/getFile?filePath=";

    //返回给前端 下载文件的接口路径
    static {
//        host = NetUtil.getLocalhost().getHostAddress();
        host = "localhost";
    }
    //使用hutool工具类获取本机ip地址

    public static String generateName(String fileName) {

        //使用uuid生成随机字符串
        String uuid = UUID.randomUUID().toString().replace("-", "");
        //判断文件名有没有后缀，如果没有返回随机字符串+.jpg
        if (fileName.lastIndexOf('.') < 0) {
            return uuid + ".jpg";
        }
        return uuid + fileName.substring(fileName.lastIndexOf('.'));
    }

    public static String localSave(MultipartFile file, String port) {
        //生成随机文件名称
        String generateName = generateName(file.getOriginalFilename());
        //使用路径创建保存文件类
        File saveDir = new File(saveUrl);
        //判断路径是否存在，如果不存在创建文件夹
        if (!saveDir.exists()) {
            saveDir.mkdirs();
        }
        //创建文件对象，并保存
        File saveFile = new File(saveDir, generateName);
        try {
            file.transferTo(saveFile);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        //http://192.168.43.152:8084/file/getFile?filePath=D:/test/image/a2e5d27ab52449cb9a96ca66fa995a57.jpg
        return "http://" + host + ":" + port + returnUrl + saveUrl + generateName;
    }

    /**
     * 根据下载链接 获取 磁盘路径
     *
     * @param downloadUrl
     * @return
     */
    //   http://localhost：/file/getFile?filePath=  D:\test\image\3eaae8aabfa94e5f80a31304b0a5e2f6.jpg
    public static String getFilePath(String downloadUrl) {
        return downloadUrl.substring(downloadUrl.lastIndexOf("filePath=") + 9);
    }

    /**
     * 根据文件在磁盘的路径 获取 下载路径
     *
     * @param filePath
     * @param port
     * @return
     */
    public static String getDownloadUrl(String filePath, String port) {
        //判断路径是否已经是下载链接，如果不是则拼接路径
        //判断路径内是否包含有协议名称 http://
        if (filePath != null && !filePath.contains("http://")) {
            return "http://" + host + ":" + port + returnUrl + filePath;
        }
        return filePath;
    }

    /**
     * 删除文件
     *
     * @param filePath
     * @return
     */
    public static Boolean deleteFile(String filePath) {
        //用磁盘路径获取文件对象
        File file = new File(filePath);
        if (file.exists()) {
            return file.delete();
        }
        return true;
    }
}
