package com.example.demo.controller;


import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import com.example.demo.beans.CommonResult;
import com.example.demo.service.DiscussInfoService;
import com.example.demo.vo.DiscussInfoVo;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

/**
 * <p>
 * 讨论表 前端控制器
 * </p>
 *
 * @author hc1204
 * @since 2023-12-04
 */
@RestController
@RequestMapping("/discussInfo")
public class DiscussInfoController {
    @Resource
    private DiscussInfoService discussInfoService;

    @PostMapping("/addDiscuss")
    public CommonResult addDiscuss(HttpServletRequest request, @RequestBody DiscussInfoVo discussInfoVo) {
        if (ObjectUtil.isNull(discussInfoVo)) {
            return CommonResult.error("参数不能为空");
        }
        if (StrUtil.isBlank(discussInfoVo.getContent())) {
            return CommonResult.error("内容不能为空");
        }
        return discussInfoService.addDiscuss(request, discussInfoVo);
    }

    @GetMapping("/getDiscussList")
    public CommonResult getDiscussList(HttpServletRequest request, DiscussInfoVo discussInfoVo) {
        if (ObjectUtil.isNull(discussInfoVo)) {
            return CommonResult.error("参数不能为空");
        }
        if (discussInfoVo.getPage() == null || discussInfoVo.getPage() < 1) {
            return CommonResult.error("页码不能为空");
        }
        if (discussInfoVo.getSize() == null || discussInfoVo.getSize() < 1) {
            return CommonResult.error("每页条数不能为空");
        }
        return discussInfoService.getDiscussList(request,discussInfoVo);
    }

    @PostMapping("/deleteDiscuss")
    public CommonResult deleteDiscuss(HttpServletRequest request,@RequestBody DiscussInfoVo discussInfoVo){
        CommonResult result = null;
        //参数校验
        if (ObjectUtil.isNull(discussInfoVo)){
            return CommonResult.error("参数不能为空");
        }
        if (ObjectUtil.isNull(discussInfoVo.getType())){
            return CommonResult.error("要删除的数据类型不能为空");
        }
        if (ObjectUtil.isNull(discussInfoVo.getId())){
            return CommonResult.error("id不能为空");
        }
        try {
            result = discussInfoService.deleteDiscuss(request,discussInfoVo);
        } catch (Exception e) {
            return CommonResult.error(e.getMessage());
        }
        return result;
    }
}

