package com.example.demo.dto;

import com.example.demo.po.ResourceInfo;
import lombok.Data;

@Data
public class ResourceInfoDto extends ResourceInfo {
    private String fileName;
}
