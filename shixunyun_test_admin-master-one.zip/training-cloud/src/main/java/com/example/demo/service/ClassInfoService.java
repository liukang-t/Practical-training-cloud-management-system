package com.example.demo.service;

import com.example.demo.beans.CommonResult;
import com.example.demo.po.ClassInfo;
import com.baomidou.mybatisplus.extension.service.IService;
import com.example.demo.vo.ClassInfoVo;

import javax.servlet.http.HttpServletRequest;

/**
 * <p>
 * 班级表 服务类
 * </p>
 *
 * @author mp
 * @since 2023-10-25
 */
public interface ClassInfoService extends IService<ClassInfo> {

    CommonResult addClass(HttpServletRequest request, ClassInfoVo classInfoVo);

    CommonResult getClassList(HttpServletRequest request, ClassInfoVo classInfoVo);

    CommonResult modifyClass(HttpServletRequest request, ClassInfoVo classInfoVo);


    CommonResult deletedClass(HttpServletRequest request, ClassInfoVo classInfoVo) throws Exception;

    CommonResult getClassInfo(HttpServletRequest request);
}
