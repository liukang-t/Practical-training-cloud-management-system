package com.example.demo.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.http.server.HttpServerRequest;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.example.demo.beans.CommonResult;
import com.example.demo.dao.StudentInfoMapper;
import com.example.demo.dao.TeacherInfoMapper;
import com.example.demo.dto.UserInfoDto;
import com.example.demo.po.StudentInfo;
import com.example.demo.po.TeacherInfo;
import com.example.demo.po.UserInfo;
import com.example.demo.dao.UserInfoMapper;
import com.example.demo.service.UserInfoService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.demo.utils.PasswordCryptoTool;
import com.example.demo.utils.SessionUtil;
import com.example.demo.utils.UploadFileUtil;
import com.example.demo.vo.UserInfoVo;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.HashMap;
import java.util.UUID;

/**
 * <p>
 * 用户表 服务实现类
 * </p>
 *
 * @author mp
 * @since 2023-10-25
 */
@Service
public class UserInfoServiceImpl extends ServiceImpl<UserInfoMapper, UserInfo> implements UserInfoService {

    @Resource
    private TeacherInfoMapper teacherInfoMapper;

    @Resource
    private StudentInfoMapper studentInfoMapper;

    @Transactional(rollbackFor = Exception.class)
    @Override
    public CommonResult register(HttpServerRequest request, UserInfoVo userInfoVo) throws Exception {

        // 判断用户是否存在数据库,且状态为正常
        LambdaQueryWrapper<UserInfo> userInfoWapper = new LambdaQueryWrapper<UserInfo>()
                .eq(UserInfo::getAccountNumber, userInfoVo.getAccountNum())
                .eq(UserInfo::getUserStatus, 0);
        UserInfo userInfo = this.getOne(userInfoWapper);
        if (ObjectUtil.isNotNull(userInfo)) {
            return CommonResult.error("用户已存在");
        }
        //创建教师身份的账号
        UserInfo addUserInfo = new UserInfo();
        addUserInfo.setAccountNumber(userInfoVo.getAccountNum());
        String encryptPassword = PasswordCryptoTool.encryptPassword(userInfoVo.getPassword());
        addUserInfo.setPassword(encryptPassword);
        addUserInfo.setNick(userInfoVo.getTeacherName());
        addUserInfo.setUserStatus(0);
        addUserInfo.setUserType(1);
        boolean save = this.save(addUserInfo);
        if (!save) {
            return CommonResult.error("注册失败");
        }
        //创建教师信息
        TeacherInfo teacherInfo = new TeacherInfo();
        teacherInfo.setRelationUserId(addUserInfo.getId());
        teacherInfo.setTeacherName(userInfoVo.getTeacherName());
        teacherInfo.setTeacherNum(userInfoVo.getAccountNum());
        int insert = teacherInfoMapper.insert(teacherInfo);
        if (insert <= 0) {
            throw new Exception("注册失败");
        }
        return CommonResult.success("注册成功");
    }

    @Override
    public CommonResult login(HttpServletRequest request, UserInfoVo userInfoVo) {
        //从数据库查询用户信息
        LambdaQueryWrapper<UserInfo> userQueryWrapper = new LambdaQueryWrapper<UserInfo>()
                .eq(UserInfo::getAccountNumber, userInfoVo.getAccountNum())
                //TODO 查询未注销的账号
                .eq(UserInfo::getUserStatus,0);
        UserInfo userInfo = this.getOne(userQueryWrapper);
//判断数据是否为空，或者账号状态为注销状态
        if (ObjectUtil.isNull(userInfo) || Integer.valueOf(1).equals(userInfo.getUserStatus())) {
            return CommonResult.error("账号不存在");
        }
//判断密码是否正常
        Boolean checkPassword = PasswordCryptoTool.checkPassword(userInfoVo.getPassword(), userInfo.getPassword());
        if (!checkPassword) {
            return CommonResult.error("密码不正确");
        }
//生成token
        String token = UUID.randomUUID().toString();
//构造返回的账号信息
        UserInfoDto userInfoDto = new UserInfoDto();
        BeanUtil.copyProperties(userInfo, userInfoDto);
//放入账号需要的身份信息 1 教师 2学生
        if (userInfo.getUserType() == 1) {
            LambdaQueryWrapper<TeacherInfo> teacherInfoQueryWapper = new LambdaQueryWrapper<TeacherInfo>()
                    .eq(TeacherInfo::getRelationUserId, userInfo.getId());
            TeacherInfo teacherInfo = teacherInfoMapper.selectOne(teacherInfoQueryWapper);
            userInfoDto.setTeacherInfo(teacherInfo);
        } else {
            LambdaQueryWrapper<StudentInfo> studentInfoQueryWrapper = new LambdaQueryWrapper<StudentInfo>()
                    .eq(StudentInfo::getRelationUserId, userInfo.getId());
            StudentInfo studentInfo = studentInfoMapper.selectOne(studentInfoQueryWrapper);
            userInfoDto.setStudentInfo(studentInfo);
        }
//从请求中获取session 把参数放入session
        HttpSession session = request.getSession();
        session.setAttribute(token, userInfoDto);
//构造一个hashMap 把token 和 用户信息放入 返回前端
        HashMap<String, Object> map = new HashMap<>();
        map.put("token", token);
        map.put("userDto", userInfoDto);
        return CommonResult.success("登录成功", map);
    }

    @Override
    public CommonResult changePassword(HttpServletRequest request, UserInfoVo userInfoVo) {
        //从请求中获取token,从token中获取用户信息
        UserInfoDto userInfoDto = SessionUtil.getUserFromSession(request);
        //查询数据库,获取用户信息,用密码工具进行比对   select * from user_info where     account_number = ""
        LambdaQueryWrapper<UserInfo> queryWrapper = new LambdaQueryWrapper<UserInfo>()
                .eq(UserInfo::getAccountNumber, userInfoDto.getAccountNumber());
        UserInfo userInfo = this.getOne(queryWrapper);
        if (userInfo == null) {
            return CommonResult.error("用户不存在");
        }
        Boolean checkPassword = PasswordCryptoTool.checkPassword(userInfoVo.getOldPassword(), userInfo.getPassword());
        if (!checkPassword) {
            return CommonResult.error("用户密码错误");
        }
        //用密码工具进行加密,并且放置到用户信息对象中
        String encryptPassword = PasswordCryptoTool.encryptPassword(userInfoVo.getNewPassword());
        userInfo.setPassword(encryptPassword);
        //更新人的id
        userInfo.setUpdateBy(userInfoDto.getId());
        //更新数据库
        boolean update = this.updateById(userInfo);
        //放置更新的结果到session缓存中
        if (update) {
            userInfoDto.setPassword(encryptPassword);
            //从请求中获取token,从请求中获取session
            String token = SessionUtil.getTokenFromRequest(request);
            HttpSession session = request.getSession();
            //放置参数到session中
            session.setAttribute(token, userInfoDto);
            return CommonResult.success("更新密码成功");
        } else {
            return CommonResult.error("更新密码失败");
        }
    }

    @Override
    public CommonResult changeAvatar(HttpServletRequest request, UserInfoVo userInfoVo) {
//        1.从请求中获取用户信息
        UserInfoDto userInfoDto = SessionUtil.getUserFromSession(request);
//        2.创建更新对象，填充属性
        UserInfo userInfo = new UserInfo();
        userInfo.setId(userInfoDto.getId());
        //把下载路径转化为磁盘路径
        String filePath = UploadFileUtil.getFilePath(userInfoVo.getAvatar());
        userInfo.setUserAva(filePath);
        userInfo.setUpdateBy(userInfoDto.getId());
//        3.更新数据库
        boolean update = this.updateById(userInfo);
//        4.如果更新成功，更新session缓存
        if (!update) {
            return CommonResult.error("更新失败");
        }
        //把更新的头像放入缓存
        HttpSession session = request.getSession();
        String token = SessionUtil.getTokenFromRequest(request);
        userInfoDto.setUserAva(userInfoVo.getAvatar());
        session.setAttribute(token, userInfoDto);
        return CommonResult.success("更新头像成功");
    }

    @Override
    public CommonResult changeUserInfo(HttpServletRequest request, UserInfoVo userInfoVo) {
        //获取登录用户的身份信息
        UserInfoDto userInfoDto = SessionUtil.getUserFromSession(request);
        //查询用户信息是否存在
        UserInfo userInfo = this.getById(userInfoDto.getId());
        if (ObjectUtil.isNull(userInfo)){
            return CommonResult.error("用户信息不存在");
        }
        //定义一个布尔值，判断是否更新性别成功
        Boolean isUpdateGender = true;
        if (Integer.valueOf(1).equals(userInfoDto.getUserType())) {
            //教师
            TeacherInfo teacherInfo = teacherInfoMapper.selectById(userInfoDto.getTeacherInfo().getId());
            //当性别被修改，或原性别为空时
            if (teacherInfo.getGender() == null || !teacherInfo.getGender().equals(userInfoVo.getGender())) {
                //更新教师表性别
                teacherInfo.setGender(userInfoVo.getGender());
                int update = teacherInfoMapper.updateById(teacherInfo);
                isUpdateGender = update > 0 ? true : false;
            }
            userInfoDto.getTeacherInfo().setGender(userInfoVo.getGender());
        } else {
            //学生
            StudentInfo studentInfo = studentInfoMapper.selectById(userInfoDto.getStudentInfo().getId());
            //当性别被修改，或原性别为空时
            if (studentInfo.getGender() == null || !studentInfo.getGender().equals(userInfoVo.getGender())) {
                //更新学生性别
                studentInfo.setGender(userInfoVo.getGender());
                int update = studentInfoMapper.updateById(studentInfo);
                isUpdateGender = update > 0 ? true : false;
            }
            userInfoDto.getStudentInfo().setGender(userInfoVo.getGender());
        }
        //判断性别更新的结果
        if (!isUpdateGender){
            return CommonResult.error("更新用户性别失败");
        }
        //设置更新参数
        userInfo.setNick(userInfoVo.getNick());
        userInfo.setUserPhone(userInfoVo.getUserPhone());
        userInfo.setUserEmail(userInfoVo.getUserEmail());
        userInfo.setUpdateBy(userInfoDto.getId());
        //更新数据到用户表
        boolean update = this.updateById(userInfo);
        if (!update){
            return CommonResult.error("更新用户信息失败");
        }
        //更新缓存到session中
        userInfoDto.setNick(userInfoVo.getNick());
        userInfoDto.setUserPhone(userInfoVo.getUserPhone());
        userInfoDto.setUserEmail(userInfoVo.getUserEmail());
        HttpSession session = request.getSession();
        String token = SessionUtil.getTokenFromRequest(request);
        session.setAttribute(token,userInfoDto);
        return CommonResult.success("更新用户信息成功");
    }

}
