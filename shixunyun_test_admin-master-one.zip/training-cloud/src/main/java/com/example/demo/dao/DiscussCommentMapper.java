package com.example.demo.dao;

import com.example.demo.po.DiscussComment;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 评论表 Mapper 接口 数据库持久层
 * </p>
 *
 * @author mp
 * @since 2023-12-04
 */
public interface DiscussCommentMapper extends BaseMapper<DiscussComment> {

}
