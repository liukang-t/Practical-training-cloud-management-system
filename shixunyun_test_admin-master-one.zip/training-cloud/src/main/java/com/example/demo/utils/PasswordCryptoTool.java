package com.example.demo.utils;

import cn.hutool.crypto.digest.BCrypt;

public class PasswordCryptoTool {

    /**
     * 密码加密
     * @param password
     * @return
     */
    public static String encryptPassword(String password){
        return BCrypt.hashpw(password, BCrypt.gensalt());
    }

    /**
     * 密码验证
     * @param password
     * @param encryptPassword
     * @return
     */
    public static Boolean checkPassword(String password,String encryptPassword){
        return BCrypt.checkpw(password, encryptPassword);
    }
}
