package com.example.demo.service.impl;

import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import com.example.demo.beans.CommonResult;
import com.example.demo.dao.DiscussInfoMapper;
import com.example.demo.dto.UserInfoDto;
import com.example.demo.po.DiscussComment;
import com.example.demo.dao.DiscussCommentMapper;
import com.example.demo.po.DiscussInfo;
import com.example.demo.service.DiscussCommentService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.demo.utils.SessionUtil;
import com.example.demo.utils.UploadFileUtil;
import com.example.demo.vo.DiscussCommentVo;
import org.springframework.stereotype.Service;
import org.springframework.web.util.HtmlUtils;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

/**
 * <p>
 * 评论表 服务实现类
 * </p>
 *
 * @author hc1204
 * @since 2023-12-04
 */
@Service
public class DiscussCommentServiceImpl extends ServiceImpl<DiscussCommentMapper, DiscussComment> implements DiscussCommentService {

    @Resource
    DiscussInfoMapper discussInfoMapper;

    @Override
    public CommonResult addDiscussComment(HttpServletRequest request, DiscussCommentVo discussCommentVo) {
        //获取登录用户的信息
        UserInfoDto userInfoDto = SessionUtil.getUserFromSession(request);
        //查询关联的答疑内容是否存在
        DiscussInfo discussInfo = discussInfoMapper.selectById(discussCommentVo.getRelationDiscussId());
        if (ObjectUtil.isNull(discussInfo)) {
            return CommonResult.error("答疑信息不存在");
        }
        //创建要插入数据库的回复对象
        DiscussComment discussComment = new DiscussComment();
        //根据回复的对象，设置被回复的内容
        if (ObjectUtil.isNull(discussCommentVo.getReplyId())) {
            //如果关联的回复id为空，说明是对答疑内容进行回复
            //被回复人id
            discussComment.setReplyPeopleId(discussInfo.getCreateBy());
            //被回复人名称
            discussComment.setUserParentNick(discussInfo.getCreateByName());
        } else {
            //如果有传replyId 说明是对别人的回复内容 进行 回复的操作
            DiscussComment beReplyComment = this.getById(discussCommentVo.getReplyId());
            if (ObjectUtil.isNull(beReplyComment)) {
                return CommonResult.error("被回复的内容不存在");
            }
            //被回复的内容id
            discussComment.setReplyPeopleId(beReplyComment.getCreateBy());
            //被回复人的id
            discussComment.setReplyId(beReplyComment.getId());
            //被回复人的昵称
            discussComment.setUserParentNick(beReplyComment.getCreateByName());
            //被回复的内容
            discussComment.setUserParentContent(beReplyComment.getContent());
        }
        //设置关联的答疑id
        discussComment.setRelationDiscussId(discussCommentVo.getRelationDiscussId());
        //设置回复的内容 需要进行转义 <p> -> &ltp&gt  把html标签转义
        String htmlEscape = HtmlUtils.htmlEscape(discussCommentVo.getContent());
        discussComment.setContent(htmlEscape);
        //对文件路径处理，如果有传文件路径，则进行判断空值，如果不为空，则转换为磁盘路径
        if (StrUtil.isNotBlank(discussCommentVo.getImgUrl())) {
            String filePath = UploadFileUtil.getFilePath(discussCommentVo.getImgUrl());
            discussComment.setImgUrl(filePath);
        }
        //设置创建人信息
        discussComment.setCreateBy(userInfoDto.getId());
        discussComment.setCreateByName(userInfoDto.getNick());
        //把用户头像 从下载路径 转换为磁盘路径
        if (StrUtil.isNotBlank(userInfoDto.getUserAva())) {
            String filePath = UploadFileUtil.getFilePath(userInfoDto.getUserAva());
            discussComment.setUserAvatar(filePath);
        }
        //插入对象到数据库
        boolean save = this.save(discussComment);
        return save ? CommonResult.success("回复成功") : CommonResult.error("回复失败");
    }
}
