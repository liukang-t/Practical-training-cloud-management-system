package com.example.demo.vo;

import lombok.Data;

@Data
public class UserInfoVo {

    /**
     * 用户昵称
     */
    private String teacherName;

    /**
     * 账号
     */
    private String accountNum;

    /**
     * 密码
     */
    private String password;


    /**
     * 旧密码
     */
    private String oldPassword;

    /**
     * 新密码
     */
    private String newPassword;


    /**
     * 头像
     */
    private String avatar;

    /**
     * 昵称
     */
    private String nick;

    /**
     * 手机号
     */
    private String userPhone;

    /**
     * 邮箱
     */
    private String userEmail;


    /**
     * 性别 1-男 2-女
     */
    private Integer gender;
}
