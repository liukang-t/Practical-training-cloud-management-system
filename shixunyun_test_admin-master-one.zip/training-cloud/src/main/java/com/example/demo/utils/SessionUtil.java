package com.example.demo.utils;

import com.example.demo.dto.UserInfoDto;
import org.apache.commons.lang3.StringUtils;

import javax.servlet.http.HttpServletRequest;

/**
 * 缓存操作工具
 */
public class SessionUtil {

    /**
     *  从请求中获取token
     * @param request 请求
     * @return token
     */
    public static String getTokenFromRequest(HttpServletRequest request){
        String token = request.getParameter("token");
        if (StringUtils.isBlank(token)){
            token = request.getHeader("token");
        }
        return token;
    }
    /**
     *  通过token从session中获取用户信息
     * @param request 请求
     * @return token
     */
    public static UserInfoDto getUserFromSession(HttpServletRequest request){

        String token = getTokenFromRequest(request);
        //获取缓存
        return (UserInfoDto) request.getSession().getAttribute(token);
    }

}