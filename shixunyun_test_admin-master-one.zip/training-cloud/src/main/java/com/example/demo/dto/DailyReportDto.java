package com.example.demo.dto;

import com.example.demo.po.DailyReport;
import lombok.Data;

@Data
public class DailyReportDto extends DailyReport {
    /**
     * 关联的学生名称
     */
    private String relationStudentName;
}
