package com.example.demo.vo;

import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;
import java.util.List;

@Data
public class StudentInfoVo extends BaseVo{
/*    studentName: '',
    studentNumber: '',
    gender: '',
    relationClassId: '',
    age: '',
    birth: ''*/

    /**
     * 学生姓名
     */
    private String studentName;

    /**
     * 学号
     */
    private String studentNumber;


    /**
     * 性别 1 男 2女
     */
    private Integer gender;

    /**
     * 关联的班级id
     */
    private Integer relationClassId;

    /**
     * 年龄
     */
    private Integer age;

    /**
     * 生日  2023-11-06
     */
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date birth;


    private Integer relationTeacherId;

    /**
     * id列表
     */
    private List<Integer> idList;
}
