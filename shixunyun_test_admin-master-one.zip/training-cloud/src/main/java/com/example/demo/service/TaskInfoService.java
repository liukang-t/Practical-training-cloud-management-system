package com.example.demo.service;

import com.example.demo.beans.CommonResult;
import com.example.demo.po.TaskInfo;
import com.baomidou.mybatisplus.extension.service.IService;
import com.example.demo.vo.TaskInfoVo;

import javax.servlet.http.HttpServletRequest;

/**
 * <p>
 * 任务表 服务类
 * </p>
 *
 * @author hc1201
 * @since 2023-11-27
 */
public interface TaskInfoService extends IService<TaskInfo> {

    CommonResult addTask(HttpServletRequest request, TaskInfoVo taskInfoVo);

    CommonResult getTaskList(HttpServletRequest request, TaskInfoVo taskInfoVo);

    CommonResult modifyTask(HttpServletRequest request, TaskInfoVo taskInfoVo);

    CommonResult deleteTask(HttpServletRequest request, TaskInfoVo taskInfoVo) throws Exception;

    CommonResult getTaskDetail(HttpServletRequest request, TaskInfoVo taskInfoVo);
}
