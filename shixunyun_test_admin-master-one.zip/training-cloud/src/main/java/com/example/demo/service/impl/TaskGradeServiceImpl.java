package com.example.demo.service.impl;

import cn.hutool.core.util.ObjectUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.example.demo.beans.CommonResult;
import com.example.demo.dao.TaskInfoMapper;
import com.example.demo.dto.TaskGradeDto;
import com.example.demo.dto.UserInfoDto;
import com.example.demo.po.TaskGrade;
import com.example.demo.dao.TaskGradeMapper;
import com.example.demo.po.TaskInfo;
import com.example.demo.service.TaskGradeService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.demo.utils.SessionUtil;
import com.example.demo.vo.TaskGradeVo;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.List;

/**
 * <p>
 * 任务评分表 服务实现类
 * </p>
 *
 * @author hc1204
 * @since 2023-11-27
 */
@Service
public class TaskGradeServiceImpl extends ServiceImpl<TaskGradeMapper, TaskGrade> implements TaskGradeService {

    @Resource
    TaskInfoMapper taskInfoMapper;

    @Override
    public CommonResult getTaskScoreList(HttpServletRequest request, TaskGradeVo taskGradeVo) {
        //查询任务信息是否存在
        TaskInfo taskInfo = taskInfoMapper.selectById(taskGradeVo.getTaskId());
        if (ObjectUtil.isNull(taskInfo)) {
            return CommonResult.error("任务信息不存在");
        }
        //设置查询条件，关联的班级id
        taskGradeVo.setRelationClassId(taskInfo.getRelationClassId());
        //使用sql语句 进行 联表查询 关联 学生信息表  任务评分表
        List<TaskGradeDto> list = this.baseMapper.getTaskScoreList(taskGradeVo);
        Integer total = this.baseMapper.countTaskScore(taskGradeVo);
        //创建返回结果，填充参数
        HashMap<String, Object> map = new HashMap<>();
        map.put("total", total);
        map.put("list", list);
        return CommonResult.success("查询列表成功", map);
    }

    @Override
    public CommonResult modifyTaskScore(HttpServletRequest request, TaskGradeVo taskGradeVo) {
        //获取用户信息
        UserInfoDto userInfoDto = SessionUtil.getUserFromSession(request);
        if (!Integer.valueOf(1).equals(userInfoDto.getUserType()) || ObjectUtil.isNull(userInfoDto.getTeacherInfo())) {
            return CommonResult.error("用户没有权限操作");
        }
        //查询评分的信息是否存在
        LambdaQueryWrapper<TaskGrade> queryWrapper = new LambdaQueryWrapper<TaskGrade>()
                .eq(TaskGrade::getRelationTaskId, taskGradeVo.getTaskId())
                .eq(TaskGrade::getRelationStudentId, taskGradeVo.getStudentId());
        TaskGrade taskGrade = this.getOne(queryWrapper);
        if (ObjectUtil.isNull(taskGrade)) {
            //新增
            taskGrade = new TaskGrade();
            taskGrade.setScore(taskGradeVo.getScore());
            taskGrade.setRelationTaskId(taskGradeVo.getTaskId());
            taskGrade.setRelationStudentId(taskGradeVo.getStudentId());
            taskGrade.setRelationTeacherId(userInfoDto.getTeacherInfo().getId());
            taskGrade.setCreateBy(userInfoDto.getId());
        } else {
            //修改
            taskGrade.setScore(taskGradeVo.getScore());
            taskGrade.setUpdateBy(taskGradeVo.getId());
        }
        boolean update = this.saveOrUpdate(taskGrade);
        return update ? CommonResult.success("任务评分成功") : CommonResult.error("任务评分失败");
    }
}
