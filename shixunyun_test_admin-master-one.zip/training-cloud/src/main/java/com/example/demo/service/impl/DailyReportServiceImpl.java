package com.example.demo.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.util.ObjectUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.demo.beans.CommonResult;
import com.example.demo.dao.ClassInfoMapper;
import com.example.demo.dao.StudentInfoMapper;
import com.example.demo.dto.DailyReportDto;
import com.example.demo.dto.StudentDailyReportDto;
import com.example.demo.dto.UserInfoDto;
import com.example.demo.po.ClassInfo;
import com.example.demo.po.DailyReport;
import com.example.demo.dao.DailyReportMapper;
import com.example.demo.po.StudentInfo;
import com.example.demo.service.DailyReportService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.demo.utils.SessionUtil;
import com.example.demo.vo.DailyReportVo;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * <p>
 * 学生日报表 服务实现类
 * </p>
 *
 * @author mp
 * @since 2023-11-23
 */
@Service
public class DailyReportServiceImpl extends ServiceImpl<DailyReportMapper, DailyReport> implements DailyReportService {

    @Resource
    StudentInfoMapper studentInfoMapper;

    @Resource
    ClassInfoMapper classInfoMapper;

    @Override
    public CommonResult addDailyReport(HttpServletRequest request, DailyReportVo dailyReportVo) {
        //先获取用户身份
        UserInfoDto userInfoDto = SessionUtil.getUserFromSession(request);
        //判断是否为学生
        if (!Integer.valueOf(2).equals(userInfoDto.getUserType()) || ObjectUtil.isNull(userInfoDto.getStudentInfo())) {
            return CommonResult.error("用户没有权限添加日报");
        }
        //创建要保存的对象
        DailyReport dailyReport = new DailyReport();
        dailyReport.setContent(dailyReportVo.getContent());
        dailyReport.setProblem(dailyReportVo.getProblem());
        dailyReport.setRelationStudentId(userInfoDto.getStudentInfo().getId());
        dailyReport.setRelationClassId(userInfoDto.getStudentInfo().getRelationClassId());
        //插入数据到数据库
        boolean save = this.save(dailyReport);
        return save ? CommonResult.success("提交日报成功") : CommonResult.error("提交日报失败");
    }

    @Override
    public CommonResult getDailyReportList(HttpServletRequest request, DailyReportVo dailyReportVo) {
        //获取用户的身份信息
        UserInfoDto userInfoDto = SessionUtil.getUserFromSession(request);
        //根据身份类型填充查询条件
        LambdaQueryWrapper<DailyReport> queryWrapper = new LambdaQueryWrapper<>();
        String studentName = null;
        if (userInfoDto.getUserType().equals(1)) {
            //教师
            if (ObjectUtil.isNull(dailyReportVo.getRelationStudentId())) {
                return CommonResult.error("关联的学生id不能为空");
            }
            //去查询学生信息
            StudentInfo studentInfo = studentInfoMapper.selectById(dailyReportVo.getRelationStudentId());
            if (ObjectUtil.isNull(studentInfo)) {
                return CommonResult.error("查询的学生不存在");
            }
            studentName = studentInfo.getStudentName();
            queryWrapper.eq(DailyReport::getRelationStudentId, dailyReportVo.getRelationStudentId());
        } else {
            //学生
            queryWrapper.eq(DailyReport::getRelationStudentId, userInfoDto.getStudentInfo().getId());
            studentName = userInfoDto.getStudentInfo().getStudentName();
        }
        //构造分页构造器，进行分页查询
        Page<DailyReport> page = new Page<>(dailyReportVo.getPage(), dailyReportVo.getSize());
        IPage<DailyReport> dailyReportPage = this.page(page, queryWrapper);
        //对数据进行处理
        ArrayList<DailyReportDto> dailyReportDtos = new ArrayList<>();
        if (dailyReportPage.getRecords() != null && dailyReportPage.getRecords().size() > 0) {
            for (int i = 0; i < dailyReportPage.getRecords().size(); i++) {
                DailyReport dailyReport = dailyReportPage.getRecords().get(i);
                DailyReportDto dailyReportDto = new DailyReportDto();
                BeanUtil.copyProperties(dailyReport, dailyReportDto);
                dailyReportDto.setRelationStudentName(studentName);
                dailyReportDtos.add(dailyReportDto);
            }
        }
        //创建返回结果 填充属性
        HashMap<String, Object> map = new HashMap<>();
        map.put("total", dailyReportPage.getTotal());
        map.put("list", dailyReportDtos);
        map.put("pages", dailyReportPage.getPages());
        return CommonResult.success("查询日报成功", map);
    }

    @Override
    public CommonResult getStudentDailyList(HttpServletRequest request, DailyReportVo dailyReportVo) {
        //获取用户信息
        UserInfoDto userInfoDto = SessionUtil.getUserFromSession(request);
        //判断身份类型是否为教师
        if (!Integer.valueOf(1).equals(userInfoDto.getUserType()) || ObjectUtil.isNull(userInfoDto.getTeacherInfo())) {
            return CommonResult.error("用户没有权限操作");
        }
        //设置查询条件
        if (ObjectUtil.isNull(dailyReportVo.getRelationClassId())) {
            dailyReportVo.setRelationTeacherId(userInfoDto.getTeacherInfo().getId());
        } else {
            //查询班级是否存在，判断班级是否属于当前教师用户
            ClassInfo classInfo = classInfoMapper.selectById(dailyReportVo.getRelationClassId());
            if (ObjectUtil.isNull(classInfo)) {
                return CommonResult.error("班级不存在");
            }
            if (!classInfo.getRelationTeacherId().equals(userInfoDto.getTeacherInfo().getId())) {
                return CommonResult.error("班级不属于当前用户");
            }
        }
        //查询日报的分页列表
        List<StudentDailyReportDto> list = this.baseMapper.selectStudentDailyReportList(dailyReportVo);
        Integer total = this.baseMapper.countStudentDailyReport(dailyReportVo);
        //创建返回结果
        HashMap<String, Object> map = new HashMap<>();
        map.put("total", total);
        map.put("list", list);
        return CommonResult.success("查询成功", map);
    }

    @Override
    public CommonResult commentOnDailyReport(HttpServletRequest request, DailyReportVo dailyReportVo) {
        //获取登录用户信息，判断身份是否为教师
        UserInfoDto userInfoDto = SessionUtil.getUserFromSession(request);
        if (!Integer.valueOf(1).equals(userInfoDto.getUserType()) || ObjectUtil.isNull(userInfoDto.getTeacherInfo())) {
            return CommonResult.error("用户没有权限操作");
        }
        //查询日报是否存在
        DailyReport dailyReport = this.getById(dailyReportVo.getId());
        if (ObjectUtil.isNull(dailyReport)) {
            return CommonResult.error("日报不存在");
        }
        //查询班级信息，判断班级是否属于当前教师
        ClassInfo classInfo = classInfoMapper.selectById(dailyReport.getRelationClassId());
        if (ObjectUtil.isNull(classInfo)) {
            return CommonResult.error("班级不存在");
        }
        if (!classInfo.getRelationTeacherId().equals(userInfoDto.getTeacherInfo().getId())) {
            return CommonResult.error("班级不属于当前教师");
        }
        //填充数据，更新到数据库
        dailyReport.setComment(dailyReportVo.getComment());
        boolean update = this.updateById(dailyReport);
        return update ? CommonResult.success("更新成功") : CommonResult.error("更新失败");
    }
}
