package com.example.demo.vo;

import lombok.Data;

@Data
public class BaseVo {

    /**
     * 页码
     */
    private Integer page;

    /**
     * 数量
     */
    private Integer size;

    /**
     * 偏移量
     */
    private Integer offset;

    /**
     * 关键词
     */
    private String key;

    /**
     * id
     */
    private Integer id;

    public Integer getOffset() {
        if (page != null && size != null) {
            return (page - 1) * size;
        }
        return null;
    }
}
