package com.example.demo.service.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.ObjectUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.demo.beans.CommonResult;
import com.example.demo.dao.ClassInfoMapper;
import com.example.demo.dto.StudentVideoInfoDto;
import com.example.demo.dto.UserInfoDto;
import com.example.demo.po.ClassInfo;
import com.example.demo.po.VideoInfo;
import com.example.demo.dao.VideoInfoMapper;
import com.example.demo.service.VideoInfoService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.demo.utils.SessionUtil;
import com.example.demo.utils.UploadFileUtil;
import com.example.demo.vo.VideoInfoVo;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.List;

/**
 * <p>
 * 视频列表 服务实现类
 * </p>
 *
 * @author mp
 * @since 2023-12-13
 */
@Service
public class VideoInfoServiceImpl extends ServiceImpl<VideoInfoMapper, VideoInfo> implements VideoInfoService {

    @Resource
    ClassInfoMapper classInfoMapper;

    @Override
    public CommonResult addVideoInfo(HttpServletRequest request, VideoInfoVo videoInfoVo) {
        //获取当前登录的用户信息，判断身份类型是否为学生
        UserInfoDto userInfoDto = SessionUtil.getUserFromSession(request);
        //用户的身份类型不是学生
        if (!userInfoDto.getUserType().equals(2) || ObjectUtil.isNull(userInfoDto.getStudentInfo())) {
            return CommonResult.error("用户没有权限操作");
        }
        //创建信息对象，填充数据
        VideoInfo videoInfo = new VideoInfo();
        //视频内容的信息
        videoInfo.setVideoName(videoInfoVo.getVideoName());
        String path = UploadFileUtil.getFilePath(videoInfoVo.getVideoUrl());
        videoInfo.setVideoUrl(path);
        videoInfo.setContent(videoInfoVo.getContent());
        //身份的信息
        videoInfo.setRelationClassId(userInfoDto.getStudentInfo().getRelationClassId());
        videoInfo.setRelationStudentId(userInfoDto.getStudentInfo().getId());
        boolean save = this.save(videoInfo);
        return save ? CommonResult.success("上传视频成功") : CommonResult.error("上传视频失败");
    }

    @Override
    public CommonResult getVideoList(HttpServletRequest request, VideoInfoVo videoInfoVo) {
        UserInfoDto userInfoDto = SessionUtil.getUserFromSession(request);
        //根据用户类型设置查询条件
        LambdaQueryWrapper<VideoInfo> queryWrapper = new LambdaQueryWrapper<>();
        if (userInfoDto.getUserType().equals(1)) {
            //教师
            if (ObjectUtil.isNull(videoInfoVo.getRelationStudentId())) {
                return CommonResult.error("关联的学生id不能为空");
            }
            queryWrapper.eq(VideoInfo::getRelationStudentId, videoInfoVo.getRelationStudentId());
        } else {
            //学生
            queryWrapper.eq(VideoInfo::getRelationStudentId, userInfoDto.getStudentInfo().getId());
        }
        //创建分页构造器 执行分页查询
        Page<VideoInfo> videoInfoPage = new Page<>(videoInfoVo.getPage(), videoInfoVo.getSize());
        IPage<VideoInfo> page = this.page(videoInfoPage, queryWrapper);
        //如果有查询结果，则处理数据
        List<VideoInfo> records = page.getRecords();
        if (CollUtil.isNotEmpty(records)){
            records.forEach(t -> {
              //处理视频的链接为下载链接
                String downloadUrl = UploadFileUtil.getDownloadUrl(t.getVideoUrl(), "8084");
                t.setVideoUrl(downloadUrl);
            });
        }
        //返回结果给前端
        HashMap<String, Object> map = new HashMap<>();
        map.put("total",page.getTotal());
        map.put("list",page.getRecords());
        map.put("pages",page.getRecords());
        return CommonResult.success("查询成功",map);
    }

    @Override
    public CommonResult deleteVideoInfo(HttpServletRequest request, VideoInfoVo videoInfoVo) {
        //获取用户信息，判断身份类型是否为学生
        UserInfoDto userInfoDto = SessionUtil.getUserFromSession(request);
        if (!userInfoDto.getUserType().equals(2)){
            return CommonResult.error("用户没有权限操作");
        }
        //查询要删除的信息是否存在
        LambdaQueryWrapper<VideoInfo> queryWrapper = new LambdaQueryWrapper<VideoInfo>()
                .eq(VideoInfo::getRelationStudentId, userInfoDto.getStudentInfo().getId())
                .in(VideoInfo::getId, videoInfoVo.getIdList());
        List<VideoInfo> list = this.list(queryWrapper);
        //对列表做验证
        if (CollUtil.isEmpty(list) || list.size() != videoInfoVo.getIdList().size()){
            return CommonResult.error("要删除的数据异常");
        }
        //批量删除
        boolean update = this.removeByIds(videoInfoVo.getIdList());
        if (!update){
            return CommonResult.error("删除视频信息失败");
        }
        //删除视频信息对应的文件
        for (VideoInfo item:
             list) {
            String videoUrl = item.getVideoUrl();
            UploadFileUtil.deleteFile(videoUrl);
        }
        return CommonResult.success("删除视频成功");
    }

    @Override
    public CommonResult getStudentVideoList(HttpServletRequest request, VideoInfoVo videoInfoVo) {
        UserInfoDto userInfoDto = SessionUtil.getUserFromSession(request);
        //对用户的权限做判断
        if (!userInfoDto.getUserType().equals(1)){
            return CommonResult.error("用户没有权限操作");
        }
        //设置查询条件
        if (ObjectUtil.isNull(videoInfoVo.getRelationClassId())){
            videoInfoVo.setRelationTeacherId(userInfoDto.getTeacherInfo().getId());
        } else {
            ClassInfo classInfo = classInfoMapper.selectById(videoInfoVo.getRelationClassId());
            if (ObjectUtil.isNull(classInfo)){
                return CommonResult.error("班级信息不存在");
            }
            if (!classInfo.getRelationTeacherId().equals(userInfoDto.getTeacherInfo().getId())){
                return CommonResult.error("班级不属于当前教师用户");
            }
        }
        //用sql实现 学生表 关联 视频表的联表分页查询
        List<StudentVideoInfoDto> list = this.baseMapper.getStudentVideoList(videoInfoVo);
        Integer count = this.baseMapper.countStudentVideo(videoInfoVo);
        //创建返回结果
        HashMap<String, Object> map = new HashMap<>();
        map.put("total",count);
        map.put("list",list);
        return CommonResult.success("查询成功",map);
    }
}
