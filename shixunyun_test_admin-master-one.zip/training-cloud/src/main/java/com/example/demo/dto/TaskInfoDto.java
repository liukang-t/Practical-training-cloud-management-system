package com.example.demo.dto;

import com.example.demo.po.TaskInfo;
import lombok.Data;

@Data
public class TaskInfoDto extends TaskInfo {

    /**
     * 平均分数 1.1
     */
    private String scoreAverage;
}
