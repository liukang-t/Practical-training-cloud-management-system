package com.example.demo.controller;


import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import com.example.demo.beans.CommonResult;
import com.example.demo.service.TaskInfoService;
import com.example.demo.vo.TaskInfoVo;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

/**
 * <p>
 * 任务表 前端控制器
 * </p>
 *
 * @author hc1201
 * @since 2023-11-27
 */
@RestController
@RequestMapping("/taskInfo")
public class TaskInfoController {

    @Resource
    TaskInfoService taskInfoService;

    @PostMapping("/addTask")
    public CommonResult addTask(HttpServletRequest request, @RequestBody TaskInfoVo taskInfoVo){
        //参数校验
        if (ObjectUtil.isNull(taskInfoVo)){
            return CommonResult.error("参数不能为空");
        }
        if (StrUtil.isBlank(taskInfoVo.getTaskName())){
            return CommonResult.error("任务名称不能为空");
        }
        if (StrUtil.isBlank(taskInfoVo.getContent())){
            return CommonResult.error("任务内容不能为空");
        }
        if (ObjectUtil.isNull(taskInfoVo.getStartTime())){
            return CommonResult.error("开始时间不能为空");
        }
        if (ObjectUtil.isNull(taskInfoVo.getEndTime())){
            return CommonResult.error("结束时间不能为空");
        }
        if (taskInfoVo.getStartTime().getTime() > taskInfoVo.getEndTime().getTime()){
            return CommonResult.error("开始时间不能大于结束时间");
        }
        if (ObjectUtil.isNull(taskInfoVo.getRelationClassId())){
            return CommonResult.error("关联班级id不能为空");
        }
        return taskInfoService.addTask(request,taskInfoVo);
    }

    @GetMapping("/getTaskList")
    public CommonResult getTaskList(HttpServletRequest request,TaskInfoVo taskInfoVo){
        if (ObjectUtil.isNull(taskInfoVo)){
            return CommonResult.error("参数不能为空");
        }
        if (ObjectUtil.isNull(taskInfoVo.getPage())){
            return CommonResult.error("页码不能为空");
        }
        if (ObjectUtil.isNull(taskInfoVo.getSize())){
            return CommonResult.error("每页条数不能为空");
        }
        return taskInfoService.getTaskList(request,taskInfoVo);
    }

    @PostMapping("/modifyTask")
    public CommonResult modifyTask(HttpServletRequest request,@RequestBody TaskInfoVo taskInfoVo){
        //参数校验
        if (ObjectUtil.isNull(taskInfoVo)){
            return CommonResult.error("参数不能为空");
        }
        if (ObjectUtil.isNull(taskInfoVo.getId())){
            return CommonResult.error("日报的id不能为空");
        }
        if (StrUtil.isBlank(taskInfoVo.getTaskName())){
            return CommonResult.error("任务名称不能为空");
        }
        if (StrUtil.isBlank(taskInfoVo.getContent())){
            return CommonResult.error("任务的内容不能为空");
        }
        if (ObjectUtil.isNull(taskInfoVo.getEndTime())){
            return CommonResult.error("任务的截至时间不能为空");
        }
        return taskInfoService.modifyTask(request,taskInfoVo);
    }

    @PostMapping("/deleteTask")
    public CommonResult deleteTask(HttpServletRequest request,@RequestBody TaskInfoVo taskInfoVo){
        CommonResult result = null;
        //参数校验
        if (ObjectUtil.isNull(taskInfoVo)){
            return CommonResult.error("参数不能为空");
        }
        if (CollUtil.isEmpty(taskInfoVo.getIdList())){
            return CommonResult.error("id列表不能为空");
        }
        try {
            result = taskInfoService.deleteTask(request,taskInfoVo);
        } catch (Exception e) {
            return CommonResult.error(e.getMessage());
        }
        return result;
    }

    @GetMapping("/getTaskDetail")
    public CommonResult getTaskDetail(HttpServletRequest request ,TaskInfoVo taskInfoVo){
        //参数校验
        if (ObjectUtil.isNull(taskInfoVo)){
            return CommonResult.error("参数不能为空");
        }
        if (ObjectUtil.isNull(taskInfoVo.getId())){
            return CommonResult.error("任务id不能为空");
        }
        return taskInfoService.getTaskDetail(request,taskInfoVo);
    }
}

