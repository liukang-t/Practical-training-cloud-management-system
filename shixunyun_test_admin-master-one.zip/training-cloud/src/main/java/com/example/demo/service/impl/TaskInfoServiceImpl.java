package com.example.demo.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.ObjectUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.demo.beans.CommonResult;
import com.example.demo.dao.ClassInfoMapper;
import com.example.demo.dto.TaskInfoDto;
import com.example.demo.dto.UserInfoDto;
import com.example.demo.po.ClassInfo;
import com.example.demo.po.TaskGrade;
import com.example.demo.po.TaskInfo;
import com.example.demo.dao.TaskInfoMapper;
import com.example.demo.service.TaskGradeService;
import com.example.demo.service.TaskInfoService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.demo.utils.SessionUtil;
import com.example.demo.vo.TaskInfoVo;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.List;

/**
 * <p>
 * 任务表 服务实现类
 * </p>
 *
 * @author hc1201
 * @since 2023-11-27
 */
@Service
public class TaskInfoServiceImpl extends ServiceImpl<TaskInfoMapper, TaskInfo> implements TaskInfoService {

    @Resource
    TaskGradeService taskGradeService;

    @Resource
    ClassInfoMapper classInfoMapper;

    @Override
    public CommonResult addTask(HttpServletRequest request, TaskInfoVo taskInfoVo) {
        // 获取登录的用户，判断用户的身份类型是否为教师
        UserInfoDto userInfoDto = SessionUtil.getUserFromSession(request);
        if (!Integer.valueOf(1).equals(userInfoDto.getUserType()) || ObjectUtil.isNull(userInfoDto.getTeacherInfo())) {
            return CommonResult.error("用户没有权限操作");
        }
        //查询班级是否存在
        ClassInfo classInfo = classInfoMapper.selectById(taskInfoVo.getRelationClassId());
        if (ObjectUtil.isNull(classInfo)) {
            return CommonResult.error("班级信息不存在");
        }
        if (!classInfo.getRelationTeacherId().equals(userInfoDto.getTeacherInfo().getId())) {
            return CommonResult.error("班级不属于当前教师账号");
        }
        //创建任务信息对象，填充属性
        TaskInfo taskInfo = new TaskInfo();
        taskInfo.setTaskName(taskInfoVo.getTaskName());
        taskInfo.setContent(taskInfoVo.getContent());
        taskInfo.setStartTime(taskInfoVo.getStartTime());
        taskInfo.setEndTime(taskInfoVo.getEndTime());
        taskInfo.setRelationClassId(taskInfoVo.getRelationClassId());
        taskInfo.setRelationTeacherId(userInfoDto.getTeacherInfo().getId());
        taskInfo.setTaskStatus(1);
        taskInfo.setCreateBy(userInfoDto.getId());
        //保存信息到数据库
        boolean save = this.save(taskInfo);
        return save ? CommonResult.success("保存成功") : CommonResult.error("保存失败");
    }

    @Override
    public CommonResult getTaskList(HttpServletRequest request, TaskInfoVo taskInfoVo) {
        //获取用户身份信息
        UserInfoDto userInfoDto = SessionUtil.getUserFromSession(request);
        //根据用户的身份类型设置查询条件 如果为教师 则使用教师id  如果为学生 则使用关联班级id
        LambdaQueryWrapper<TaskInfo> queryWrapper = new LambdaQueryWrapper<>();
        if (Integer.valueOf(1).equals(userInfoDto.getUserType())) {
            queryWrapper.eq(TaskInfo::getRelationTeacherId, userInfoDto.getTeacherInfo().getId());
            if (ObjectUtil.isNotNull(taskInfoVo.getRelationClassId())) {
                queryWrapper.eq(TaskInfo::getRelationClassId, taskInfoVo.getRelationClassId());
            }
        } else {
            queryWrapper.eq(TaskInfo::getRelationClassId, userInfoDto.getStudentInfo().getRelationClassId());
        }
        //创建分页构造器，查询分页列表
        Page<TaskInfo> page = new Page<>(taskInfoVo.getPage(), taskInfoVo.getSize());
        IPage<TaskInfo> taskInfoIPage = this.page(page, queryWrapper);
        //创建一个返回结果，填充数据
        HashMap<String, Object> map = new HashMap<>();
        map.put("total", taskInfoIPage.getTotal());
        map.put("list", taskInfoIPage.getRecords());
        map.put("pages", taskInfoIPage.getPages());
        return CommonResult.success("查询成功", map);
    }

    @Override
    public CommonResult modifyTask(HttpServletRequest request, TaskInfoVo taskInfoVo) {
//        1.获取用户身份信息，判断是否为教师
        UserInfoDto userInfoDto = SessionUtil.getUserFromSession(request);
        if (!Integer.valueOf(1).equals(userInfoDto.getUserType()) || ObjectUtil.isNull(userInfoDto.getTeacherInfo())) {
            return CommonResult.error("用户没有权限操作");
        }
//        2.查询要修改的任务信息，判断是否存在，是否属于当前用户
        TaskInfo taskInfo = this.getById(taskInfoVo.getId());
        if (ObjectUtil.isNull(taskInfo)) {
            return CommonResult.error("任务信息不存在");
        }
        if (!taskInfo.getRelationTeacherId().equals(userInfoDto.getTeacherInfo().getId())) {
            return CommonResult.error("当前任务不属于当前教师");
        }
//        3.判断结束时间是否大于开始时间
        if (taskInfo.getStartTime().getTime() > taskInfoVo.getEndTime().getTime()) {
            return CommonResult.error("开始时间不能大于结束时间");
        }
//        4. 修改任务信息，更新到数据库
        taskInfo.setTaskName(taskInfoVo.getTaskName());
        taskInfo.setContent(taskInfoVo.getContent());
        taskInfo.setEndTime(taskInfoVo.getEndTime());
        taskInfo.setUpdateBy(userInfoDto.getId());
        boolean update = this.updateById(taskInfo);
        return update ? CommonResult.success("更新成功") : CommonResult.error("更新失败");
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public CommonResult deleteTask(HttpServletRequest request, TaskInfoVo taskInfoVo) throws Exception {
        //获取用户信息，判断身份类型是否为教师
        UserInfoDto userInfoDto = SessionUtil.getUserFromSession(request);
        if (!Integer.valueOf(1).equals(userInfoDto.getUserType()) || ObjectUtil.isNull(userInfoDto.getTeacherInfo())) {
            return CommonResult.error("用户没有权限操作");
        }
        //查询要删除的信息是否存在
        LambdaQueryWrapper<TaskInfo> queryWrapper = new LambdaQueryWrapper<TaskInfo>()
                .in(TaskInfo::getId, taskInfoVo.getIdList())
                .eq(TaskInfo::getRelationTeacherId, userInfoDto.getTeacherInfo().getId());
        List<TaskInfo> list = this.list(queryWrapper);
        if (CollUtil.isEmpty(list)) {
            return CommonResult.error("任务信息不存在");
        }
        if (list.size() != taskInfoVo.getIdList().size()) {
            return CommonResult.error("任务信息数量异常");
        }
        //删除任务对应的评分信息
        LambdaQueryWrapper<TaskGrade> taskGradeLambdaQueryWrapper = new LambdaQueryWrapper<TaskGrade>()
                .in(TaskGrade::getRelationTaskId, taskInfoVo.getIdList());
        boolean remove = taskGradeService.remove(taskGradeLambdaQueryWrapper);
        if (!remove) {
            return CommonResult.error("删除任务评分失败");
        }
        //删除任务信息
        boolean update = this.removeByIds(taskInfoVo.getIdList());
        if (!update) {
            throw new Exception("删除任务信息失败");
        }
        return CommonResult.success("删除任务信息成功");
    }

    @Override
    public CommonResult getTaskDetail(HttpServletRequest request, TaskInfoVo taskInfoVo) {
        //查询任务信息，判断是否存在
        TaskInfo taskInfo = this.getById(taskInfoVo.getId());
        if (ObjectUtil.isNull(taskInfo)) {
            return CommonResult.error("任务信息不存在");
        }
        //查询任务对应的评分信息
        LambdaQueryWrapper<TaskGrade> queryWrapper = new LambdaQueryWrapper<>();
        LambdaQueryWrapper<TaskGrade> taskGradeLambdaQueryWrapper = queryWrapper.eq(TaskGrade::getRelationTaskId, taskInfoVo.getId());
        List<TaskGrade> list = taskGradeService.list(taskGradeLambdaQueryWrapper);
        TaskInfoDto taskInfoDto = new TaskInfoDto();
        //用列表中的分数计算平均分 for循环 获取总分
        if (CollUtil.isNotEmpty(list)) {
            Double score = 0d;
            for (int i = 0; i < list.size(); i++) {
                TaskGrade taskGrade = list.get(i);
                score = score + Double.valueOf(taskGrade.getScore());
            }
            score = score / list.size();
            taskInfoDto.setScoreAverage(score.toString());
        }
        //填充属性
        BeanUtil.copyProperties(taskInfo,taskInfoDto);
        return CommonResult.success("查询任务详情成功",taskInfoDto);
    }


}
