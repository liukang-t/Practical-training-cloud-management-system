package com.example.demo.po;

import com.baomidou.mybatisplus.annotation.*;

import java.util.Date;
import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 学生日报表
 * </p>
 *
 * @author mp
 * @since 2023-11-23
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class DailyReport implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 日报id
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 关联学生id
     */
    @TableField("relation_student_id")
    private Integer relationStudentId;

    /**
     * 工作概述
     */
    @TableField("content")
    private String content;

    /**
     * 存在的问题
     */
    @TableField("problem")
    private String problem;

    /**
     * 创建时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd")
    @TableField(value = "create_time", fill = FieldFill.INSERT)
    private Date createTime;

    /**
     * 更新时间
     */
    @TableField(value = "update_time", fill = FieldFill.UPDATE)
    private Date updateTime;

    /**
     * 关联班级id
     */
    @TableField("relation_class_id")
    private Integer relationClassId;

    /**
     * 评论内容
     */
    @TableField("comment")
    private String comment;

    /**
     * 逻辑删除：0=未删除，1=删除
     */
    @TableLogic
    @TableField(value = "deleted",fill = FieldFill.INSERT)
    private Integer deleted;


}
