package com.example.demo.vo;

import lombok.Data;

import java.util.List;

@Data
public class ClassInfoVo extends BaseVo{
/*    className: '',
    departmentName: '',
    schoolName: '',
    counselor: '',
    counselorTelephone: '',
    practiceTitle: '',
    practiceContent: ''*/

    /**
     * 班级名称
     */
    private String className;

    /**
     * 院系名称
     */
    private String departmentName;

    /**
     * 学校名称
     */
    private String schoolName;

    /**
     * 辅导员
     */
    private String counselor;

    /**
     * 辅导员电话号码
     */
    private String counselorTelephone;


    /**
     * 实训标题
     */
    private String practiceTitle;

    /**
     * 实训内容
     */
    private String practiceContent;


    /**
     * id列表
     */
    private List<Integer> idList;
}
