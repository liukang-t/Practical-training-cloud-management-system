package com.example.demo.dto;

import lombok.Data;

@Data
public class StudentVideoInfoDto {

    private Integer studentId;

    private String studentName;

    private String className;

    /**
     * 学校名称
     */
    private String schoolName;

    /**
     * 院系名称
     */
    private String departmentName;

    private Integer videoCount;
}
