package com.example.demo.po;

import com.baomidou.mybatisplus.annotation.*;

import java.util.Date;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 班级表
 * </p>
 *
 * @author mp
 * @since 2023-10-25
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class ClassInfo implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 编号
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 创建人
     */
    @TableField("create_by")
    private Integer createBy;

    /**
     * 创建时间
     */
    @TableField(value = "create_time", fill = FieldFill.INSERT)
    private Date createTime;

    /**
     * 更新人
     */
    @TableField("update_by")
    private Integer updateBy;

    /**
     * 更新时间
     */
    @TableField(value = "update_time", fill = FieldFill.UPDATE)
    private Date updateTime;

    /**
     * 删除 0-未删除 1-已删除
     */
    @TableLogic
    @TableField(value = "deleted",fill = FieldFill.INSERT)
    private Integer deleted;

    /**
     * 关联教师表id
     */
    @TableField("relation_teacher_id")
    private Integer relationTeacherId;

    /**
     * 班级名称
     */
    @TableField("class_name")
    private String className;

    /**
     * 院系名称
     */
    @TableField("department_name")
    private String departmentName;

    /**
     * 学校名称
     */
    @TableField("school_name")
    private String schoolName;


    /**
     * 实训标题
     */
    @TableField("practice_title")
    private String practiceTitle;

    /**
     * 实训内容
     */
    @TableField("practice_content")
    private String practiceContent;

    /**
     * 辅导员名称
     */
    @TableField("counselor")
    private String counselor;

    /**
     * 辅导员电话
     */
    @TableField("counselor_telephone")
    private String counselorTelephone;


}
