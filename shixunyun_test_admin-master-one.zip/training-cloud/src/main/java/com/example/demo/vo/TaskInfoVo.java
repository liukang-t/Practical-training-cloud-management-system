package com.example.demo.vo;

import lombok.Data;

import java.util.Date;
import java.util.List;

@Data
public class TaskInfoVo extends BaseVo{

    /**
     * 任务名称
     */
    private String taskName;

    /**
     * 任务内容
     */
    private String content;

    /**
     * 开始时间
     */
    private Date startTime;

    /**
     * 结束时间
     */
    private Date endTime;

    /**
     * 关联的班级id
     */
    private Integer relationClassId;

    /**
     * id
     */
    private List<Integer> idList;
}
