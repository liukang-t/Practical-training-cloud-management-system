package com.example.demo.controller;


import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import com.example.demo.beans.CommonResult;
import com.example.demo.po.ClassInfo;
import com.example.demo.service.ClassInfoService;
import com.example.demo.vo.ClassInfoVo;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

/**
 * <p>
 * 班级表 前端控制器
 * </p>
 *
 * @author mp
 * @since 2023-10-25
 */
@RestController
@RequestMapping("/classInfo")
public class ClassInfoController {

    @Resource
    private ClassInfoService classInfoService;

    @PostMapping("/add")
    public CommonResult addClass(HttpServletRequest request, @RequestBody ClassInfoVo classInfoVo){
        //参数校验
        if (ObjectUtil.isNull(classInfoVo)){
            return CommonResult.error("参数不能为空");
        }
        if (StrUtil.isBlank(classInfoVo.getClassName())){
            return CommonResult.error("班级名称不能为空");
        }
        if (StrUtil.isBlank(classInfoVo.getPracticeTitle())){
            return CommonResult.error("实训的标题不能为空");
        }
        if (StrUtil.isBlank(classInfoVo.getPracticeContent())){
            return CommonResult.error("实训的内容不能为空");
        }
        return classInfoService.addClass(request,classInfoVo);
    }

    @GetMapping("/getClassList")
    public CommonResult getClassList(HttpServletRequest request,ClassInfoVo classInfoVo){
      //参数校验
        if (ObjectUtil.isNull(classInfoVo)){
            return CommonResult.error("参数不能为空");
        }
        return classInfoService.getClassList(request,classInfoVo);
    }

    @PostMapping("/modify")
    public CommonResult modifyClass(HttpServletRequest request,@RequestBody ClassInfoVo classInfoVo){
        if (ObjectUtil.isNull(classInfoVo)){
            return CommonResult.error("参数不能为空");
        }
        if (ObjectUtil.isNull(classInfoVo.getId())){
            return CommonResult.error("id不能为空");
        }
        if (StrUtil.isBlank(classInfoVo.getClassName())){
            return CommonResult.error("班级名称不能为空");
        }
        if (StrUtil.isBlank(classInfoVo.getPracticeTitle())){
            return CommonResult.error("实训标题不能为空");
        }
        if (StrUtil.isBlank(classInfoVo.getPracticeContent())){
            return CommonResult.error("实训的内容不能为空");
        }
        return classInfoService.modifyClass(request,classInfoVo);
    }

    @PostMapping("/deleted")
    public CommonResult deletedClass(HttpServletRequest request,@RequestBody ClassInfoVo classInfoVo){
        CommonResult result = null;
        if (ObjectUtil.isNull(classInfoVo)){
            return CommonResult.error("参数不能为空");
        }
        if (CollUtil.isEmpty(classInfoVo.getIdList())){
            return CommonResult.error("id不能为空");
        }
        try {
           result = classInfoService.deletedClass(request,classInfoVo);
        } catch (Exception e) {
            return CommonResult.error("删除班级失败");
        }
        return result;
    }

    @GetMapping("/getClassInfo")
    public CommonResult getClassInfo(HttpServletRequest request){
        return classInfoService.getClassInfo(request);
    }
}

