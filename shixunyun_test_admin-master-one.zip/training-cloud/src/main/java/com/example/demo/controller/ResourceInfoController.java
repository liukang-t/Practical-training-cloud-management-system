package com.example.demo.controller;


import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import com.example.demo.beans.CommonResult;
import com.example.demo.service.ResourceInfoService;
import com.example.demo.vo.ResourceInfoVo;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

/**
 * <p>
 * 资源表 前端控制器
 * </p>
 *
 * @author mp
 * @since 2023-11-17
 */
@RestController
@RequestMapping("/resourceInfo")
public class ResourceInfoController {

    @Resource
    ResourceInfoService resourceInfoService;

    @PostMapping("/addResource")
    public CommonResult addResource(HttpServletRequest request, @RequestBody ResourceInfoVo resourceInfoVo) {
        if (ObjectUtil.isNull(resourceInfoVo)) {
            return CommonResult.error("参数不能为空");
        }
        if (StrUtil.isBlank(resourceInfoVo.getResourceName())) {
            return CommonResult.error("资源名称不能为空");
        }
        if (StrUtil.isBlank(resourceInfoVo.getResourceUrl())) {
            return CommonResult.error("资源链接不能为空");
        }
        if (ObjectUtil.isNull(resourceInfoVo.getRelationClassId())) {
            return CommonResult.error("关联的班级id不能为空");
        }
        return resourceInfoService.addResource(request, resourceInfoVo);
    }

    @GetMapping("/getResourceList")
    public CommonResult getResourceList(HttpServletRequest request, ResourceInfoVo resourceInfoVo) {
        if (ObjectUtil.isNull(resourceInfoVo)) {
            return CommonResult.error("参数不能为空");
        }
        if (resourceInfoVo.getPage() == null || resourceInfoVo.getPage() < 0){
            return CommonResult.error("页码不能为空");
        }
        if (resourceInfoVo.getSize() == null || resourceInfoVo.getSize() <0){
            return CommonResult.error("每页条数不能为空");
        }
        return resourceInfoService.getResourceList(request,resourceInfoVo);
    }

    @PostMapping("/modifyResource")
    public CommonResult modifyResource(HttpServletRequest request,@RequestBody ResourceInfoVo resourceInfoVo){
        //参数校验
        if (ObjectUtil.isNull(resourceInfoVo)){
            return CommonResult.error("参数不能为空");
        }
        //id
        if (ObjectUtil.isNull(resourceInfoVo.getId())){
            return CommonResult.error("资源id不能为空");
        }
        if (StrUtil.isBlank(resourceInfoVo.getResourceName())){
            return CommonResult.error("资源名称不能为空");
        }
        if (StrUtil.isBlank(resourceInfoVo.getResourceUrl())){
            return CommonResult.error("资源链接不能为空");
        }
        if (ObjectUtil.isNull(resourceInfoVo.getRelationClassId())){
            return CommonResult.error("班级id不能为空");
        }
        return resourceInfoService.modifyResource(request,resourceInfoVo);
    }

    @PostMapping("/deleteResource")
    public CommonResult deleteResource(HttpServletRequest request,@RequestBody ResourceInfoVo resourceInfoVo){
        //参数校验
        if (ObjectUtil.isNull(resourceInfoVo)){
            return CommonResult.error("参数不能为空");
        }
        if (CollUtil.isEmpty(resourceInfoVo.getIdList())){
            return CommonResult.error("id列表不能为空");
        }
        return resourceInfoService.deleteResource(request,resourceInfoVo);
    }
}

