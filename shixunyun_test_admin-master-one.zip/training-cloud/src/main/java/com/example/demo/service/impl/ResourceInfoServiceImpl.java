package com.example.demo.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.demo.beans.CommonResult;
import com.example.demo.dto.ResourceInfoDto;
import com.example.demo.dto.UserInfoDto;
import com.example.demo.po.ResourceInfo;
import com.example.demo.dao.ResourceInfoMapper;
import com.example.demo.service.ResourceInfoService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.demo.utils.SessionUtil;
import com.example.demo.utils.UploadFileUtil;
import com.example.demo.vo.ResourceInfoVo;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * <p>
 * 资源表 服务实现类
 * </p>
 *
 * @author mp
 * @since 2023-11-17
 */
@Service
public class ResourceInfoServiceImpl extends ServiceImpl<ResourceInfoMapper, ResourceInfo> implements ResourceInfoService {

    @Override
    public CommonResult addResource(HttpServletRequest request, ResourceInfoVo resourceInfoVo) {
        //获取登录用户的信息，判断身份是否为教师
        UserInfoDto userInfoDto = SessionUtil.getUserFromSession(request);
        if (!Integer.valueOf(1).equals(userInfoDto.getUserType()) || ObjectUtil.isNull(userInfoDto.getTeacherInfo())) {
            return CommonResult.error("用户没有权限操作");
        }
        //创建对象，并且填充信息
        ResourceInfo resourceInfo = new ResourceInfo();
        resourceInfo.setResourceName(resourceInfoVo.getResourceName());
        //对资源的链接处理 获取文件在磁盘内的路径
        String filePath = UploadFileUtil.getFilePath(resourceInfoVo.getResourceUrl());
        resourceInfo.setResourceUrl(filePath);
        resourceInfo.setRelationClassId(resourceInfoVo.getRelationClassId());
        resourceInfo.setRelationTeacherId(userInfoDto.getTeacherInfo().getId());
        resourceInfo.setResourceDescription(resourceInfoVo.getResourceDescription());
        resourceInfo.setCreateBy(userInfoDto.getId());
        //插入信息到数据库
        boolean save = this.save(resourceInfo);
        return save ? CommonResult.success("保存资源成功") : CommonResult.error("保存资源失败");
    }

    @Override
    public CommonResult getResourceList(HttpServletRequest request, ResourceInfoVo resourceInfoVo) {
        //获取当前登录用户身份
        UserInfoDto userInfoDto = SessionUtil.getUserFromSession(request);
        //分页构造器 查询条件构造器
        Page<ResourceInfo> page = new Page<>(resourceInfoVo.getPage(), resourceInfoVo.getSize());
        LambdaQueryWrapper<ResourceInfo> queryWrapper = new LambdaQueryWrapper<>();
        //放置查询条件
        if (Integer.valueOf(1).equals(userInfoDto.getUserType())) {
            queryWrapper.eq(ResourceInfo::getRelationTeacherId, userInfoDto.getTeacherInfo().getId());
            if (ObjectUtil.isNotNull(resourceInfoVo.getRelationClassId())){
                queryWrapper.eq(ResourceInfo::getRelationClassId,resourceInfoVo.getRelationClassId());
            }
        } else {
            queryWrapper.eq(ResourceInfo::getRelationClassId, userInfoDto.getStudentInfo().getRelationClassId());
        }
        //分页查询
        IPage<ResourceInfo> resourceInfoPage = this.page(page, queryWrapper);
        //循环列表 对数据进行处理 磁盘链接转换为下载链接 fileName
        ArrayList<ResourceInfoDto> resourceInfoDtos = new ArrayList<>();
        if (resourceInfoPage.getRecords() != null && resourceInfoPage.getRecords().size() > 0){
            for (int i = 0; i < resourceInfoPage.getRecords().size(); i++) {
                ResourceInfo resourceInfo = resourceInfoPage.getRecords().get(i);
                ResourceInfoDto resourceInfoDto = new ResourceInfoDto();
                BeanUtil.copyProperties(resourceInfo,resourceInfoDto);
                //获取文件名称
                String fileName = StrUtil.subAfter(resourceInfoDto.getResourceUrl(), '/', true);
                resourceInfoDto.setFileName(fileName);
                //获取下载路径
                String downloadUrl = UploadFileUtil.getDownloadUrl(resourceInfoDto.getResourceUrl(), "8084");
                resourceInfoDto.setResourceUrl(downloadUrl);
                resourceInfoDtos.add(resourceInfoDto);
            }
        }
        //创建返回结果
        HashMap<String, Object> map = new HashMap<>();
        map.put("total",resourceInfoPage.getTotal());
        map.put("list",resourceInfoDtos);
        map.put("pages",resourceInfoPage.getPages());
        return CommonResult.success("查询资源列表成功",map);
    }

    @Override
    public CommonResult modifyResource(HttpServletRequest request, ResourceInfoVo resourceInfoVo) {
        //获取当前登录用户的身份，判断是否为教师
        UserInfoDto userInfoDto = SessionUtil.getUserFromSession(request);
        if (!Integer.valueOf(1).equals(userInfoDto.getUserType()) || ObjectUtil.isNull(userInfoDto.getTeacherInfo())){
            return CommonResult.error("用户没有操作权限");
        }
        //查询资源是否存在，判断资源是否由当前用户上传
        ResourceInfo resourceInfo = this.getById(resourceInfoVo.getId());
        if (ObjectUtil.isNull(resourceInfo)){
            return CommonResult.error("资源信息不存在");
        }
        if (!userInfoDto.getTeacherInfo().getId().equals(resourceInfo.getRelationTeacherId())){
            return CommonResult.error("资源不是当前用户上传");
        }
        //判断文件是否修改，删除原文件
        String filePath = UploadFileUtil.getFilePath(resourceInfoVo.getResourceUrl());
        if (!filePath.equals(resourceInfo.getResourceUrl())){
            Boolean deleteFile = UploadFileUtil.deleteFile(resourceInfo.getResourceUrl());
            if (!deleteFile){
                return CommonResult.error("文件删除失败");
            }
        }
        //更新到数据库
        resourceInfo.setResourceName(resourceInfoVo.getResourceName());
        resourceInfo.setResourceUrl(filePath);
        resourceInfo.setResourceDescription(resourceInfoVo.getResourceDescription());
        resourceInfo.setRelationClassId(resourceInfoVo.getRelationClassId());
        resourceInfo.setUpdateBy(userInfoDto.getId());
        boolean update = this.updateById(resourceInfo);
        return update ? CommonResult.success("编辑资源成功"):CommonResult.error("更新资源失败");
    }

    @Override
    public CommonResult deleteResource(HttpServletRequest request, ResourceInfoVo resourceInfoVo) {
        //获取用户信息，判断身份
        UserInfoDto userInfoDto = SessionUtil.getUserFromSession(request);
        if (!Integer.valueOf(1).equals(userInfoDto.getUserType()) || ObjectUtil.isNull(userInfoDto.getTeacherInfo())){
            return CommonResult.error("用户没有权限操作");
        }
        //查询要删除的信息，判断是否存在
        LambdaQueryWrapper<ResourceInfo> queryWrapper = new LambdaQueryWrapper<ResourceInfo>()
                .eq(ResourceInfo::getRelationTeacherId, userInfoDto.getTeacherInfo().getId())
                .in(ResourceInfo::getId, resourceInfoVo.getIdList());
        List<ResourceInfo> list = this.list(queryWrapper);
        if (CollUtil.isEmpty(list)){
            return CommonResult.error("要删除的信息不存在");
        }
        if (list.size() != resourceInfoVo.getIdList().size()){
            return CommonResult.error("要删除的信息数量异常");
        }
        //批量删除数据
        boolean removed = this.removeByIds(resourceInfoVo.getIdList());
        if (!removed){
            return CommonResult.error("删除失败");
        }
        //删除掉数据后，删除磁盘内的文件
        for (int i = 0; i < list.size(); i++) {
            ResourceInfo resourceInfo = list.get(i);
            UploadFileUtil.deleteFile(resourceInfo.getResourceUrl());
        }
        return CommonResult.success("删除资源成功");
    }
}
