package com.example.demo.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.util.ObjectUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.example.demo.beans.CommonResult;
import com.example.demo.dao.UserInfoMapper;
import com.example.demo.dto.StudentInfoDto;
import com.example.demo.dto.UserInfoDto;
import com.example.demo.po.StudentInfo;
import com.example.demo.dao.StudentInfoMapper;
import com.example.demo.po.UserInfo;
import com.example.demo.service.StudentInfoService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.demo.utils.PasswordCryptoTool;
import com.example.demo.utils.SessionUtil;
import com.example.demo.vo.StudentInfoVo;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

/**
 * <p>
 * 学生 服务实现类
 * </p>
 *
 * @author mp
 * @since 2023-10-25
 */
@Service
public class StudentInfoServiceImpl extends ServiceImpl<StudentInfoMapper, StudentInfo> implements StudentInfoService {

    @Resource
    UserInfoMapper userInfoMapper;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public CommonResult addStudent(HttpServletRequest request, StudentInfoVo studentInfoVo) throws Exception {
        //判断当前用户的身份，是否为教师
        UserInfoDto userInfoDto = SessionUtil.getUserFromSession(request);
        if (!Integer.valueOf(1).equals(userInfoDto.getUserType()) || ObjectUtil.isNull(userInfoDto.getTeacherInfo())) {
            return CommonResult.error("没有权限操作");
        }
        //查询账号是否存在 根据用户的账号 和 账号的状态
        LambdaQueryWrapper<UserInfo> lambdaQueryWrapper = new LambdaQueryWrapper<UserInfo>()
                .eq(UserInfo::getAccountNumber, studentInfoVo.getStudentNumber())
                .eq(UserInfo::getUserStatus, 0);
        UserInfo userInfo = userInfoMapper.selectOne(lambdaQueryWrapper);
        if (ObjectUtil.isNotNull(userInfo)) {
            return CommonResult.error("账号已存在");
        }
        //新建用户信息对象,填充参数
        UserInfo addUserInfo = new UserInfo();
        addUserInfo.setAccountNumber(studentInfoVo.getStudentNumber());
        //密码是学号的后六位
        String password = null;
        int length = studentInfoVo.getStudentNumber().length();
        if (length <= 6) {
            password = PasswordCryptoTool.encryptPassword(studentInfoVo.getStudentNumber());
        } else {
            password = PasswordCryptoTool.encryptPassword(studentInfoVo.getStudentNumber().substring(length - 6));
        }
        addUserInfo.setPassword(password);
        addUserInfo.setNick(studentInfoVo.getStudentName());
        addUserInfo.setUserStatus(0);
        addUserInfo.setUserType(2);
        addUserInfo.setCreateBy(userInfoDto.getId());
        //插入用户信息，并且判断是否插入成功
        int insert = userInfoMapper.insert(addUserInfo);
        if (insert < 1) {
            return CommonResult.error("插入用户信息失败");
        }
        //创建学生信息对象，属性赋值
        StudentInfo studentInfo = new StudentInfo();
        BeanUtil.copyProperties(studentInfoVo, studentInfo);
        studentInfo.setRelationUserId(addUserInfo.getId());
        studentInfo.setCreateTime(new Date());
        studentInfo.setCreateBy(userInfoDto.getId());
        studentInfo.setDeleted(0);
        //插入学生信息
        int addNum = this.baseMapper.addStudent(studentInfo);
        if (addNum <= 0) {
            throw new Exception("插入学生信息失败");
        }
        return CommonResult.success("插入学生信息成功");
    }

    @Override
    public CommonResult selectStudentList(HttpServletRequest request, StudentInfoVo studentInfoVo) {
        //判断当前登录用户的身份
        UserInfoDto userInfoDto = SessionUtil.getUserFromSession(request);
        if (!Integer.valueOf(1).equals(userInfoDto.getUserType()) || ObjectUtil.isNull(userInfoDto.getTeacherInfo())) {
            return CommonResult.error("没有权限操作");
        }
        //设置关联的教师id
        studentInfoVo.setRelationTeacherId(userInfoDto.getTeacherInfo().getId());
        //使用sql的方式实现分页查询学生信息
        Integer total = this.baseMapper.countStudent(studentInfoVo);
        List<StudentInfoDto> list = this.baseMapper.pageStudent(studentInfoVo);
        //返回结果
        HashMap<String, Object> map = new HashMap<>();
        map.put("total", total);
        map.put("list", list);
        return CommonResult.success("查询成功", map);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public CommonResult modifyStudent(HttpServletRequest request, StudentInfoVo studentInfoVo) throws Exception {
        //判断登录的用户身份，是否为教师
        UserInfoDto userInfoDto = SessionUtil.getUserFromSession(request);
        if (!Integer.valueOf(1).equals(userInfoDto.getUserType()) || ObjectUtil.isNull(userInfoDto.getTeacherInfo())) {
            return CommonResult.error("用户没有权限操作");
        }
        //设置查询条件 关联的教师id
        studentInfoVo.setRelationTeacherId(userInfoDto.getTeacherInfo().getId());
        //查询当前要修改的学生信息是否存在
        StudentInfo studentInfo = this.baseMapper.selectStudent(studentInfoVo);
        if (ObjectUtil.isNull(studentInfo)) {
            return CommonResult.error("学生信息不存在");
        }
        //更新用户信息,如果有更新学号
        if (!studentInfoVo.getStudentNumber().equals(studentInfo.getStudentNumber())) {
            //判断学号是否重复
            LambdaQueryWrapper<UserInfo> queryWrapper = new LambdaQueryWrapper<UserInfo>()
                    .eq(UserInfo::getAccountNumber, studentInfoVo.getStudentNumber());
            UserInfo userInfo = userInfoMapper.selectOne(queryWrapper);
            if (ObjectUtil.isNotNull(userInfo)) {
                return CommonResult.error("账号已存在");
            }
            //创建userInfo对象，填充属性
            UserInfo updateUserInfo = new UserInfo();
            updateUserInfo.setAccountNumber(studentInfoVo.getStudentNumber());
            updateUserInfo.setId(studentInfo.getRelationUserId());
            updateUserInfo.setUpdateBy(userInfoDto.getId());
            //修改账号密码
            String password = null;
            int length = studentInfoVo.getStudentNumber().length();
            if (length <= 6) {
                password = PasswordCryptoTool.encryptPassword(studentInfoVo.getStudentNumber());
            } else {
                password = PasswordCryptoTool.encryptPassword(studentInfoVo.getStudentNumber().substring(length - 6));
            }
            updateUserInfo.setPassword(password);
            int update = userInfoMapper.updateById(updateUserInfo);
            if (update < 1) {
                return CommonResult.error("更新用户信息失败");
            }
        }
        //更新学生信息
        StudentInfo updateStudentInfo = new StudentInfo();
        BeanUtil.copyProperties(studentInfoVo, updateStudentInfo);
        //设置更新人的id
        updateStudentInfo.setUpdateBy(userInfoDto.getId());
        updateStudentInfo.setUpdateTime(new Date());
        Integer updateStudent = this.baseMapper.updateStudent(updateStudentInfo);
        if (updateStudent < 1) {
            throw new Exception("更新学生信息失败");
        }

        return CommonResult.success("更新成功");
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public CommonResult deleteStudent(HttpServletRequest request, StudentInfoVo studentInfoVo) throws Exception {
        //判断登录用户的身份类型，判断用户身份类型 是否为教师
        UserInfoDto userInfoDto = SessionUtil.getUserFromSession(request);
        if (!Integer.valueOf(1).equals(userInfoDto.getUserType()) || ObjectUtil.isNull(userInfoDto.getTeacherInfo())) {
            return CommonResult.error("用户没有权限");
        }
        //查询要删除的信息是否存在
        studentInfoVo.setRelationTeacherId(userInfoDto.getTeacherInfo().getId());
        List<StudentInfoDto> list = this.baseMapper.pageStudent(studentInfoVo);
        //判断要删除信息的数量
        if (studentInfoVo.getIdList().size() != list.size()) {
            return CommonResult.error("要删除的数量异常");
        }
        //删除信息
        Integer deleteStudent = this.baseMapper.deleteStudent(studentInfoVo);
        if (deleteStudent != studentInfoVo.getIdList().size()) {
            throw new Exception("删除学生信息失败");
        }
        //获取用户信息的id列表
        List<Integer> userIds = new ArrayList<>();
        for (int i = 0; i < list.size(); i++) {
            userIds.add(list.get(i).getRelationUserId());
        }
        //更新用户新的注销状态
        LambdaUpdateWrapper<UserInfo> updateWrapper = new LambdaUpdateWrapper<UserInfo>()
                .set(UserInfo::getUserStatus, 1)
                .in(UserInfo::getId, userIds);
        int update = userInfoMapper.update(new UserInfo(), updateWrapper);
        if (update != deleteStudent){
            throw  new Exception("用户账号注销失败");
        }
        return CommonResult.success("删除学生信息成功");
    }
}
