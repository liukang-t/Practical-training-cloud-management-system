package com.example.demo.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 教师表 前端控制器
 * </p>
 *
 * @author mp
 * @since 2023-10-25
 */
@RestController
@RequestMapping("/teacherInfo")
public class TeacherInfoController {

}

