package com.example.demo.dao;

import com.example.demo.dto.StudentInfoDto;
import com.example.demo.po.StudentInfo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.demo.vo.StudentInfoVo;

import java.util.List;

/**
 * <p>
 * 学生 Mapper 接口
 * </p>
 *
 * @author mp
 * @since 2023-10-25
 */
public interface StudentInfoMapper extends BaseMapper<StudentInfo> {

    int addStudent(StudentInfo studentInfo);

    Integer countStudent(StudentInfoVo studentInfoVo);

    List<StudentInfoDto> pageStudent(StudentInfoVo studentInfoVo);

    StudentInfo selectStudent(StudentInfoVo studentInfoVo);

    Integer updateStudent(StudentInfo updateStudentInfo);

    Integer deleteStudent(StudentInfoVo studentInfoVo);
}
