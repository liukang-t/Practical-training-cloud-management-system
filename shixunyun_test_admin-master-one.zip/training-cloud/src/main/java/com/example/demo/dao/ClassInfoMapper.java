package com.example.demo.dao;

import com.example.demo.po.ClassInfo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 班级表 Mapper 接口
 * </p>
 *
 * @author mp
 * @since 2023-10-25
 */
public interface ClassInfoMapper extends BaseMapper<ClassInfo> {

}
