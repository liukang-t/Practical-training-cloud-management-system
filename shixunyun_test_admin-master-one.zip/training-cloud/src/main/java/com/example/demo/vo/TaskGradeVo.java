package com.example.demo.vo;

import lombok.Data;

@Data
public class TaskGradeVo extends BaseVo{
    /**
     * 任务id
     */
    private Integer taskId;

    /**
     * 学生id
     */
    private Integer studentId;

    /**
     * 分数
     */
    private String score;

    /**
     * 关联的班级id
     */
    private Integer relationClassId;
}
