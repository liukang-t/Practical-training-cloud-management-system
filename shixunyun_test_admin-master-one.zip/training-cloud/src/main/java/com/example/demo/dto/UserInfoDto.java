package com.example.demo.dto;

import com.example.demo.po.StudentInfo;
import com.example.demo.po.TeacherInfo;
import com.example.demo.po.UserInfo;
import lombok.Data;

@Data
public class UserInfoDto extends UserInfo {

    private TeacherInfo teacherInfo;

    private StudentInfo studentInfo;
}
