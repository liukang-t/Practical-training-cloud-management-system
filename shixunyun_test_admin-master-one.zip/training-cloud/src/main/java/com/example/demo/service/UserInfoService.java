package com.example.demo.service;

import cn.hutool.http.server.HttpServerRequest;
import com.example.demo.beans.CommonResult;
import com.example.demo.po.UserInfo;
import com.baomidou.mybatisplus.extension.service.IService;
import com.example.demo.vo.UserInfoVo;

import javax.servlet.http.HttpServletRequest;

/**
 * <p>
 * 用户表 服务类
 * </p>
 *
 * @author mp
 * @since 2023-10-25
 */
public interface UserInfoService extends IService<UserInfo> {

    CommonResult register(HttpServerRequest request, UserInfoVo userInfoVo) throws Exception;

    CommonResult login(HttpServletRequest request, UserInfoVo userInfoVo);

    CommonResult changePassword(HttpServletRequest request, UserInfoVo userInfoVo);

    CommonResult changeAvatar(HttpServletRequest request, UserInfoVo userInfoVo);

    CommonResult changeUserInfo(HttpServletRequest request, UserInfoVo userInfoVo);
}
