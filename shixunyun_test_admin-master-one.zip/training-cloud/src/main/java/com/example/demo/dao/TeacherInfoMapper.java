package com.example.demo.dao;

import com.example.demo.po.TeacherInfo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 教师表 Mapper 接口
 * </p>
 *
 * @author mp
 * @since 2023-10-25
 */
public interface TeacherInfoMapper extends BaseMapper<TeacherInfo> {

}
