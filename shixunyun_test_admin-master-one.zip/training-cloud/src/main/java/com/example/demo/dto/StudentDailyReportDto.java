package com.example.demo.dto;

import lombok.Data;

import java.util.Date;

@Data
public class StudentDailyReportDto {

    /**
     * 学生id
     */
    private Integer studentId;

    /**
     * 学生名称
     */
    private String studentName;

    /**
     * 学生学号
     */
    private String studentNumber;

    /**
     * 学校名称
     */
    private String schoolName;

    /**
     * 院系名称
     */
    private String departmentName;

    /**
     * 班级名称
     */
    private String className;

    /**
     * 最新提交时间
     */
    private Date lastCommitTime;

    /**
     * 提交次数
     */
    private Integer commitCount;
}
