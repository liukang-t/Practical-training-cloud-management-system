package com.example.demo.po;

import com.baomidou.mybatisplus.annotation.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 用户表
 * </p>
 *
 * @author mp
 * @since 2023-10-25
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class UserInfo implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 编号
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 创建人
     */
    @TableField("create_by")
    private Integer createBy;

    /**
     * 创建时间
     */
    @TableField(value = "create_time", fill = FieldFill.INSERT)
    private Date createTime;

    /**
     * 更新人
     */
    @TableField("update_by")
    private Integer updateBy;

    /**
     * 更新时间
     */
    @TableField(value = "update_time", fill = FieldFill.UPDATE)
    private Date updateTime;

    /**
     * 账号
     */
    @TableField("account_number")
    private String accountNumber;

    /**
     * 密码
     */
    @TableField("password")
    private String password;

    /**
     * 昵称
     */
    @TableField("nick")
    private String nick;

    /**
     * 用户状态 0-正常 1-注销
     */
    @TableField("user_status")
    private Integer userStatus;

    /**
     * 用户头像
     */
    @TableField("user_ava")
    private String userAva;

    /**
     * 用户类型 1-老师 2-学生
     */
    @TableField("user_type")
    private Integer userType;

    /**
     * 手机号
     */
    @TableField("user_phone")
    private String userPhone;

    /**
     * 邮箱
     */
    @TableField("user_email")
    private String userEmail;
}
