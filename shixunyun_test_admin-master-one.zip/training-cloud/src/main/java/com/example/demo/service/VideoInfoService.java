package com.example.demo.service;

import com.example.demo.beans.CommonResult;
import com.example.demo.po.VideoInfo;
import com.baomidou.mybatisplus.extension.service.IService;
import com.example.demo.vo.VideoInfoVo;

import javax.servlet.http.HttpServletRequest;

/**
 * <p>
 * 视频列表 服务类
 * </p>
 *
 * @author mp
 * @since 2023-12-13
 */
public interface VideoInfoService extends IService<VideoInfo> {

    CommonResult addVideoInfo(HttpServletRequest request, VideoInfoVo videoInfoVo);

    CommonResult getVideoList(HttpServletRequest request, VideoInfoVo videoInfoVo);

    CommonResult deleteVideoInfo(HttpServletRequest request, VideoInfoVo videoInfoVo);

    CommonResult getStudentVideoList(HttpServletRequest request, VideoInfoVo videoInfoVo);
}
