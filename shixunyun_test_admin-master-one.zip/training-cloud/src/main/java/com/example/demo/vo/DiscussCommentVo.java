package com.example.demo.vo;

import lombok.Data;

@Data
public class DiscussCommentVo extends BaseVo{

    /**
     * 关联的答疑id
     */
    private Integer relationDiscussId;

    /**
     * 关联的回复id
     */
    private Integer replyId;

    /**
     * 内容
     */
    private String content;

    /**
     * 文件路径
     */
    private String imgUrl;
}
