package com.example.demo.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.bean.copier.CopyOptions;
import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.ObjectUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.demo.beans.CommonResult;
import com.example.demo.dao.StudentInfoMapper;
import com.example.demo.dto.ClassInfoDto;
import com.example.demo.dto.UserInfoDto;
import com.example.demo.po.ClassInfo;
import com.example.demo.dao.ClassInfoMapper;
import com.example.demo.po.StudentInfo;
import com.example.demo.service.ClassInfoService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.demo.service.StudentInfoService;
import com.example.demo.utils.SessionUtil;
import com.example.demo.vo.ClassInfoVo;
import com.example.demo.vo.StudentInfoVo;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * <p>
 * 班级表 服务实现类
 * </p>
 *
 * @author mp
 * @since 2023-10-25
 */
@Service
public class ClassInfoServiceImpl extends ServiceImpl<ClassInfoMapper, ClassInfo> implements ClassInfoService {

    @Resource
    StudentInfoMapper studentInfoMapper;

    @Resource
    StudentInfoService studentInfoService;

    @Override
    public CommonResult addClass(HttpServletRequest request, ClassInfoVo classInfoVo) {
        //判断登录的用户身份是否为教师
        UserInfoDto userInfoDto = SessionUtil.getUserFromSession(request);
        if (!Integer.valueOf(1).equals(userInfoDto.getUserType()) || ObjectUtil.isNull(userInfoDto.getTeacherInfo())) {
            return CommonResult.error("用户的身份类型不等于教师");
        }
        //创建班级对象 并且使用BeanUtil进行属性复制 前面的是有属性的对象  后面是新建的对象
        ClassInfo classInfo = new ClassInfo();
        BeanUtil.copyProperties(classInfoVo, classInfo);
        //设置班级的教师id 和 创建人id
        classInfo.setRelationTeacherId(userInfoDto.getTeacherInfo().getId());
        classInfo.setCreateBy(userInfoDto.getId());
        //插入到数据库
        boolean save = this.save(classInfo);
        //返回结果
        return save ? CommonResult.success("操作成功") : CommonResult.error("操作失败");
    }

    @Override
    public CommonResult getClassList(HttpServletRequest request, ClassInfoVo classInfoVo) {
        //获取session中的用户信息,判断当前用户的身份是否为教师
        UserInfoDto userInfoDto = SessionUtil.getUserFromSession(request);
        if (!Integer.valueOf(1).equals(userInfoDto.getUserType()) || ObjectUtil.isNull(userInfoDto.getTeacherInfo())) {
            return CommonResult.error("当前用户无权限");
        }
        //新建一个查询构造器,条件是 关联的教师id  where realation_teacher_id = 1
        LambdaQueryWrapper<ClassInfo> queryWrapper = new LambdaQueryWrapper<ClassInfo>()
                .eq(ClassInfo::getRelationTeacherId, userInfoDto.getTeacherInfo().getId());
        //创建一个返回结果
        HashMap<String, Object> map = new HashMap<>();
        //判断是否有传page 页码 如果有使用分页查询 如果没有使用列表查询
        if (ObjectUtil.isNotNull(classInfoVo.getPage()) && classInfoVo.getPage() > 0) {
            //新建 一个 分页插件
            Page<ClassInfo> page = new Page<>(classInfoVo.getPage(), classInfoVo.getSize());
            //分页查询
            IPage<ClassInfo> infoIPage = this.page(page, queryWrapper);
            map.put("list", infoIPage.getRecords());
            map.put("total", infoIPage.getTotal());
            map.put("pages", infoIPage.getPages());
        } else {
            //列表查询
            List<ClassInfo> list = this.list(queryWrapper);
            map.put("list", list);
        }
        return CommonResult.success("查询成功", map);
    }

    @Override
    public CommonResult modifyClass(HttpServletRequest request, ClassInfoVo classInfoVo) {
        //判断当前对象身份是否为教师
        UserInfoDto userInfoDto = SessionUtil.getUserFromSession(request);
        if (!Integer.valueOf(1).equals(userInfoDto.getUserType()) || ObjectUtil.isNull(userInfoDto.getTeacherInfo())) {
            return CommonResult.error("用户没有操作权限");
        }
        //去数据库查询要修改的信息
        ClassInfo classInfo = this.getById(classInfoVo.getId());
        //判断班级的关联教师id不为当前登录用户的教师id  ==
        if (ObjectUtil.isNull(classInfo) || !userInfoDto.getTeacherInfo().getId().equals(classInfo.getRelationTeacherId())) {
            return CommonResult.error("该班级信息不是当前用户创建");
        }
        //把要更新的信息 填充 到 要更新到数据库的classinfo里面去 使用BeanUtil 配置忽略空值
        BeanUtil.copyProperties(classInfoVo, classInfo, CopyOptions.create().ignoreNullValue());
        classInfo.setUpdateBy(userInfoDto.getId());
        //更新数据到数据库
        boolean update = this.updateById(classInfo);
        return update ? CommonResult.success("更新成功") : CommonResult.error("更新失败");
    }

    @Override
    public CommonResult deletedClass(HttpServletRequest request, ClassInfoVo classInfoVo) throws Exception {
        CommonResult result = null;
        //判断用户的身份类型是否为教师
        UserInfoDto userInfoDto = SessionUtil.getUserFromSession(request);
        if (!Integer.valueOf(1).equals(userInfoDto.getUserType()) || ObjectUtil.isNull(userInfoDto.getTeacherInfo())) {
            return CommonResult.error("用户没有操作权限");
        }
        //查询要删除的记录是否存在  查询条件是 关联的教师id  和  班级idlist
        LambdaQueryWrapper<ClassInfo> queryWrapper = new LambdaQueryWrapper<ClassInfo>()
                .eq(ClassInfo::getRelationTeacherId, userInfoDto.getTeacherInfo().getId())
                .in(ClassInfo::getId, classInfoVo.getIdList());
        List<ClassInfo> list = this.list(queryWrapper);
        if (CollUtil.isEmpty(list)) {
            return CommonResult.error("要删除的信息不存在");
        }
        if (classInfoVo.getIdList().size() != list.size()) {
            return CommonResult.error("要删除的信息数量异常");
        }
        //删除学生信息,注销学生账号
        LambdaQueryWrapper<StudentInfo> studentInfoLambdaQueryWrapper = new LambdaQueryWrapper<StudentInfo>()
                .in(StudentInfo::getRelationClassId, classInfoVo.getIdList());
        List<StudentInfo> studentInfos = studentInfoService.list(studentInfoLambdaQueryWrapper);
        if (studentInfos != null && studentInfos.size() >0) {
            //创建学生id列表
            ArrayList<Integer> studentIds = new ArrayList<>();
            //循环学生信息列表，放置id
            for (int i = 0; i < studentInfos.size(); i++) {
                studentIds.add(studentInfos.get(i).getId());
            }
            StudentInfoVo studentInfoVo = new StudentInfoVo();
            studentInfoVo.setIdList(studentIds);
            result = studentInfoService.deleteStudent(request, studentInfoVo);
            if (result.getCode() != 200) {
                return result;
            }
        }
        //删除班级
        boolean removed = this.removeByIds(classInfoVo.getIdList());
        return removed ? CommonResult.success("删除成功") : CommonResult.error("删除失败");
    }

    @Override
    public CommonResult getClassInfo(HttpServletRequest request) {
//        1.获取当前登录用户身份，判断是否为学生
        UserInfoDto userInfoDto = SessionUtil.getUserFromSession(request);
        if (!Integer.valueOf(2).equals(userInfoDto.getUserType()) || ObjectUtil.isNull(userInfoDto.getStudentInfo())) {
            return CommonResult.error("用户没有权限");
        }
//        2.查询当前学生的班级信息
        ClassInfo classInfo = this.getById(userInfoDto.getStudentInfo().getRelationClassId());
//        3.查询当前学生班级内的人数
        LambdaQueryWrapper<StudentInfo> queryWrapper = new LambdaQueryWrapper<StudentInfo>()
                .eq(StudentInfo::getRelationClassId, classInfo.getId());
        Integer totalCount = studentInfoMapper.selectCount(queryWrapper);
        queryWrapper.eq(StudentInfo::getGender, 1);
        Integer nanCount = studentInfoMapper.selectCount(queryWrapper);
        Integer nvCount = 0;
        if (totalCount != null && nanCount != null) {
            nvCount = totalCount - nanCount;
        }
//        4. 创建返回结果，填充参数
        ClassInfoDto classInfoDto = new ClassInfoDto();
        BeanUtil.copyProperties(classInfo, classInfoDto);
        classInfoDto.setTotalCount(totalCount);
        classInfoDto.setNanCount(nanCount);
        classInfoDto.setNvCount(nvCount);
        return CommonResult.success("查询成功", classInfoDto);
    }
}
