package com.example.demo.controller;


import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import com.example.demo.beans.CommonResult;
import com.example.demo.service.VideoInfoService;
import com.example.demo.vo.VideoInfoVo;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

/**
 * <p>
 * 视频列表 前端控制器
 * </p>
 *
 * @author mp
 * @since 2023-12-13
 */
@RestController
@RequestMapping("/videoInfo")
public class VideoInfoController {

    @Resource
    VideoInfoService videoInfoService;


    @PostMapping("/addVideoInfo")
    public CommonResult addVideoInfo(HttpServletRequest request, @RequestBody VideoInfoVo videoInfoVo){
        //参数校验
        if (ObjectUtil.isNull(videoInfoVo)){
            return CommonResult.error("参数不能为空");
        }
        if (StrUtil.isBlank(videoInfoVo.getVideoName())){
            return CommonResult.error("视频名称不能为空");
        }
        if (StrUtil.isBlank(videoInfoVo.getVideoUrl())){
            return CommonResult.error("视频的链接不能为空");
        }
        return videoInfoService.addVideoInfo(request,videoInfoVo);
    }

    @GetMapping("/getVideoList")
    public CommonResult getVideoList(HttpServletRequest request,VideoInfoVo videoInfoVo){
        if (ObjectUtil.isNull(videoInfoVo)){
            return CommonResult.error("参数不能为空");
        }
        if (ObjectUtil.isNull(videoInfoVo.getPage()) || videoInfoVo.getPage() < 1){
            return CommonResult.error("页码不能为空");
        }
        if (ObjectUtil.isNull(videoInfoVo.getSize()) || videoInfoVo.getSize() < 1){
            return CommonResult.error("每页条数不能为空");
        }
        return videoInfoService.getVideoList(request,videoInfoVo);
    }

    @PostMapping("/deleteVideoInfo")
    public CommonResult deleteVideoInfo(HttpServletRequest request,@RequestBody VideoInfoVo videoInfoVo){
        if (ObjectUtil.isNull(videoInfoVo)){
            return CommonResult.error("参数不能为空");
        }
        if (CollUtil.isEmpty(videoInfoVo.getIdList())){
            return CommonResult.error("id列表不能为空");
        }
        return videoInfoService.deleteVideoInfo(request,videoInfoVo);
    }

    @GetMapping("/getStudentVideoList")
    public CommonResult getStudentVideoList(HttpServletRequest request,VideoInfoVo videoInfoVo){
        if (ObjectUtil.isNull(videoInfoVo)){
            return CommonResult.error("参数不能为空");
        }
        if (ObjectUtil.isNull(videoInfoVo.getPage()) || videoInfoVo.getPage() < 1){
            return CommonResult.error("页码不能为空");
        }
        if (ObjectUtil.isNull(videoInfoVo.getSize()) || videoInfoVo.getSize() < 1){
            return CommonResult.error("每页条数不能为空");
        }
        return videoInfoService.getStudentVideoList(request,videoInfoVo);
    }
}

