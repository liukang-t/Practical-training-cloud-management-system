package com.example.demo.dao;

import com.example.demo.dto.StudentVideoInfoDto;
import com.example.demo.po.VideoInfo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.demo.vo.VideoInfoVo;

import java.util.List;

/**
 * <p>
 * 视频列表 Mapper 接口
 * </p>
 *
 * @author mp
 * @since 2023-12-13
 */
public interface VideoInfoMapper extends BaseMapper<VideoInfo> {

    List<StudentVideoInfoDto> getStudentVideoList(VideoInfoVo videoInfoVo);

    Integer countStudentVideo(VideoInfoVo videoInfoVo);
}
