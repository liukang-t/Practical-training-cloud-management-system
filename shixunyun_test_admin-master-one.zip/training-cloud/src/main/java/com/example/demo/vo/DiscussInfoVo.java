package com.example.demo.vo;

import lombok.Data;

@Data
public class DiscussInfoVo extends BaseVo{

    /**
     * 答疑内容
     */
    private String content;

    /**
     * 文件上传路径
     */
    private String imgUrl;

    /**
     * 关联的班级id
     */
    private Integer relationClassId;

    /**
     * 删除的数据类型：1-答疑 2-回复
     */
    private Integer type;
}
