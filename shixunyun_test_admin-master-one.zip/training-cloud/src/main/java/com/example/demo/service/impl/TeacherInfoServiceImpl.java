package com.example.demo.service.impl;

import com.example.demo.po.TeacherInfo;
import com.example.demo.dao.TeacherInfoMapper;
import com.example.demo.service.TeacherInfoService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 教师表 服务实现类
 * </p>
 *
 * @author mp
 * @since 2023-10-25
 */
@Service
public class TeacherInfoServiceImpl extends ServiceImpl<TeacherInfoMapper, TeacherInfo> implements TeacherInfoService {

}
