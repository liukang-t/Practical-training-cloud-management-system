package com.example.demo.dto;

import com.example.demo.po.ClassInfo;
import lombok.Data;

@Data
public class ClassInfoDto extends ClassInfo {

    /**
     * 总人数
     */
    private Integer totalCount;

    /**
     * 男生人数
     */
    private Integer nanCount;

    /**
     * 女生人数
     */
    private Integer nvCount;
}
