package com.example.demo.service;

import com.example.demo.po.TeacherInfo;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 教师表 服务类
 * </p>
 *
 * @author mp
 * @since 2023-10-25
 */
public interface TeacherInfoService extends IService<TeacherInfo> {

}
