package com.example.demo.dao;

import com.example.demo.po.TaskInfo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 任务表 Mapper 接口
 * </p>
 *
 * @author mp
 * @since 2023-11-27
 */
public interface TaskInfoMapper extends BaseMapper<TaskInfo> {

}
