package com.example.demo.controller;


import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import com.example.demo.beans.CommonResult;
import com.example.demo.service.DiscussCommentService;
import com.example.demo.vo.DiscussCommentVo;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

/**
 * <p>
 * 回复表 前端控制器
 * </p>
 *
 * @author hc1204
 * @since 2023-12-04
 */
@RestController
@RequestMapping("/discussComment")
public class DiscussCommentController {

    @Resource
    DiscussCommentService discussCommentService;

    @PostMapping("/addDiscussComment")
    public CommonResult addDiscussComment(HttpServletRequest request, @RequestBody DiscussCommentVo discussCommentVo) {
        //参数校验 如果有vaild 就可以用注解进行参数校验了
        if (ObjectUtil.isNull(discussCommentVo)){
            return CommonResult.error("参数不能为空");
        }
        if (ObjectUtil.isNull(discussCommentVo.getRelationDiscussId())){
            return CommonResult.error("答疑id不能为空");
        }
        if (StrUtil.isBlank(discussCommentVo.getContent())){
            return CommonResult.error("内容不能为空");
        }
        return discussCommentService.addDiscussComment(request,discussCommentVo);
    }
}

