package com.example.demo.controller;


import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import com.example.demo.beans.CommonResult;
import com.example.demo.service.DailyReportService;
import com.example.demo.vo.DailyReportVo;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

/**
 * <p>
 * 学生日报表 前端控制器
 * </p>
 *
 * @author mp
 * @since 2023-11-23
 */
@RestController
@RequestMapping("/dailyReport")
public class DailyReportController {

    @Resource
    DailyReportService dailyReportService;

    @PostMapping("/addDailyReport")
    public CommonResult addDailyReport(HttpServletRequest request,@RequestBody DailyReportVo dailyReportVo){
        if (ObjectUtil.isNull(dailyReportVo)){
            return CommonResult.error("参数不能为空");
        }
        if (StrUtil.isBlank(dailyReportVo.getProblem())){
            return CommonResult.error("存在的问题不能为空");
        }
        if (StrUtil.isBlank(dailyReportVo.getContent())){
            return CommonResult.error("日报的内容不能为空");
        }
        return dailyReportService.addDailyReport(request,dailyReportVo);
    }

    @GetMapping("/getDailyReportList")
    public CommonResult getDailyReportList(HttpServletRequest request,DailyReportVo dailyReportVo){
        if (ObjectUtil.isNull(dailyReportVo)){
            return CommonResult.error("参数不能为空");
        }
        if (dailyReportVo.getPage() == null || dailyReportVo.getPage() <= 0){
            return CommonResult.error("页码不存在");
        }
        if (dailyReportVo.getSize() == null || dailyReportVo.getSize() <= 0){
            return CommonResult.error("条数不存在");
        }
        return dailyReportService.getDailyReportList(request,dailyReportVo);
    }

    @GetMapping("/getStudentDailyList")
    public CommonResult getStudentDailyList(HttpServletRequest request,DailyReportVo dailyReportVo){
        //参数校验
        if (ObjectUtil.isNull(dailyReportVo)){
            return CommonResult.error("参数不能为空");
        }
        if (dailyReportVo.getPage() == null || dailyReportVo.getPage() <= 0){
            return CommonResult.error("页码不存在");
        }
        if (dailyReportVo.getSize() == null || dailyReportVo.getSize() <= 0){
            return CommonResult.error("条数不存在");
        }
        return dailyReportService.getStudentDailyList(request,dailyReportVo);
    }

    @PostMapping("/commentOnDailyReport")
    public CommonResult commentOnDailyReport(HttpServletRequest request,@RequestBody DailyReportVo dailyReportVo){
        //参数校验
        if (ObjectUtil.isNull(dailyReportVo)){
            return CommonResult.error("参数不能为空");
        }
        if (ObjectUtil.isNull(dailyReportVo.getId())){
            return CommonResult.error("日报id不能为空");
        }
        if (StrUtil.isBlank(dailyReportVo.getComment())){
            return CommonResult.error("日报的评论不能为空");
        }
        return dailyReportService.commentOnDailyReport(request,dailyReportVo);
    }
}

