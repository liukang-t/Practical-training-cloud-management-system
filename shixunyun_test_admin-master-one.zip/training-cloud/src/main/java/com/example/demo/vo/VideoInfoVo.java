package com.example.demo.vo;

import lombok.Data;

import java.util.List;

@Data
public class VideoInfoVo extends BaseVo {

    private String videoName; //视频名称

    private String videoUrl; //视频链接

    private String content; //视频内容

    private Integer relationStudentId;//关联的学生id

    private List<Integer> idList;

    private Integer relationClassId;//关联的班级id

    private Integer relationTeacherId;//关联的教师id
}
