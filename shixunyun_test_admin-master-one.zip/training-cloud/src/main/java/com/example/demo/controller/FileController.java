package com.example.demo.controller;

import com.example.demo.beans.CommonResult;
import com.example.demo.utils.UploadFileUtil;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.net.URLEncoder;

@RestController
@RequestMapping("/file")
public class FileController {

    @PostMapping("/upload")
    public CommonResult uploadByAjax(HttpServletRequest request) {
        //转换请求类型，来获取请求内的文件
        MultipartHttpServletRequest multipartHttpServletRequest = (MultipartHttpServletRequest) request;
        MultipartFile file = multipartHttpServletRequest.getFile("file");
        //保存文件到本地磁盘，并获取下载路径
        String downloadUrl = UploadFileUtil.localSave(file, "8084");
        return CommonResult.success("保存成功", downloadUrl);
    }

    @GetMapping("/getFile")
    public void getFile(HttpServletRequest request, HttpServletResponse response) throws IOException {
        //获取请求的路径
        String filePath = request.getParameter("filePath");
        //判断文件是否携带参数   D:/test/image/1.txt ?name=1111
        int nameIndex = filePath.lastIndexOf('?');
        String name = null;
        name = String.valueOf(System.currentTimeMillis());
        if (nameIndex > 0) {
            int paramerIndex = filePath.lastIndexOf('=');
            if (paramerIndex > 0) {
                name = filePath.substring(paramerIndex + 1);
            }
            filePath = filePath.substring(0, nameIndex);
        }
        //获取文件的后缀名
        int index = filePath.lastIndexOf('.');
        String suffix = filePath.substring(index);
        response.setHeader("Content-disposition", "attachment; filename=" + URLEncoder.encode(name, "utf-8") + suffix);
        //创建输入流 输出流 进行io操作
        FileInputStream inputStream = new FileInputStream(filePath);
        BufferedOutputStream outputStream = new BufferedOutputStream(response.getOutputStream());
        //进行io操作
        byte[] bytes = new byte[1024];
        Integer lens = null;
        while ((lens = inputStream.read(bytes)) != -1) {
            outputStream.write(bytes);
        }
        //刷新输出流
        outputStream.flush();
        //关闭输入流 和 输出流
        outputStream.close();
        inputStream.close();
    }
}
