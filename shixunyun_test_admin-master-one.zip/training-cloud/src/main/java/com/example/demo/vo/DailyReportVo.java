package com.example.demo.vo;

import lombok.Data;

import java.util.List;

@Data
public class DailyReportVo extends BaseVo {

    /**
     * 存在的问题
     */
    private String problem;

    /**
     * 日报的内容
     */
    private String content;

    /**
     * 关联的学生id
     */
    private Integer relationStudentId;

    /**
     * 关联的班级id
     */
    private Integer relationClassId;

    /**
     * 关联的教师id
     */
    private Integer relationTeacherId;

    /**
     * 班级id列表
     */
    private List<Integer> classIds;

    /**
     * 评论
     */
    private String comment;
}
