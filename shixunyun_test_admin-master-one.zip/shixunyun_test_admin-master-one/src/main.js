import Vue from 'vue'
import App from './App.vue'

import ElementUI from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'
Vue.use(ElementUI)
import '@/styles/index.scss'

import store from '@/store/index.js'
import router from '@/router/index.js'

import '@/permission.js'

import * as globalMethods from '@/utils/global.js'
Object.keys(globalMethods).forEach((key) => {
  Vue.prototype[`$${key}`] = globalMethods[key]
})

import message from '@/utils/resetMessage.js'
Vue.prototype.$message = message

import myPager from '@/components/myPager/index.vue'
Vue.component('MyPager', myPager)

Vue.config.productionTip = false

// import mixin from '@/utils/mixin.js'

// Vue.mixin(mixin)


new Vue({
  render: h => h(App),
  store,
  router
}).$mount('#app')
