<template>
  <div class="main-box">
    <el-form
      class="form-box"
      label-position="left"
      label-width="100px"
    >
      <el-form-item label="班级">
        <el-select v-model="formData.relationClassId" placeholder="请选择班级" style="width: 100%;">
          <el-option
            v-for="item in classList"
            :key="item.id"
            :label="item.className"
            :value="item.id"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="资源名称">
        <el-input v-model="formData.resourceName" placeholder="请输入资源名称" autocomplete="off" class="my-input" />
      </el-form-item>
      <el-form-item label="资源描述">
        <el-input v-model="formData.resourceDescription" type="textarea" resize="none" :rows="4" placeholder="请输入资源描述" autocomplete="off" class="my-input" />
      </el-form-item>
      <el-form-item label="上传资源">
        <el-upload
          class="my-upload"
          :action="action"
          name="file"
          :file-list="formData.fileList"
          :headers="{
            token: $store.state.user.token
          }"
          drag
          :show-file-list="true"
          :limit="1"
          :before-upload="beforeUpload"
          :on-success="handleSuccess"
          :on-error="handleError"
          :on-exceed="handleExceed"
          :before-remove="handleRemove"
        >
          <i class="el-icon-upload" />
          <div class="el-upload__text">将文件拖到此处，或<em>点击上传</em></div>
          <div slot="tip" class="el-upload__tip">只能上传单个文件，且不超过100mb</div>
        </el-upload>
      </el-form-item>
    </el-form>
    <div class="btn-box">
      <el-button @click="$emit('close')">取消</el-button>
      <el-button type="primary" :loading="submitting" @click="handleSubmit">确定</el-button>
    </div>
  </div>
</template>

<script>
import settings from '@/settings.js'
import { getClassList } from '@/api/class.js'
export default {
  props: {
    currentItem: {
      type: Object,
      default: () => ({})
    },
    submitting: {
      type: Boolean,
      default: () => false
    }
  },
  data() {
    return {
      mode: 'add',
      action: settings.uploadPath,
      formData: {},
      classList: []
    }
  },
  watch: {
    currentItem: {
      handler(e) {
        if (e.id) {
          this.mode = 'mod'
          this.formData = {
            id: e.id,
            relationClassId: e.relationClassId,
            resourceName: e.resourceName,
            resourceDescription: e.resourceDescription,
            fileList: [{ name: e.fileName, url: e.resourceUrl }]
          }
        } else {
          this.mode = 'add'
          this.formData = {
            relationClassId: '',
            resourceName: '',
            resourceDescription: '',
            fileList: []
          }
        }
      },
      deep: true,
      immediate: true
    }
  },
  mounted() {
    this.getClassList()
  },
  methods: {
    beforeUpload(file) {
      if (file.size >= 100 * 1024 * 1024) {
        this.$message.error('文件过大，请压缩后上传')
        return false
      }
      return true
    },
    handleSuccess({ code, data }, file) {
      console.log('file', file)
      if (code === 200) {
        this.$message.success('文件上传成功')
        this.formData.fileList = [{ name: file.name, url: data }]
      } else if (code === 401 || code === 403) {
        this.$message.error('身份认证过期请重新登录')
        this.$store.dispatch('user/resetToken')
        location.reload()
      } else {
        this.$message.error('文件上传失败')
      }
    },
    handleError() {
      this.$message.error('文件上传失败')
    },
    handleExceed() {
      this.$message.error('该模块只支持单文件上传，请删除资源后再重新上传')
    },
    handleRemove() {
      this.formData.fileList = []
    },
    handleSubmit() {
      const formData = this.$copy(this.formData)
      if (!formData.fileList.length) {
        this.$message.error('资源文件不能为空')
        return
      }
      formData.resourceUrl = formData.fileList[0].url
      delete formData.fileList
      if (this.mode === 'add') {
        this.$emit('addItem', formData)
      } else {
        this.$emit('modItem', formData)
      }
    },
    getClassList() {
      getClassList({}).then(({ data }) => {
        this.classList = data.list
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.main-box {
  .btn-box {
    text-align: right;
  }
}
</style>
