/* stylelint-disable rule-empty-line-before */
<template>
  <div class="my-page">
    <div class="title-box">
      <el-breadcrumb separator="/">
        <el-breadcrumb-item class="custom-breadcrumb-item" :to="{ path: '/videoManager/index' }">视频管理</el-breadcrumb-item>
        <el-breadcrumb-item class="custom-breadcrumb-item">学生视频列表</el-breadcrumb-item>
      </el-breadcrumb>
    </div>
    <div class="table-box">
      <div class="table-box-main">
        <el-table
          v-loading="tableLoading"
          :data="tableData"
          class="my-table"
          stripe
          height="100%"
        >
          <el-table-column
            label="序号"
            width="120"
            align="center"
          >
            <template #default="{$index}">
              <span>{{ (page - 1) * size + $index + 1 }}</span>
            </template>
          </el-table-column>
          <el-table-column
            label="视频名称"
            align="center"
          >
            <template #default="{row}">
              <span class="hidden-one">{{ row.videoName }}</span>
            </template>
          </el-table-column>
          <el-table-column
            label="发布时间"
            align="center"
          >
            <template #default="{row}">
              <span class="hidden-one">{{ row.createTime }}</span>
            </template>
          </el-table-column>
          <el-table-column
            label="操作"
            align="center"
          >
            <template #default="{row}">
              <el-button type="text" @click="openDetail(row)">查看</el-button>
              <el-button type="text" @click="$downloadFile(row.videoUrl)">下载</el-button>
            </template>
          </el-table-column>
        </el-table>
      </div>
    </div>
    <div class="pager-box">
      <MyPager :page="page" :size="size" :total-count="totalCount" @pageChange="pageChange" @sizeChange="sizeChange" />
    </div>
    <el-dialog
      :title="dialogTitle"
      :visible.sync="showDetail"
      width="40%"
      :close-on-click-modal="false"
      custom-class="my-dialog"
      destroy-on-close
    >
      <detail
        v-if="showDetail"
        :current-item="currentItem"
        @refresh="getList"
        @close="showDetail = false"
      />
    </el-dialog>
  </div>
</template>

<script>
import { getVideoList } from '@/api/video.js'
import detail from './components/detail.vue'
export default {
  name: 'VideoList',
  components: {
    detail
  },
  data() {
    return {
      studentId: Number(this.$route.query.id),
      page: 1,
      size: 10,
      totalCount: 0,
      tableLoading: false,
      tableData: [],
      showDetail: false,
      currentItem: {},
      dialogTitle: '查看视频'

    }
  },
  computed: {
    userInfo() {
      console.log(this.$store.state.user.userInfo)
      return this.$store.state.user.userInfo
    }
  },
  mounted() {
    this.getList()
  },
  methods: {
    pageChange(e) {
      this.page = e
      this.getList()
    },
    sizeChange(e) {
      this.page = 1
      this.size = e
      this.getList()
    },
    openDetail(row) {
      console.log('传入数据', row)
      this.dialogTitle = row.videoName
      this.currentItem = row
      this.showDetail = true
    },
    getList() {
      this.tableLoading = true
      const params = {
        page: this.page,
        size: this.size,
        relationStudentId: this.studentId
      }
      getVideoList(params).then(({ data }) => {
        this.tableData = data.list
        this.totalCount = data.total
        this.tableLoading = false
        this.canDelete = false
      }).catch(() => {
        this.tableLoading = false
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.my-page {
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  padding: 0 30px;
  .title-box {
    height: 40px;
    font-size: 16px;
    font-weight: bold;
    line-height: 40px;
    color: #333;
    margin-top: 40px;
    margin-bottom: 20px;
    .custom-breadcrumb-item {
      font-size: 16px;
      font-weight: bold;
    }
  }
  .btn-box {
    height: 40px;
    margin-bottom: 10px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    .btn-left {
      width: 340px;
    }
  }
  .table-box {
    flex: 1;
    position: relative;
    .table-box-main {
      position: absolute;
      width: 100%;
      height: 100%;
      .my-table {
        border: 1px solid #CCC;
        border-radius: 8px;
      }
    }
  }
  .pager-box {
    padding: 10px 0;
  }
  /deep/ .my-dialog {
    border-radius: 6px !important;
    .el-dialog__body {
      padding: 20px 30px;
    }
  }
}
</style>
