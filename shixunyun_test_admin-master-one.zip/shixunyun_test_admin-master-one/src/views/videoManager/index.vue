/* stylelint-disable rule-empty-line-before */
<template>
  <div class="my-page">
    <div class="title-box">
      视频管理
    </div>
    <div class="btn-box">
      <div class="btn-left">
        <el-select v-model="relationClassId" placeholder="请选择班级" clearable @change="getList">
          <el-option
            v-for="item in classList"
            :key="item.id"
            :label="item.className"
            :value="item.id"
          />
        </el-select>
      </div>
      <div class="btn-right" />
    </div>
    <div class="table-box">
      <div class="table-box-main">
        <el-table
          v-if="userInfo.teacherInfo"
          v-loading="tableLoading"
          :data="tableData"
          class="my-table"
          stripe
          height="100%"
        >
          <el-table-column
            label="序号"
            width="120"
            align="center"
          >
            <template #default="{$index}">
              <span>{{ (page - 1) * size + $index + 1 }}</span>
            </template>
          </el-table-column>
          <el-table-column
            label="学生姓名"
            align="center"
          >
            <template #default="{row}">
              <span class="hidden-one">{{ row.studentName }}</span>
            </template>
          </el-table-column>
          <el-table-column
            label="学校"
            align="center"
          >
            <template #default="{row}">
              <span class="hidden-one">{{ row.schoolName }}</span>
            </template>
          </el-table-column>
          <el-table-column
            label="院系"
            align="center"
          >
            <template #default="{row}">
              <span class="hidden-one">{{ row.departmentName }}</span>
            </template>
          </el-table-column>
          <el-table-column
            label="班级"
            align="center"
          >
            <template #default="{row}">
              <span class="hidden-one">{{ row.className }}</span>
            </template>
          </el-table-column>
          <el-table-column
            label="提交次数"
            align="center"
          >
            <template #default="{row}">
              <span class="hidden-one">{{ row.videoCount }}</span>
            </template>
          </el-table-column>
          <el-table-column
            label="操作"
            align="center"
          >
            <template #default="{row}">
              <el-button type="text" @click="goDetail(row.studentId)">查看</el-button>
            </template>
          </el-table-column>
        </el-table>
      </div>
    </div>
    <div class="pager-box">
      <MyPager :page="page" :size="size" :total-count="totalCount" @pageChange="pageChange" @sizeChange="sizeChange" />
    </div>
  </div>
</template>

<script>
import { getStudentVideoList } from '@/api/video.js'
import { getClassList } from '@/api/class.js'
export default {
  name: 'VideoManagerIndex',
  data() {
    return {
      page: 1,
      size: 10,
      totalCount: 0,
      tableLoading: false,
      tableData: [],
      currentItem: {},
      dialogTitle: '',
      studentDialogTitle: '',
      relationClassId: '',
      classList: []
    }
  },
  computed: {
    userInfo() {
      console.log(this.$store.state.user.userInfo)
      return this.$store.state.user.userInfo
    }
  },
  mounted() {
    this.getClassList()
    this.getList()
  },
  methods: {
    pageChange(e) {
      this.page = e
      this.getList()
    },
    sizeChange(e) {
      this.page = 1
      this.size = e
      this.getList()
    },
    goDetail(id) {
      this.$jumpPage({ path: '/videoManager/videoList', query: { id }})
    },
    getClassList() {
      getClassList({}).then(({ data }) => {
        this.classList = data.list
      })
    },
    getList() {
      this.tableLoading = true
      const params = {
        page: this.page,
        size: this.size
      }
      if (this.relationClassId) {
        params.relationClassId = this.relationClassId
      }
      getStudentVideoList(params).then(({ data }) => {
        this.tableData = data.list
        this.totalCount = data.total
        this.tableLoading = false
        this.canDelete = false
      }).catch(() => {
        this.tableLoading = false
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.my-page {
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  padding: 0 30px;
  .title-box {
    height: 40px;
    font-size: 16px;
    font-weight: bold;
    line-height: 40px;
    color: #333;
    margin-bottom: 20px;
  }
  .btn-box {
    height: 40px;
    margin-bottom: 10px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    .btn-left {
      width: 340px;
    }
  }
  .table-box {
    flex: 1;
    position: relative;
    .table-box-main {
      position: absolute;
      width: 100%;
      height: 100%;
      .my-table {
        border: 1px solid #CCC;
        border-radius: 8px;
      }
    }
  }
  .pager-box {
    padding: 10px 0;
  }
  /deep/ .my-dialog {
    border-radius: 6px !important;
    .el-dialog__body {
      padding: 20px 30px;
    }
  }
}
</style>
