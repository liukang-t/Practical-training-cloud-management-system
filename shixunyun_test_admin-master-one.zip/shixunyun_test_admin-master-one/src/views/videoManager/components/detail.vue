<template>
  <div class="main-box">
    <el-form
      class="form-box"
      label-position="left"
      label-width="100px"
    >
      <el-form-item label="发布时间：">
        <span>{{ formData.createTime }}</span>
      </el-form-item>
      <el-form-item>
        <video :src="formData.videoUrl" controls class="video-box" />
      </el-form-item>
      <el-form-item label="视频描述：">
        <span>{{ formData.content }}</span>
      </el-form-item>
    </el-form>
    <div class="btn-box">
      <el-button @click="$emit('close')">关闭</el-button>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    currentItem: {
      type: Object,
      default: () => ({})
    }
  },
  data() {
    return {
      formData: {},
      submitting: false
    }
  },
  watch: {
    currentItem: {
      handler(e) {
        this.formData = this.$copy(this.currentItem)
      },
      deep: true,
      immediate: true
    }
  },
  methods: {

  }
}
</script>

<style lang="scss" scoped>
.main-box {
  .video-box {
    width: 360px;
    height: 270px;
    border: 1px solid #CCC;
    border-radius: 8px;
  }
  .btn-box {
    text-align: right;
  }
}
</style>
