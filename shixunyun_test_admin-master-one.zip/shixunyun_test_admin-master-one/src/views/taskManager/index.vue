<template>
  <div class="my-page">
    <div class="title-box">
      任务管理
    </div>
    <div v-if="userInfo.teacherInfo" class="btn-box">
      <div v-if="userInfo.teacherInfo" class="btn-left">
        <el-select v-model="relationClassId" placeholder="请选择班级" clearable @change="getList">
          <el-option
            v-for="item in classList"
            :key="item.id"
            :label="item.className"
            :value="item.id"
          />
        </el-select>
      </div>
      <div class="btn-right">
        <el-button
          type="danger"
          :plain="!canDelete"
          @click="deleteChange"
        >{{ canDelete ? '删除选中' : '批量删除' }}</el-button>
        <el-button type="primary" @click="openTaskEdit({})">添加任务</el-button>
      </div>
    </div>
    <div class="table-box">
      <div class="table-box-main">
        <el-table
          v-loading="tableLoading"
          :data="tableData"
          class="my-table"
          stripe
          height="100%"
          @selection-change="handleSelectionChange"
        >
          <el-table-column
            v-if="canDelete"
            type="selection"
            width="60"
            align="center"
          />
          <el-table-column
            label="序号"
            width="120"
            align="center"
          >
            <template #default="{$index}">
              <span>{{ (page - 1) * size + $index + 1 }}</span>
            </template>
          </el-table-column>
          <el-table-column
            label="任务名称"
            align="center"
          >
            <template #default="{row}">
              <span class="hidden-one">{{ row.taskName }}</span>
            </template>
          </el-table-column>
          <el-table-column
            label="任务开始时间"
            align="center"
          >
            <template #default="{row}">
              <span class="hidden-one">{{ row.startTime }}</span>
            </template>
          </el-table-column>
          <el-table-column
            label="任务截至时间"
            align="center"
          >
            <template #default="{row}">
              <span class="hidden-one">{{ row.endTime }}</span>
            </template>
          </el-table-column>
          <el-table-column
            label="任务内容"
            align="center"
          >
            <template #default="{row}">
              <span class="hidden-one">{{ row.content }}</span>
            </template>
          </el-table-column>
          <el-table-column
            label="操作"
            align="center"
          >
            <template #default="{row}">
              <el-button type="text" @click="goDetail(row.id)">查看</el-button>
              <el-button v-if="userInfo.teacherInfo" type="text" @click="openTaskEdit(row)">编辑</el-button>
              <el-button v-if="userInfo.teacherInfo" type="text" @click="delItem([row.id])">删除</el-button>
            </template>
          </el-table-column>
        </el-table>
      </div>
    </div>
    <div class="pager-box">
      <MyPager :page="page" :size="size" :total-count="totalCount" @pageChange="pageChange" @sizeChange="sizeChange" />
    </div>
    <el-dialog
      :title="dialogTitle"
      :visible.sync="showTaskEdit"
      width="40%"
      :close-on-click-modal="false"
      custom-class="my-dialog"
      destroy-on-close
    >
      <TaskEdit
        v-if="showTaskEdit"
        :submitting="submitting"
        :current-item="currentItem"
        :class-list="classList"
        @addItem="addItem"
        @modItem="modItem"
        @close="showTaskEdit = false"
      />
    </el-dialog>
  </div>
</template>

<script>
import TaskEdit from './components/taskEdit.vue'
import { getClassList } from '@/api/class.js'
import { addTask, getTaskList, modifyTask, deleteTask } from '@/api/task.js'
export default {
  name: 'TaskManagerIndex',
  components: {
    TaskEdit
  },
  data() {
    return {
      page: 1,
      size: 10,
      totalCount: 0,
      tableLoading: false,
      canDelete: false,
      deleteIdList: [],
      tableData: [],
      dialogTitle: '添加任务',
      showTaskEdit: false,
      currentItem: {},
      classList: [],
      submitting: false,
      relationClassId: ''
    }
  },
  computed: {
    userInfo() {
      console.log(this.$store.state.user.userInfo)
      return this.$store.state.user.userInfo
    }
  },
  mounted() {
    this.getClassList()
    this.getList()
  },
  methods: {
    pageChange(e) {
      this.page = e
      this.getList()
    },
    sizeChange(e) {
      this.page = 1
      this.size = e
      this.getList()
    },
    openTaskEdit(e = {}) {
      console.log('传入数据', e)
      e.id ? this.dialogTitle = '编辑任务' : this.dialogTitle = '添加任务'
      this.currentItem = e
      console.log('当前数据', this.currentItem)
      this.showTaskEdit = true
    },
    deleteChange() {
      if (!this.canDelete || !this.deleteIdList.length) {
        this.canDelete = !this.canDelete
      } else {
        this.delItem(this.deleteIdList)
      }
    },
    handleSelectionChange(e) {
      console.log('勾选改变', e)
      this.deleteIdList = e.map((item) => {
        return item.id
      })
    },
    goDetail(id) {
      this.$jumpPage({ path: '/taskManager/detail', query: { id }})
    },
    getList() {
      this.tableLoading = true
      const params = {
        page: this.page,
        size: this.size,
        relationClassId: this.relationClassId
      }
      getTaskList(params).then(({ data }) => {
        this.tableData = data.list
        this.totalCount = data.totalCount
        this.tableLoading = false
        this.canDelete = false
      }).catch(() => {
        this.tableLoading = false
      })
    },
    addItem(e) {
      this.submitting = true
      addTask(e).then(() => {
        this.submitting = false
        this.$message.success('任务添加成功')
        this.showTaskEdit = false
        this.getList()
      }).catch(() => {
        this.submitting = false
      })
    },
    modItem(e) {
      this.submitting = true
      modifyTask(e).then(() => {
        this.submitting = false
        this.$message.success('班级修改成功')
        this.showTaskEdit = false
        this.getList()
      }).catch(() => {
        this.submitting = false
      })
    },
    delItem(e) {
      this.$confirm('该操作将删除此项，是否确认删除？', '提示', {
        type: 'warning',
        showClose: true
      }).then(() => {
        deleteTask({
          idList: e
        }).then(() => {
          this.$message.success('成功删除班级')
          if (this.page > 1 && this.tableData.length === e.length) {
            this.page--
          }
          this.getList()
        })
      })
    },
    getClassList() {
      if (this.userInfo.teacherInfo) {
        getClassList({}).then(({ data }) => {
          this.classList = data.list
          if (data.list.length !== 0) {
            this.relationClassId = data.list[0].id
          }
        })
      } else {
        this.classList = []
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.my-page {
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  padding: 0 30px;
  .title-box {
    height: 40px;
    font-size: 16px;
    font-weight: bold;
    line-height: 40px;
    color: #333;
  }
  .btn-box {
    height: 40px;
    margin-bottom: 10px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    .btn-left {
      width: 340px;
    }
  }
  .table-box {
    flex: 1;
    position: relative;
    .table-box-main {
      position: absolute;
      width: 100%;
      height: 100%;
      .my-table {
        border: 1px solid #CCC;
        border-radius: 8px;
      }
    }
  }
  .pager-box {
    padding: 10px 0;
  }
  /deep/ .my-dialog {
    border-radius: 6px !important;
    .el-dialog__body {
      padding: 20px 30px;
    }
  }
}
</style>
