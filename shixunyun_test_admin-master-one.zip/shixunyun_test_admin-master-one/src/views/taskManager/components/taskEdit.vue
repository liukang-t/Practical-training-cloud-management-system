<template>
  <div class="main-box">
    <el-form
      class="form-box"
      label-position="left"
      label-width="100px"
    >
      <el-form-item label="任务名称">
        <el-input v-model="formData.taskName" placeholder="请输入任务名称" autocomplete="off" class="my-input" />
      </el-form-item>
      <el-form-item label="班级">
        <el-select v-model="formData.relationClassId" placeholder="请选择班级" style="width: 100%;" :disabled="mode === 'mod'">
          <el-option
            v-for="item in classList"
            :key="item.id"
            :label="item.className"
            :value="item.id"
          />
        </el-select>
      </el-form-item>
      <el-form-item v-if="mode ==='add'" label="开始时间">
        <el-date-picker v-model="formData.startTime" value-format="yyyy-MM-dd" type="date" placeholder="选择开始日期" style="width: 100%;" />
      </el-form-item>
      <el-form-item label="截至时间">
        <el-date-picker v-model="formData.endTime" value-format="yyyy-MM-dd" type="date" placeholder="选择截至日期" style="width: 100%;" />
      </el-form-item>
      <el-form-item label="任务内容">
        <el-input v-model="formData.content" type="textarea" resize="none" :rows="4" placeholder="请输入任务内容" autocomplete="off" class="my-input" />
      </el-form-item>
    </el-form>
    <div class="btn-box">
      <el-button @click="$emit('close')">取消</el-button>
      <el-button type="primary" :loading="submitting" @click="handleSubmit">确定</el-button>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    currentItem: {
      type: Object,
      default: () => ({})
    },
    submitting: {
      type: Boolean,
      default: () => false
    },
    classList: {
      type: Array,
      default: () => ([])
    }
  },
  data() {
    return {
      mode: 'add',
      formData: {}
    }
  },
  watch: {
    currentItem: {
      handler(e) {
        if (e.id) {
          this.mode = 'mod'
          this.formData = {
            id: e.id,
            taskName: e.taskName,
            relationClassId: e.relationClassId,
            endTime: e.endTime,
            content: e.content
          }
        } else {
          this.mode = 'add'
          this.formData = {
            taskName: '',
            startTime: '',
            relationClassId: '',
            endTime: '',
            content: ''
          }
        }
      },
      deep: true,
      immediate: true
    }
  },
  methods: {
    checkTime(selectTime) {
      const nowTime = this.$parseTime('', '{y}-{m}-{d}')
      const endTime = this.$parseTime(selectTime, '{y}-{m}-{d}')
      return nowTime.replace(/-/g, '') <= endTime.replace(/-/g, '')
    },
    handleSubmit() {
      if (!this.checkTime(this.formData.endTime)) {
        this.$message.error('截至时间不能早于当前时间')
        return
      }
      if (this.mode === 'add') {
        this.$emit('addItem', this.$copy(this.formData))
      } else {
        this.$emit('modItem', this.$copy(this.formData))
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.main-box {
  .btn-box {
    text-align: right;
  }
}
</style>
