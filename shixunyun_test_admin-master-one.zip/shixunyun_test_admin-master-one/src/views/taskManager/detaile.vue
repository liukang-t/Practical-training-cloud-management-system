<template>
  <div class="my-page">
    <div class="page-top-box">
      <span @click="$jumpPage(-1)">返回上一级 |</span>
      <span class="only">任务管理</span>
      <span>> 任务详情</span>
    </div>
    <div class="big-box">
      <div class="left-box">
        <div class="top-tip">任务详情</div>
        <div class="detail-form">
          <div class="row-box">
            <div class="label-box">任务名称</div>
            <div class="value-box">{{ detail.taskName }}</div>
          </div>
          <div class="row-box">
            <div class="label-box">起止时间</div>
            <div class="value-box">{{ detail.startTime }}  -  {{ detail.endTime }}</div>
          </div>
          <div class="row-box">
            <div class="label-box">任务内容</div>
            <div class="value-box">{{ detail.content }}</div>
          </div>
          <div class="row-box">
            <div class="label-box">任务状态</div>
            <div class="value-box">{{ detail.taskStatus === 1 ? '进行中' : '已结束' }}</div>
          </div>
          <div class="row-box">
            <div class="label-box">平均分数</div>
            <div class="value-box">{{ Number(detail.scoreAverage).toFixed(2) }}</div>
          </div>
        </div>
      </div>
      <div class="right-box">
        <div class="top-tip">评分列表</div>
        <div class="table-box">
          <div class="table-box-main">
            <el-table
              v-loading="tableLoading"
              :data="tableData"
              class="my-table"
              stripe
              height="100%"
            >
              <el-table-column
                label="序号"
                width="120"
                align="center"
              >
                <template #default="{$index}">
                  <span>{{ (page - 1) * size + $index + 1 }}</span>
                </template>
              </el-table-column>
              <el-table-column
                label="姓名"
                align="center"
              >
                <template #default="{row}">
                  <span class="hidden-one">{{ row.studentName }}</span>
                </template>
              </el-table-column>
              <el-table-column
                label="学号"
                align="center"
              >
                <template #default="{row}">
                  <span class="hidden-one">{{ row.studentNumber }}</span>
                </template>
              </el-table-column>
              <el-table-column
                label="任务评分"
                align="center"
              >
                <template #default="{row}">
                  <div v-if="!row.isEdit" class="score-box">
                    <span class="hidden-one score-text">{{ !row.score && row.score !== 0 ? '暂未评分' : row.score }}</span>
                    <img v-if="userInfo.teacherInfo" src="@/assets/icons/editor.png" alt="" @click="openEdit(row)">
                  </div>
                  <div v-else class="score-box">
                    <el-input v-model="row.score" autocomplete="off" size="mini" class="my-input" @keyup.enter.native="modifyScore(row)" />
                    <el-button type="text" @click="modifyScore(row)">确定</el-button>
                  </div>
                </template>
              </el-table-column>
            </el-table>
          </div>
        </div>
        <div class="pager-box">
          <MyPager layout="prev, pager, next" :page="page" :size="size" :total-count="totalCount" @pageChange="pageChange" @sizeChange="sizeChange" />
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { getTaskDetail, getTaskScoreList, modifyTaskScore } from '@/api/task'
export default {
  name: 'TaskManagerDetail',
  data() {
    return {
      id: Number(this.$route.query.id),
      detail: {},
      page: 1,
      size: 10,
      totalCount: 0,
      tableLoading: false,
      tableData: []
    }
  },
  computed: {
    userInfo() {
      console.log(this.$store.state.user.userInfo)
      return this.$store.state.user.userInfo
    }
  },
  mounted() {
    this.getTaskDetail()
    this.getTaskScoreList()
  },
  methods: {
    pageChange(e) {
      this.page = e
      this.getTaskScoreList()
    },
    sizeChange(e) {
      this.page = 1
      this.size = e
      this.getTaskScoreList()
    },
    getTaskDetail() {
      getTaskDetail({ id: this.id }).then(({ data }) => {
        this.detail = data
      })
    },
    getTaskScoreList() {
      this.tableLoading = true
      getTaskScoreList({ taskId: this.id, page: this.page, size: this.size }).then(({ data }) => {
        this.tableData = data.list.map((item) => {
          item.isEdit = false
          return item
        })
        this.totalCount = data.total
        this.tableLoading = false
      }).catch(() => {
        this.tableLoading = false
      })
    },
    openEdit(row) {
      row.isEdit = true
    },
    modifyScore(row) {
      if (!row.score && row.score !== 0) {
        this.$message.error('评分不能为空')
        return
      }
      if (row.score > 100 || row.score < 0) {
        this.$message.error('评分不能超过100或小于0')
        return
      }
      modifyTaskScore({ studentId: row.studentId, taskId: this.id, score: row.score }).then(() => {
        this.$message.success('评分成功')
        this.getTaskDetail()
        this.getTaskScoreList()
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.my-page {
  width: 100%;
  height: 100%;
  .page-top-box {
    width: 100%;
    height: 60px;
    padding: 0 15px;
    display: flex;
    align-items: center;
    color: #0CC;
    font-size: 12px;
    .only {
      color: #333;
      margin: 0 4px;
    }
    span:first-child {
      cursor: pointer;
    }
  }
  .big-box {
    display: flex;
    align-items: center;
    width: 100%;
    height: calc(100% - 60px);
    .left-box,
    .right-box {
      width: 50%;
      height: 100%;
      padding: 0 30px;
      .top-tip {
        padding-left: 10px;
        position: relative;
        font-size: 14px;
        font-weight: bold;
        line-height: 16px;
        margin-bottom: 30px;
        &::before {
          content: '';
          position: absolute;
          width: 2px;
          height: 16px;
          border-radius: 1px;
          background-color: #0CC;
          left: 0;
          top: 0;
        }
      }
    }
    .left-box {
      .detail-form {
        padding: 0 30px;
        .row-box {
          display: flex;
          font-size: 14px;
          color: #666;
          margin-bottom: 36px;
          .label-box {
            width: 86px;
            text-align: right;
            margin-right: 40px;
          }
        }
      }
    }
    .right-box {
      display: flex;
      flex-direction: column;
      .table-box {
        flex: 1;
        position: relative;
        .table-box-main {
          position: absolute;
          height: 100%;
          width: 100%;
          .my-table {
            border: 1px solid #CCC;
            border-radius: 8px;
            .score-box {
              display: flex;
              justify-content: center;
              align-items: center;
              .score-text {
                margin-right: 14px;
              }
              img {
                cursor: pointer;
              }
              .my-input {
                width: 80px;
                margin-right: 14px;
              }
            }
          }
        }
      }
      .pager-box {
        padding: 10px 0;
      }
    }
  }
}
</style>
