<template>
  <div class="page">
    <div class="login-box">
      <div class="top-padding-box">
        <div class="login-top">
          <div class="logo-box">
            <img src="@/assets/icons/login_logo.png" alt="">
            <span>实训云</span>
          </div>
          <div class="hellow-text">欢迎使用实训云平台系统</div>
        </div>
        <div class="tabs-box">
          <el-tabs v-model="tabName" :before-leave="changeTab">
            <el-tab-pane label="密码登录" name="login" />
            <el-tab-pane label="账号注册" name="register" />
          </el-tabs>
        </div>
        <!-- 登录表单 -->
        <el-form v-if="tabName === 'login'" ref="loginForm" key="login" :model="loginForm" :rules="loginRules" class="form-box">
          <el-form-item prop="accountNum">
            <el-input v-model="loginForm.accountNum" placeholder="请输入账号" prefix-icon="el-icon-user" autocomplete="off" />
          </el-form-item>
          <el-form-item prop="password">
            <el-input v-model="loginForm.password" placeholder="请输入密码" prefix-icon="el-icon-lock" show-password autocomplete="off" />
          </el-form-item>
          <div style="text-align: right; margin-bottom: 20px;">
            <el-checkbox v-model="saveUserName">记住账号</el-checkbox>
            <el-checkbox v-model="savePassword">记住密码</el-checkbox>
          </div>
          <el-form-item>
            <el-button type="primary" style="width: 100%;" @click="handleLogin">登录</el-button>
          </el-form-item>
        </el-form>
        <!-- 注册表单 -->
        <el-form v-if="tabName === 'register'" ref="registerForm" key="register" :model="registerForm" status-icon :rules="registerRules" class="form-box">
          <el-form-item prop="teacherName">
            <el-input v-model="registerForm.teacherName" placeholder="请输入用户名" prefix-icon="el-icon-user" autocomplete="off" />
          </el-form-item>
          <el-form-item prop="accountNum">
            <el-input v-model="registerForm.accountNum" placeholder="请输入注册账号" prefix-icon="el-icon-user" autocomplete="off" />
          </el-form-item>
          <el-form-item prop="password">
            <el-input v-model="registerForm.password" placeholder="请输入密码" prefix-icon="el-icon-lock" show-password autocomplete="off" />
          </el-form-item>
          <el-form-item prop="confirmPassword">
            <el-input v-model="registerForm.confirmPassword" placeholder="请输入确认密码" prefix-icon="el-icon-lock" show-password autocomplete="off" />
          </el-form-item>
          <el-form-item>
            <el-button type="primary" style="width: 100%;" :loading="registerLoading" @click="handleRegister">注册</el-button>
          </el-form-item>
        </el-form>
      </div>
      <div class="bottom-text">本品由福州安博榕信息科技有限公司提供技术支持</div>
    </div>
  </div>
</template>

<script>
import { register } from '@/api/user.js'
export default {
  name: 'Login',
  data() {
    const validateConfirmPassword = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('确认密码不能位空'))
      } else if (this.registerForm.password !== value) {
        callback(new Error('确认密码与密码不相同'))
      } else {
        callback()
      }
    }
    return {
      tabName: 'login',
      loginForm: {
        accountNum: localStorage.getItem('accountNum') || '',
        password: localStorage.getItem('password') || ''
      },
      loginRules: {
        accountNum: [
          { required: true, message: '账号不能为空', trigger: 'blur' },
          { pattern: /^[A-Za-z0-9]{6,20}$/, message: '账号必须由6-20位数字字母组成', trigger: 'blur' }
        ],
        password: [
          { required: true, message: '密码不能为空', trigger: 'blur' },
          { pattern: /^.{6,20}$/, message: '密码必须由6-20位组成', trigger: 'blur' }
        ]
      },
      registerForm: {
        teacherName: '',
        accountNum: '',
        password: '',
        confirmPassword: ''
      },
      registerRules: {
        teacherName: [
          { required: true, message: '教师姓名不能为空', trigger: 'blur' }
        ],
        accountNum: [
          { required: true, message: '账号不能为空', trigger: 'blur' },
          { pattern: /^[A-Za-z0-9]{6,20}$/, message: '账号必须由6-20位数字字母组成', trigger: 'blur' }
        ],
        password: [
          { required: true, message: '密码不能为空', trigger: 'blur' },
          { pattern: /^.{6,20}$/, message: '密码必须由6-20位组成', trigger: 'blur' }
        ],
        confirmPassword: [{ validator: validateConfirmPassword, trigger: 'blur' }]
      },
      saveUserName: !!localStorage.getItem('accountNum'),
      savePassword: !!localStorage.getItem('password'),
      loginLoading: false,
      registerLoading: false
    }
  },
  mounted() {
    // testGet({}).then((res) => {
    //   console.log('res', res)
    // })
    // console.log('登录或退出时的路由状态', this.$router)
  },
  methods: {
    changeTab(newName, oldName) {
      // console.log('changeTab', newName, oldName)
      // if (oldName === 'login') {
      //   this.$refs.loginForm.clearValidate()
      // }
      // if (oldName === 'register') {
      //   this.$refs.registerForm.clearValidate()
      // }
    },
    handleLogin() {
      this.$refs.loginForm.validate((flag) => {
        if (flag) {
          var formData = this.$copy(this.loginForm)
          this.$store.dispatch('user/login', formData).then(() => {
            this.$store.dispatch('user/getUserInfo').then(() => {
              this.saveUserName ? localStorage.setItem('accountNum', this.loginForm.accountNum) : localStorage.removeItem('accountNum')
              this.savePassword ? localStorage.setItem('password', this.loginForm.password) : localStorage.removeItem('password')
              var userInfo = this.$store.state.user.userInfo
              console.log('userInfo', userInfo)
              if (userInfo.userType === 1) {
                this.$jumpPage('/classManager/index')
              } else if (userInfo.userType === 2) {
                this.$jumpPage('/classInfo/index')
              }
            })
          })
        }
      })
    },
    handleRegister() {
      this.$refs.registerForm.validate((flag) => {
        if (flag) {
          this.registerLoading = true
          const formData = {
            teacherName: this.registerForm.teacherName,
            accountNum: this.registerForm.accountNum,
            password: this.registerForm.password
          }
          register(formData).then((res) => {
            console.log('register', res)
            this.registerLoading = false
            this.$message.success('注册成功，请切换登录页面登录账号')
          }).catch(() => {
            this.registerLoading = false
          })
        }
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.page {
  width: 100vw;
  height: 100vh;
  background: url(@/assets/image/login_background.png) no-repeat;
  background-size: 100% 100%;
  display: flex;
  justify-content: center;
  align-items: center;
  .login-box {
    width: 420px;
    height: 560px;
    background-color: #FFF;
    border-radius: 10px;
    padding-top: 60px;
    position: relative;
    .top-padding-box {
      padding: 0 60px;
      .login-top {
        .logo-box {
          display: flex;
          justify-content: center;
          align-items: center;
          img {
            width: 42px;
            height: 28px;
          }
          span {
            font-size: 20px;
            line-height: 28px;
            font-weight: bold;
            margin-left: 10px;
          }
        }
        .hellow-text {
          font-size: 18px;
          color: #333;
          margin-top: 20px;
          text-align: center;
        }
      }
      .tabs-box {
        margin-top: 50px;
        margin-bottom: 10px;
        /deep/ .el-tabs__nav-wrap::after {
          display: none;
        }
      }
    }
    .bottom-text {
      position: absolute;
      bottom: 0;
      width: 100%;
      height: 32px;
      background: #F9F9F9;
      line-height: 32px;
      font-size: 12px;
      text-align: center;
      color: #00B3B3;
      border-radius: 0 0 10px 10px;
    }
  }
}
</style>
