<template>
  <div class="my-page">
    <div class="title-box">
      班级管理
    </div>
    <div class="btn-box">
      <el-button
        type="danger"
        :plain="!canDelete"
        @click="deleteChange"
      >{{ canDelete ? '删除选中' : '批量删除' }}</el-button>
      <el-button type="primary" @click="openClassEdit({})">添加班级</el-button>
    </div>
    <div class="table-box">
      <div class="table-box-main">
        <el-table
          v-loading="tableLoading"
          :data="tableData"
          class="my-table"
          stripe
          height="100%"
          @selection-change="handleSelectionChange"
        >
          <el-table-column
            v-if="canDelete"
            type="selection"
            width="60"
            align="center"
          />
          <el-table-column
            label="序号"
            width="120"
            align="center"
          >
            <template #default="{$index}">
              <span>{{ (page - 1) * size + $index + 1 }}</span>
            </template>
          </el-table-column>
          <el-table-column
            label="班级名称"
            align="center"
          >
            <template #default="{row}">
              <span>{{ row.className }}</span>
            </template>
          </el-table-column>
          <el-table-column
            label="学校名称"
            align="center"
          >
            <template #default="{row}">
              <span>{{ row.schoolName }}</span>
            </template>
          </el-table-column>
          <el-table-column
            label="院系名称"
            align="center"
          >
            <template #default="{row}">
              <span>{{ row.departmentName }}</span>
            </template>
          </el-table-column>
          <el-table-column
            label="辅导员姓名"
            align="center"
          >
            <template #default="{row}">
              <span>{{ row.counselor }}</span>
            </template>
          </el-table-column>
          <el-table-column
            label="辅导员电话"
            align="center"
          >
            <template #default="{row}">
              <span>{{ row.counselorTelephone }}</span>
            </template>
          </el-table-column>
          <el-table-column
            label="实训标题"
            align="center"
          >
            <template #default="{row}">
              <span>{{ row.practiceTitle }}</span>
            </template>
          </el-table-column>
          <el-table-column
            label="实训内容"
            align="center"
          >
            <template #default="{row}">
              <span>{{ row.practiceContent }}</span>
            </template>
          </el-table-column>
          <el-table-column
            label="操作"
            align="center"
          >
            <template #default="{row}">
              <el-button type="text" @click="openClassEdit(row)">编辑</el-button>
              <el-button type="text" @click="delItem([row.id])">删除</el-button>
            </template>
          </el-table-column>
        </el-table>
      </div>
    </div>
    <div class="pager-box">
      <MyPager :page="page" :size="size" :total-count="totalCount" @pageChange="pageChange" @sizeChange="sizeChange" />
    </div>
    <el-dialog
      :title="dialogTitle"
      :visible.sync="showClassEdit"
      width="40%"
      :close-on-click-modal="false"
      custom-class="my-dialog"
      destroy-on-close
    >
      <ClassEdit
        v-if="showClassEdit"
        :submitting="submitting"
        :current-item="currentItem"
        @addItem="addItem"
        @modItem="modItem"
        @close="showClassEdit = false"
      />
    </el-dialog>
  </div>
</template>

<script>
import ClassEdit from './components/classEdit.vue'
import { getClassList, addClass, modifyClass, deleteClass } from '@/api/class.js'
export default {
  name: 'ClassManagerIndex',
  components: {
    ClassEdit
  },
  data() {
    return {
      page: 1,
      size: 10,
      totalCount: 0,
      tableLoading: false,
      canDelete: false,
      deleteIdList: [],
      tableData: [],
      dialogTitle: '添加班级',
      showClassEdit: false,
      currentItem: {},
      submitting: false
    }
  },
  mounted() {
    this.getList()
    console.log('进入管理的路由', this.$router)
  },
  methods: {
    pageChange(e) {
      this.page = e
      this.getList()
    },
    sizeChange(e) {
      this.page = 1
      this.size = e
      this.getList()
    },
    openClassEdit(e = {}) {
      console.log('传入数据', e)
      e.id ? this.dialogTitle = '编辑班级' : this.dialogTitle = '添加班级'
      this.currentItem = e
      this.showClassEdit = true
    },
    deleteChange() {
      if (!this.canDelete || !this.deleteIdList.length) {
        this.canDelete = !this.canDelete
      } else {
        this.delItem(this.deleteIdList)
      }
    },
    handleSelectionChange(e) {
      console.log('勾选改变', e)
      this.deleteIdList = e.map((item) => {
        return item.id
      })
    },
    getList() {
      this.tableLoading = true
      const params = {
        page: this.page,
        size: this.size
      }
      getClassList(params).then(({ data }) => {
        this.tableData = data.list
        this.totalCount = data.totalCount
        this.tableLoading = false
        this.canDelete = false
      }).catch(() => {
        this.tableLoading = false
      })
    },
    addItem(e) {
      this.submitting = true
      addClass(e).then(() => {
        this.submitting = false
        this.$message.success('班级添加成功')
        this.showClassEdit = false
        this.getList()
      }).catch(() => {
        this.submitting = false
      })
    },
    modItem(e) {
      this.submitting = true
      modifyClass(e).then(() => {
        this.submitting = false
        this.$message.success('班级修改成功')
        this.showClassEdit = false
        this.getList()
      }).catch(() => {
        this.submitting = false
      })
    },
    delItem(e) {
      this.$confirm('该操作将删除此项，是否确认删除？', '提示', {
        type: 'warning',
        showClose: true
      }).then(() => {
        deleteClass({
          idList: e
        }).then(() => {
          this.$message.success('成功删除班级')
          if (this.page > 1 && this.tableData.length === e.length) {
            this.page--
          }
          this.getList()
        })
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.my-page {
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  padding: 0 30px;
  .title-box {
    height: 40px;
    font-size: 16px;
    font-weight: bold;
    line-height: 40px;
    color: #333;
  }
  .btn-box {
    height: 40px;
    margin-bottom: 10px;
    text-align: right;
  }
  .table-box {
    flex: 1;
    position: relative;
    .table-box-main {
      position: absolute;
      width: 100%;
      height: 100%;
      .my-table {
        border: 1px solid #CCC;
        border-radius: 8px;
      }
    }
  }
  .pager-box {
    padding: 10px 0;
  }
  /deep/ .my-dialog {
    border-radius: 6px !important;
    .el-dialog__body {
      padding: 20px 30px;
    }
  }
}
</style>
