<template>
  <div class="main-box">
    <el-form
      class="form-box"
      label-position="left"
      label-width="100px"
    >
      <el-form-item label="班级名称">
        <el-input v-model="formData.className" placeholder="请输入班级名称" autocomplete="off" class="my-input" />
      </el-form-item>
      <el-form-item label="学校名称">
        <el-input v-model="formData.schoolName" placeholder="请输入学校名称" autocomplete="off" class="my-input" />
      </el-form-item>
      <el-form-item label="院系名称">
        <el-input v-model="formData.departmentName" placeholder="请输入院系名称" autocomplete="off" class="my-input" />
      </el-form-item>
      <el-form-item label="辅导员姓名">
        <el-input v-model="formData.counselor" placeholder="请输入辅导员姓名" autocomplete="off" class="my-input" />
      </el-form-item>
      <el-form-item label="辅导员电话">
        <el-input v-model="formData.counselorTelephone" placeholder="请输入辅导员电话" autocomplete="off" class="my-input" />
      </el-form-item>
      <el-form-item label="实训标题">
        <el-input v-model="formData.practiceTitle" placeholder="请输入实训标题" autocomplete="off" class="my-input" />
      </el-form-item>
      <el-form-item label="实训内容">
        <el-input v-model="formData.practiceContent" type="textarea" resize="none" :rows="4" placeholder="请输入实训内容" autocomplete="off" class="my-input" />
      </el-form-item>
    </el-form>
    <div class="btn-box">
      <el-button @click="$emit('close')">取消</el-button>
      <el-button type="primary" :loading="submitting" @click="handleSubmit">确定</el-button>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    currentItem: {
      type: Object,
      default: () => ({})
    },
    submitting: {
      type: Boolean,
      default: () => false
    }
  },
  data() {
    return {
      mode: 'add',
      formData: {}
    }
  },
  watch: {
    currentItem: {
      handler(e) {
        if (e.id) {
          this.mode = 'mod'
          this.formData = {
            id: e.id,
            className: e.className,
            departmentName: e.departmentName,
            schoolName: e.schoolName,
            counselor: e.counselor,
            counselorTelephone: e.counselorTelephone,
            practiceTitle: e.practiceTitle,
            practiceContent: e.practiceContent
          }
        } else {
          this.mode = 'add'
          this.formData = {
            className: '',
            departmentName: '',
            schoolName: '',
            counselor: '',
            counselorTelephone: '',
            practiceTitle: '',
            practiceContent: ''
          }
        }
      },
      deep: true,
      immediate: true
    }
  },
  methods: {
    handleSubmit() {
      if (this.mode === 'add') {
        this.$emit('addItem', this.$copy(this.formData))
      } else {
        this.$emit('modItem', this.$copy(this.formData))
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.main-box {
  .btn-box {
    text-align: right;
  }
}
</style>
