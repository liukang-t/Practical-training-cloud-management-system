<template>
  <div class="main-box">
    <el-form
      class="form-box"
      label-position="left"
      label-width="100px"
    >
      <el-form-item label="存在问题">
        <span v-if="formData.id">{{ formData.problem }}</span>
        <el-input v-else v-model="formData.problem" placeholder="请输入存在问题" autocomplete="off" class="my-input" />
      </el-form-item>
      <el-form-item v-if="formData.id" label="发布人">
        <span>{{ formData.relationStudentName }}</span>
      </el-form-item>
      <el-form-item label="日报内容">
        <span v-if="formData.id">{{ formData.content }}</span>
        <el-input v-else v-model="formData.content" type="textarea" resize="none" :rows="4" placeholder="请输入日报内容" autocomplete="off" class="my-input" />
      </el-form-item>
      <el-form-item v-if="formData.id" label="教师评语">
        <span>{{ formData.comment || '暂无评语' }}</span>
      </el-form-item>
    </el-form>
    <div class="btn-box">
      <el-button @click="$emit('close')">取消</el-button>
      <el-button v-if="((!userInfo.teacherInfo) & (!formData.id))" type="primary" :loading="submitting" @click="handleSubmit">提交日报</el-button>
    </div>
  </div>
</template>
<script>
import { addDailyReport } from '@/api/daily.js'
export default {
  props: {
    currentItem: {
      type: Object,
      default: () => ({})
    }
  },
  data() {
    return {
      formData: {},
      submitting: false
    }
  },
  computed: {
    userInfo() {
      console.log(this.$store.state.user.userInfo)
      return this.$store.state.user.userInfo
    }
  },
  watch: {
    currentItem: {
      handler(e) {
        this.formData = this.$copy(this.currentItem)
      },
      deep: true,
      immediate: true
    }
  },
  mounted() {
  },
  methods: {
    handleSubmit() {
      this.submitting = true
      addDailyReport(this.formData)
        .then(() => {
          this.submitting = false
          this.$message.success('发布日报成功')
          this.$emit('refresh')
          this.$emit('close')
        })
    }
  }
}
</script>
<style lang="scss" scoped>
.main-box {
  .btn-box {
    text-align: right;
  }
}
</style>
