<template>
  <div>
    找不到你的页面404
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
