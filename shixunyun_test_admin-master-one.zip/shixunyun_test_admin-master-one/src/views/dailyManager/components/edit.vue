/* stylelint-disable block-no-empty */
<template>
  <div class="main-box">
    <div class="left-box">
      <div class="table-box">
        <div class="table-box-main">
          <el-table
            v-loading="tableLoading"
            :data="tableData"
            class="my-table"
            border
            stripe
            height="100%"
          >
            <el-table-column
              label="序号"
              width="120"
              align="center"
            >
              <template #default="{$index}">
                <span>{{ (page - 1) * size + $index + 1 }}</span>
              </template>
            </el-table-column>
            <el-table-column
              label="提交时间"
              align="center"
            >
              <template #default="{row}">
                <span class="hidden-one">{{ row.createTime }}</span>
              </template>
            </el-table-column>
            <el-table-column
              label="状态"
              align="center"
            >
              <template #default="{row}">
                <span class="hidden-one">{{ row.comment ? '已评价' : '未评价' }}</span>
              </template>
            </el-table-column>
            <el-table-column
              label="操作"
              align="center"
            >
              <template #default="{row}">
                <el-button type="text" @click="getDetail(row)">选择</el-button>
              </template>
            </el-table-column>
          </el-table>
        </div>
      </div>
      <div class="pager-box">
        <MyPager :page="page" :size="size" :total-count="totalCount" @pageChange="pageChange" @sizeChange="sizeChange" />
      </div>
    </div>
    <div class="right-box">
      <el-form
        class="form-box"
        label-position="left"
        label-width="100px"
      >
        <el-form-item label="存在问题">
          <span v-if="currentItem.id">{{ currentItem.problem }}</span>
        </el-form-item>
        <el-form-item v-if="currentItem.id" label="发布人">
          <span>{{ currentItem.relationStudentName }}</span>
        </el-form-item>
        <el-form-item label="日报内容">
          <span v-if="currentItem.id">{{ currentItem.content }}</span>
        </el-form-item>
        <el-form-item v-if="currentItem.id" label="教师评语">
          <el-input v-model="currentItem.comment" type="textarea" resize="none" :rows="4" placeholder="请输入评论" autocomplete="off" class="my-input" />
        </el-form-item>
      </el-form>
      <div class="btn-box">
        <el-button type="primary" :loading="submitting" @click="handleSubmit()"> 提交评价 </el-button>
      </div>
    </div>
  </div>
</template>
<script>
import { getDailyList, commentDaily } from '@/api/daily.js'
export default {
  props: {
    currentStudent: {
      type: Object,
      default: () => ({})
    }
  },
  data() {
    return {
      page: 1,
      size: 10,
      totalCount: 0,
      tableLoading: false,
      tableData: [],
      showDetail: false,
      currentItem: {},
      submitting: false
    }
  },
  computed: {
    userInfo() {
      console.log(this.$store.state.user.userInfo)
      return this.$store.state.user.userInfo
    }
  },
  mounted() {
    this.getList()
  },
  methods: {
    pageChange(e) {
      this.page = e
      this.getList()
    },
    sizeChange(e) {
      this.page = 1
      this.size = e
      console.log(e)
      this.getList()
    },
    getDetail(row) {
      console.log('传入数据', row)
      this.currentItem = row
    },
    getList() {
      this.tableLoading = true
      const params = {
        page: this.page,
        size: this.size,
        relationStudentId: this.currentStudent.studentId
      }
      console.log('查询到表单数据')
      getDailyList(params).then(({ data }) => {
        this.tableData = data.list
        this.totalCount = data.total
        this.tableLoading = false
        this.canDelete = false
        if (this.tableData.length !== 0) {
          this.currentItem = this.tableData[0]
          this.showDetail = true
        } else {
          this.showDetail = false
        }
      }).catch(() => {
        this.tableLoading = false
      })
    },
    handleSubmit() {
      this.submitting = true
      commentDaily({
        id: this.currentItem.id,
        comment: this.currentItem.comment
      }).then(() => {
        this.submitting = false
        this.$message.success('评论成功')
        this.$emit('refresh')
        this.getList()
      }).catch(() => {
        this.submitting = false
      })
    }
  }
}
</script>
<style lang="scss" scoped>
.main-box {
  display: grid; /* 使用 Grid 布局 */
  grid-template-columns: 1fr 1fr; /* 将行分为两列，每列宽度相等 */
  grid-gap: 10%;
  .left-box {
    .table-box {
      height: 90%;
      .table-box-main {
        height: 100%;
      }
    }
  }
}
.btn-box {
  display: grid;
  place-items: center; /* 这会将子元素水平垂直居中 */
}
</style>
