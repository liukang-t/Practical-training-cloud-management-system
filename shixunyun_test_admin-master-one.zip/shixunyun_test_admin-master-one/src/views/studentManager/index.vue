<template>
  <div class="my-page">
    <div class="title-box">
      学生管理
    </div>
    <div class="btn-box">
      <div class="btn-left">
        <el-select v-model="formData.relationClassId" placeholder="请选择班级" clearable @change="getList">
          <el-option
            v-for="item in classList"
            :key="item.id"
            :label="item.className"
            :value="item.id"
          />
        </el-select>
      </div>
      <div class="btn-right">
        <el-button
          type="danger"
          :plain="!canDelete"
          @click="deleteChange"
        >{{ canDelete ? '删除选中' : '批量删除' }}</el-button>
        <el-button type="primary" @click="openStudentEdit({})">添加学生</el-button>
      </div>
    </div>
    <div class="table-box">
      <div class="table-box-main">
        <el-table
          v-loading="tableLoading"
          :data="tableData"
          class="my-table"
          stripe
          height="100%"
          @selection-change="handleSelectionChange"
        >
          <el-table-column
            v-if="canDelete"
            type="selection"
            width="60"
            align="center"
          />
          <el-table-column
            label="序号"
            width="120"
            align="center"
          >
            <template #default="{$index}">
              <span>{{ (page - 1) * size + $index + 1 }}</span>
            </template>
          </el-table-column>
          <el-table-column
            label="姓名"
            width="100"
            align="center"
          >
            <template #default="{row}">
              <span>{{ row.studentName }}</span>
            </template>
          </el-table-column>
          <el-table-column
            label="学号"
            align="center"
          >
            <template #default="{row}">
              <span>{{ row.studentNumber }}</span>
            </template>
          </el-table-column>
          <el-table-column
            label="性别"
            width="80"
            align="center"
          >
            <template #default="{row}">
              <span>{{ row.gender === 1 ? '男' : '女' }}</span>
            </template>
          </el-table-column>
          <el-table-column
            label="学校"
            align="center"
          >
            <template #default="{row}">
              <span>{{ row.schoolName }}</span>
            </template>
          </el-table-column>
          <el-table-column
            label="院系"
            align="center"
          >
            <template #default="{row}">
              <span>{{ row.departmentName }}</span>
            </template>
          </el-table-column>
          <el-table-column
            label="班级"
            align="center"
          >
            <template #default="{row}">
              <span>{{ row.className }}</span>
            </template>
          </el-table-column>
          <el-table-column
            label="年龄"
            align="center"
          >
            <template #default="{row}">
              <span>{{ row.age }}</span>
            </template>
          </el-table-column>
          <el-table-column
            label="生日"
            align="center"
          >
            <template #default="{row}">
              <span>{{ row.birth }}</span>
            </template>
          </el-table-column>
          <el-table-column
            label="操作"
            align="center"
          >
            <template #default="{row}">
              <el-button type="text" @click="openStudentEdit(row)">编辑</el-button>
              <el-button type="text" @click="delItem([row.id])">删除</el-button>
            </template>
          </el-table-column>
        </el-table>
      </div>
    </div>
    <div class="pager-box">
      <MyPager :page="page" :size="size" :total-count="totalCount" @pageChange="pageChange" @sizeChange="sizeChange" />
    </div>
    <el-dialog
      :title="dialogTitle"
      :visible.sync="showStudentEdit"
      width="40%"
      :close-on-click-modal="false"
      custom-class="my-dialog"
      destroy-on-close
    >
      <StudentEdit
        v-if="showStudentEdit"
        :submitting="submitting"
        :current-item="currentItem"
        :class-list="classList"
        @addItem="addItem"
        @modItem="modItem"
        @close="showStudentEdit = false"
      />
    </el-dialog>
  </div>
</template>

<script>
import StudentEdit from './components/studentEdit.vue'
import { getClassList } from '@/api/class.js'
import { addStudent, getStudentList, modifyStudent, deleteStudent } from '@/api/student.js'

export default {
  name: 'StudentManagerIndex',
  components: {
    StudentEdit
  },
  data() {
    return {
      page: 1,
      size: 10,
      totalCount: 0,
      formData: {
        relationClassId: ''
      },
      classList: [],
      tableLoading: false,
      canDelete: false,
      deleteIdList: [],
      tableData: [],
      dialogTitle: '添加班级',
      showStudentEdit: false,
      currentItem: {},
      submitting: false
    }
  },
  mounted() {
    this.getClassList()
    this.getList()
  },
  methods: {
    pageChange(e) {
      this.page = e
      this.getList()
    },
    sizeChange(e) {
      this.page = 1
      this.size = e
      this.getList()
    },
    openStudentEdit(e = {}) {
      console.log('传入数据', e)
      e.id ? this.dialogTitle = '编辑学生' : this.dialogTitle = '添加学生'
      this.currentItem = e
      this.showStudentEdit = true
    },
    deleteChange() {
      if (!this.canDelete || !this.deleteIdList.length) {
        this.canDelete = !this.canDelete
      } else {
        this.delItem(this.deleteIdList)
      }
    },
    handleSelectionChange(e) {
      this.deleteIdList = e.map((item) => {
        return item.id
      })
    },
    getClassList() {
      getClassList({}).then(({ data }) => {
        this.classList = data.list
        if (this.classList.length !== 0) {
          this.formData.relationClassId = this.classList[0].id
        }
      })
    },
    getList() {
      this.tableLoading = true
      const params = {
        page: this.page,
        size: this.size
      }
      if (this.formData.relationClassId) {
        params.relationClassId = this.formData.relationClassId
      }

      getStudentList(params).then(({ data }) => {
        this.tableData = data.list
        this.totalCount = data.total
        this.tableLoading = false
        this.canDelete = false
      }).catch(() => {
        this.tableLoading = false
      })
    },
    addItem(e) {
      this.submitting = true
      addStudent(e).then(() => {
        this.submitting = false
        this.$message.success('学生添加成功')
        this.showStudentEdit = false
        this.getList()
      }).catch(() => {
        this.submitting = false
      })
    },
    modItem(e) {
      this.submitting = true
      modifyStudent(e).then(() => {
        this.submitting = false
        this.$message.success('班级修改成功')
        this.showStudentEdit = false
        this.getList()
      }).catch(() => {
        this.submitting = false
      })
    },
    delItem(e) {
      this.$confirm('该操作将删除此项，是否确认删除？', '提示', {
        type: 'warning',
        showClose: true
      }).then(() => {
        deleteStudent({
          idList: e
        }).then(() => {
          this.$message.success('成功删除班级')
          if (this.page > 1 && this.tableData.length === e.length) {
            this.page--
          }
          this.getList()
        })
      })
    }
  }
}
</script>

  <style lang="scss" scoped>
  .my-page {
    width: 100%;
    height: 100%;
    display: flex;
    flex-direction: column;
    padding: 0 30px;
    .title-box {
      height: 40px;
      font-size: 16px;
      font-weight: bold;
      line-height: 40px;
      color: #333;
    }
    .btn-box {
      height: 40px;
      margin-bottom: 10px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      .btn-left {
        width: 340px;
      }
    }
    .table-box {
      flex: 1;
      position: relative;
      .table-box-main {
        position: absolute;
        width: 100%;
        height: 100%;
        .my-table {
          border: 1px solid #CCC;
          border-radius: 8px;
        }
      }
    }
    .pager-box {
      padding: 10px 0;
    }
    /deep/ .my-dialog {
      border-radius: 6px !important;
      .el-dialog__body {
        padding: 20px 30px;
      }
    }
  }
  </style>
