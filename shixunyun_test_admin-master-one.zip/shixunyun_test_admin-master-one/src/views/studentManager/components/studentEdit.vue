<template>
  <div class="main-box">
    <el-form
      class="form-box"
      label-position="left"
      label-width="100px"
    >
      <el-form-item label="姓名">
        <el-input v-model="formData.studentName" placeholder="请输入姓名" autocomplete="off" class="my-input" />
      </el-form-item>
      <el-form-item label="学号">
        <el-input v-model="formData.studentNumber" placeholder="请输入学号" autocomplete="off" class="my-input" />
      </el-form-item>
      <el-form-item label="性别">
        <el-select v-model="formData.gender" placeholder="请选择性别" style="width: 100%;">
          <el-option
            v-for="item in genderOptions"
            :key="item.value"
            :label="item.label"
            :value="item.value"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="班级">
        <el-select v-model="formData.relationClassId" placeholder="请选择班级" style="width: 100%;" :disabled="mode === 'mod'">
          <el-option
            v-for="item in classList"
            :key="item.id"
            :label="item.className"
            :value="item.id"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="年龄">
        <el-input v-model="formData.age" placeholder="请输入年龄" autocomplete="off" class="my-input" />
      </el-form-item>
      <el-form-item label="生日">
        <el-date-picker v-model="formData.birth" value-format="yyyy-MM-dd" type="date" placeholder="选择生日日期" style="width: 100%;" />
      </el-form-item>
    </el-form>
    <div class="btn-box">
      <el-button @click="$emit('close')">取消</el-button>
      <el-button type="primary" :loading="submitting" @click="handleSubmit">确定</el-button>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    currentItem: {
      type: Object,
      default: () => ({})
    },
    submitting: {
      type: Boolean,
      default: () => false
    },
    classList: {
      type: Array,
      default: () => ([])
    }
  },
  data() {
    return {
      mode: 'add',
      formData: {},
      genderOptions: [
        { label: '男', value: 1 },
        { label: '女', value: 2 }
      ]
    }
  },
  watch: {
    currentItem: {
      handler(e) {
        if (e.id) {
          this.mode = 'mod'
          this.formData = {
            id: e.id,
            studentName: e.studentName,
            studentNumber: e.studentNumber,
            gender: e.gender,
            relationClassId: e.relationClassId,
            age: e.age,
            birth: e.birth
          }
        } else {
          this.mode = 'add'
          this.formData = {
            studentName: '',
            studentNumber: '',
            gender: '',
            relationClassId: '',
            age: '',
            birth: ''
          }
        }
      },
      deep: true,
      immediate: true
    }
  },
  methods: {
    handleSubmit() {
      if (this.mode === 'add') {
        this.$emit('addItem', this.$copy(this.formData))
      } else {
        this.$emit('modItem', this.$copy(this.formData))
      }
    }
  }
}
</script>

  <style lang="scss" scoped>
  .main-box {
    .btn-box {
      text-align: right;
    }
  }
  </style>

