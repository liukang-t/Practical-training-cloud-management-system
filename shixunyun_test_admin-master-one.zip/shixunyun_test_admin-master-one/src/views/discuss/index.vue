<template>
  <div class="my-page">
    <div class="title-box">
      答疑
    </div>
    <div class="main-box">
      <div class="top-box">
        <div v-if="userInfo.teacherInfo">
          <el-select v-model="relationClassId" placeholder="请选择班级" style="width: 30%; margin-bottom: 20px;" @change="getList">
            <el-option
              v-for="item in classList"
              :key="item.id"
              :label="item.className"
              :value="item.id"
            />
          </el-select>
        </div>
        <div class="top-top">
          <img
            v-if="!$store.state.user.userInfo.userAva"
            src="@/assets/image/default_avatar.jpg"
            class="avatar"
          >
          <el-image
            v-else
            :src="$store.state.user.userInfo.userAva"
            fit="cover"
            class="avatar"
          />
          <!-- <el-input v-model="content" type="textarea" resize="none" :rows="4" placeholder="请输入答疑内容" autocomplete="off" class="my-input" /> -->
          <quill-editor ref="quillEditor" v-model="content" :options="editorOptions" @focus="onEditorMouseEnter" />
        </div>
        <div class="top-bottom">
          <div class="discuss-btn" @click="addDiscuss()">发布</div>
        </div>
      </div>
      <div class="tip">
        答疑列表
      </div>
      <div class="bottom-box">
        <div class="float-box">
          <el-scrollbar class="my-scroll">
            <div class="list-box">
              <div v-for="(item,index) in mainList" :key="index" class="item-box">
                <img
                  v-if="!item.userAvatar"
                  src="@/assets/image/default_avatar.jpg"
                  class="avatar"
                >
                <el-image
                  v-else
                  :src="item.userAvatar"
                  fit="cover"
                  class="avatar"
                />
                <div class="right-box">
                  <div class="name-box">
                    {{ item.createByName }}
                  </div>
                  <div class="content" v-html="item.content" />
                  <div class="bottom-box">
                    <span class="time">{{ item.createTime }}</span>
                    <span v-if="userInfo.id === item.createBy" class="delete-btn" @click="deleteDiscusss({id: item.id, type: 1})">删除</span>
                    <!-- 添加回复按钮 -->
                    <span class="delete-btn" @click="showReplyBox({id:item.id,type:1})">回复</span>
                  </div>

                  <!-- 回复输入框 -->
                  <div v-if="showReplyId === item.id" class="reply-box">
                    <quill-editor :ref="`firstQuillEditor-${item.id}`" v-model="replyContent" :options="editorOptions" />
                    <div class="discuss-btn" @click="submitReply({relationDiscussId: item.id,content:replyContent})">发表</div>
                  </div>
                  <!-- 回复列表 -->
                  <div v-for="(reply) in item.children" :key="`reply-${reply.id}`" class="reply-item">
                    <img
                      v-if="!reply.userAvatar"
                      src="@/assets/image/default_avatar.jpg"
                      class="avatar reply-avatar"
                    >
                    <el-image
                      v-else
                      :src="reply.userAvatar"
                      fit="cover"
                      class="avatar reply-avatar"
                    />
                    <div class="right-box">
                      <div class="name-box">{{ reply.createByName }}</div>
                      <div class="reply-content" v-html="reply.content" />
                      <div v-if="reply.replyId" class="be-reply-box">
                        <div class="be-reply-content">
                          //
                          <span style="color: rgb(18, 179, 179);">@{{ reply.userParentNick }}</span>
                        </div>
                        <div class="be-reply-content" v-html="reply.userParentContent" />
                      </div>
                      <div class="reply-bottom-box">
                        <div class="bottom-box">
                          <span class="time">{{ reply.createTime }}</span>
                          <span v-if="userInfo.id === reply.createBy" class="delete-btn" @click="deleteDiscusss({pid:item.id,id: reply.id, type: 2})">删除</span>
                          <!-- 添加回复按钮 -->
                          <span class="delete-btn" @click="showReplyBox({id:reply.id,type:2})">回复</span>
                        </div>

                        <!-- 回复输入框 -->
                        <div v-if="showReplyCommentId === reply.id" class="reply-box">
                          <quill-editor :ref="`secondQuillEditor-${reply.id}`" v-model="replyContent" :options="editorOptions" />
                          <div class="discuss-btn" @click="submitReply({replyId: reply.id,relationDiscussId: item.id,content:replyContent})">回复</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div v-if="loadStatus === 'loadmore'" class="load-box" @click="getMore">点击加载更多</div>
              <div v-else-if="loadStatus === 'nomore'" class="load-box">没有更多了</div>
              <div v-else class="load-box">加载中</div>
            </div>
          </el-scrollbar>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { addDiscuss, getDiscussList, deleteDiscuss, addDiscussReply } from '@/api/discuss.js'
import settings from '@/settings.js'
import Compressor from 'compressorjs'
import { quillEditor } from 'vue-quill-editor'
import 'quill/dist/quill.core.css'
import 'quill/dist/quill.snow.css'
import 'quill/dist/quill.bubble.css'
import axios from 'axios'
import { getClassList } from '@/api/class.js'
export default {
  name: 'DiscussIndex',
  components: {
    quillEditor
  },
  data() {
    return {
      page: 1,
      size: 10,
      totalCount: 0,
      content: '',
      loadStatus: 'loadmore',
      mainList: [],
      editorOptions: {
        modules: {
          toolbar: [
            ['code-block'], // 代码块按钮
            ['image'] // 图片上传按钮
          ]
        }
      },
      showReplyId: '',
      showReplyCommentId: '',
      replyContent: '',
      uploadPath: settings.uploadPath,
      currentQuillEditor: null, // 用于追踪当前激活的 quill-editor 实例
      relationClassId: null,
      classList: []
    }
  },
  computed: {
    userInfo() {
      console.log(this.$store.state.user.userInfo)
      return this.$store.state.user.userInfo
    }
  },
  // 监听回复框的渲染状态
  watch: {
    'showReplyId'(newVal, oldVal) {
      // 如果 showReplyId 改变，可能有新的 quill-editor 被渲染
      this.$nextTick(() => {
        this.setupEditorForReply({ id: newVal, type: 1 })
      })
    },
    'showReplyCommentId'(newVal, oldVal) {
      // 如果 showReplyCommentId 改变，可能有新的 quill-editor 被渲染
      this.$nextTick(() => {
        this.setupEditorForReply({ id: newVal, type: 2 })
      })
    },
    'relationClassId'(newVal, oldVal) {
      // 下拉框内容发生改变，刷新页面列表
      this.$nextTick(() => { this.getList })
    }
  },
  mounted() {
    // 富文本框图片上传功能实现
    const quill = this.$refs.quillEditor.quill
    const toolbar = quill.getModule('toolbar')
    toolbar.addHandler('image', this.imageHandler)
    // 获取评价列表
    this.getList()
    // 获取班级列表
    this.getClassList()
  },
  methods: {
    onEditorMouseEnter() {
      console.log('鼠标移动到了答疑输入框')
      this.currentQuillEditor = this.$refs.quillEditor
    },
    setupEditorForReply(e) {
      // 假设 replyId 与动态 ref 相关联
      let editorRef = null
      if (e.type === 1) {
        editorRef = `firstQuillEditor-${e.id}`
      } else if (e.type === 2) {
        editorRef = `secondQuillEditor-${e.id}`
      } else {
        return
      }

      this.$nextTick(() => {
        const quillEditorInstance = this.$refs[editorRef]
        if (quillEditorInstance) {
          this.currentQuillEditor = quillEditorInstance[0]
          // 在这里配置 quillEditorInstance
          // 比如：为它设置图片上传处理器
          console.log(this.currentQuillEditor)
          const toolbar = quillEditorInstance[0].quill.getModule('toolbar')
          toolbar.addHandler('image', this.imageHandler)
        }
      })
    },
    imageHandler() {
      const input = document.createElement('input')
      input.setAttribute('type', 'file')
      input.setAttribute('accept', 'image/*')
      input.click()

      input.onchange = async() => {
        const file = input.files[0]
        if (file) {
          await this.uploadImage(file)
        }
      }
    },
    async uploadImage(file) {
      // 创建 FormData 对象并添加文件
      const formData = new FormData()
      const limitFile = await this.changeImg(file)
      console.log(limitFile)
      formData.append('file', limitFile) // 使用 'file' 作为字段名

      try {
        // 上传图片到你的服务器
        const response = await axios.post(this.uploadPath, formData, {
          headers: {
            'Content-Type': 'multipart/form-data'
          }
        })

        // 假设服务器响应中的下载 URL 在 response.data.data 中
        const imageUrl = response.data.data

        // 调用方法将图片 URL 插入到编辑器中
        this.insertToEditor(imageUrl)
      } catch (error) {
        console.error('Error uploading image: ', error)
        // 可以根据需要在这里添加错误处理逻辑，比如显示一个错误消息
      }
    },

    insertToEditor(url) {
      const range = this.currentQuillEditor.quill.getSelection()
      const index = range ? range.index : this.currentQuillEditor.quill.getLength()

      // 创建一个带有固定大小样式的 img 标签
      const imgTag = `<img src="${url}">`

      // 插入这个 img 标签到编辑器中
      this.currentQuillEditor.quill.clipboard.dangerouslyPasteHTML(index, imgTag)
    },
    changeImg(file) {
      return new Promise((resolve, reject) => {
        new Compressor(file, {
          quality: 0.6, // 设置压缩质量
          maxWidth: 100, // 设置图片最大宽度
          maxHeight: 100, // 设置图片最大高度
          success(result) {
            resolve(result)
          },
          error(error) {
            reject(error)
          }
        })
      })
    },
    showReplyBox(e) {
      if (e.type === 1) {
        if (this.showReplyId === e.id) {
          this.showReplyId = ''
        } else {
          this.showReplyId = e.id
        }
      } else {
        if (this.showReplyCommentId === e.id) {
          this.showReplyCommentId = ''
        } else {
          this.showReplyCommentId = e.id
        }
      }
    },
    submitReply(e) {
      if (!e.content) {
        this.$message.error('发布回复内容不能为空')
        return
      }
      addDiscussReply(e).then(() => {
        this.$message.success('回复成功')
        this.replyContent = ''
        this.showReplyId = ''
        this.showReplyCommentId = ''
        this.page = 1
        this.getList()
      })
    },
    addDiscuss() {
      if (!this.content) {
        this.$message.error('发布评论内容不能为空')
        return
      }
      addDiscuss({
        content: this.content,
        relationClassId: this.relationClassId
      }).then(() => {
        this.$message.success('发布成功')
        this.content = ''
        this.page = 1
        this.getList()
      })
    },
    deleteDiscusss(e) {
      this.$alert('是否确认删除此纪录', '提示', {
        type: 'warning',
        showClose: false
      }).then(() => {
        deleteDiscuss(e).then(() => {
          this.$message.success('删除成功')
          if (e.pid) {
            const index = this.mainList.findIndex(item => item.id === e.pid)
            const replyItem = this.mainList[index]
            const childrenList = replyItem.children
            const index2 = childrenList.findIndex(item => item.id === e.id)
            childrenList.splice(index2, 1)
            for (let i = 0; i < childrenList.length; i++) {
              if (childrenList[i].replyId === e.id) {
                childrenList[i].userParentContent = '<p>回复内容已经被删除</p>'
              }
            }
          } else {
            const index = this.mainList.findIndex(item => item.id === e.id)
            this.mainList.splice(index, 1)
          }
        })
      })
    },
    getMore() {
      this.page++
      this.getList()
    },
    getList() {
      this.loadStatus = 'loading'
      const params = {
        page: this.page,
        size: this.size
      }
      if (this.relationClassId) {
        params.relationClassId = this.relationClassId
      }
      getDiscussList(params).then(({ data }) => {
        this.totalCount = data.total
        if (this.page === 1) {
          this.mainList = []
          this.mainList = data.list
        } else {
          this.mainList = [...this.mainList, ...data.list]
        }
        this.mainList.length >= this.totalCount ? this.loadStatus = 'nomore' : this.loadStatus = 'loadmore'
        console.log(this.mainList.length)
        console.log(this.totalCount)
        console.log(this.mainList.length >= this.totalCount)
      })
    },
    getClassList() {
      if (this.$store.state.user.userInfo.teacherInfo) {
        getClassList({}).then(({ data }) => {
          this.classList = data.list
          if (this.classList.length !== 0) {
            this.relationClassId = this.classList[0].id
          }
        })
      } else {
        this.classList = []
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.my-page {
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  padding: 0 30px;
  .title-box {
    height: 40px;
    font-size: 16px;
    font-weight: bold;
    line-height: 40px;
    color: #333;
    margin-bottom: 20px;
  }
  .main-box {
    flex: 1;
    display: flex;
    flex-direction: column;
    width: 690px;
    margin: 0 auto;
    .top-box {
      .top-top {
        display: flex;
        margin-bottom: 10px;
        height: 140px;
        .avatar {
          width: 36px;
          height: 36px;
          border-radius: 50%;
          margin-right: 10px;
        }
        .quill-editor {
          width: 90%;
          height: 72%
        }
      }
      .top-bottom {
        display: flex;
        justify-content: flex-end;
        .discuss-btn {
          width: 72px;
          height: 28px;
          background: #0CC;
          border-radius: 14px;
          font-size: 14px;
          line-height: 28px;
          text-align: center;
          color: #FFF;
          cursor: pointer;
          &:hover {
            opacity: .8;
          }
        }
      }
    }
    .tip {
      font-size: 16px;
      font-weight: bold;
      color: #333;
      margin: 16px 0;
    }
    .bottom-box {
      flex: 1;
      position: relative;
      .float-box {
        position: absolute;
        width: 100%;
        height: 100%;
      }
      .my-scroll {
        height: 100%;
        /deep/ .el-scrollbar__wrap {
          overflow-x: hidden;
        }
        .list-box {
          padding-right: 12px;
          .item-box {
            margin-bottom: 30px;
            display: flex;
            .avatar {
              width: 36px;
              height: 36px;
              border-radius: 50%;
              margin-right: 12px;
            }
            .right-box {
              flex: 1;
              .name-box {
                font-size: 12px;
                font-weight: bold;
                color: #333;
              }
              .content {
                margin: 10px 0;
                font-size: 14px;
                color: #333;
              }
              .bottom-box {
                font-size: 12px;
                color: #999;
                .delete-btn {
                  margin-left: 20px;
                  cursor: pointer;
                }
              }
              .reply-box {
                .quill-editor {
                  margin: 20px
                }
                .discuss-btn {
                  width: 72px;
                  height: 28px;
                  background: #0CC;
                  border-radius: 14px;
                  font-size: 14px;
                  line-height: 28px;
                  text-align: center;
                  color: #FFF;
                  cursor: pointer;
                  &:hover {
                    opacity: .8;
                  }
                }
              }
              .reply-item {
                margin-top: 10px;
                margin-bottom: 10px;
                display: flex;
                .reply-avatar {
                  width: 30px;
                  height: 30px;
                  border-radius: 50%;
                  margin-right: 10px;
                }
                .right-box {
                  flex: 1;
                  .name-box {
                    font-size: 12px;
                    font-weight: bold;
                    color: #333;
                    margin-bottom: 5px;
                  }
                  .reply-content {
                    font-size: 14px;
                    color: #333;
                    margin-bottom: 5px;
                  }
                  .be-reply-box {
                    background-color: #EBF5F5;
                    padding: 10px;
                    border-radius: 6px;
                    .be-reply-content {
                      font-size: 14px;
                      color: #333;
                      margin-bottom: 5px;
                    }
                  }
                  .reply-bottom-box {
                    font-size: 12px;
                    color: #999;
                    // 添加更多关于回复的样式
                    .bottom-box {
                      font-size: 12px;
                      color: #999;
                      .delete-btn {
                        margin-left: 20px;
                        cursor: pointer;
                      }
                    }
                    .reply-box {
                      position: relative;

                      /* 确保 .reply-box 有足够的高度和宽度 */
                      min-height: 140px;
                      .discuss-btn {
                        position: absolute; /* 绝对定位 */
                        bottom: 10px; /* 距离底部的距离 */
                        right: 10px; /* 距离右侧的距离 */
                        width: 72px;
                        height: 28px;
                        background: #0CC;
                        border-radius: 14px;
                        font-size: 14px;
                        line-height: 28px;
                        text-align: center;
                        color: #FFF;
                        cursor: pointer;
                        &:hover {
                          opacity: .8;
                        }
                      }
                    }
                  }
                }
              }
            }
          }
          .load-box {
            text-align: center;
            font-size: 14px;
            color: #333;
            cursor: pointer;
          }
        }
      }
    }
  }
}
</style>
