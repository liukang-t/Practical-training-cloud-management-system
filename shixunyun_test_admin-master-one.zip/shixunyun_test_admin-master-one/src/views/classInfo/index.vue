<template>
  <div class="my-page">
    <el-card class="card-box">
      <div slot="header" class="clearfix">
        <span style="font-weight: bold;">班级信息</span>
      </div>
      <div class="body-box">
        <div class="top-box">
          <div class="info-box"><span>班级:</span> <span>{{ classInfo.className }}</span></div>
          <div class="info-box"><span>学校:</span> <span>{{ classInfo.schoolName }}</span></div>
          <div class="info-box"><span>院系:</span> <span>{{ classInfo.departmentName }}</span></div>
        </div>
        <div class="top-box">
          <div class="info-box"><span>辅导员:</span> <span>{{ classInfo.counselor }}</span></div>
          <div class="info-box"><span>辅导员电话:</span> <span>{{ classInfo.counselorTelephone }}</span></div>
          <div class="info-box"><span>实训标题:</span> <span>{{ classInfo.practiceTitle }}</span></div>
        </div>
        <div class="top-box">
          <div class="info-box"><span>总人数:</span> <span>{{ classInfo.totalCount }}</span></div>
          <div class="info-box"><span>男生人数:</span> <span>{{ classInfo.nanCount }}</span></div>
          <div class="info-box"><span>女生人数:</span> <span>{{ classInfo.nvCount }}</span></div>
        </div>
        <div class="content-box">
          <div class="title-box">实训内容：</div>
          <div class="text-box">{{ classInfo.practiceContent }}</div>
        </div>
      </div>
    </el-card>
  </div>
</template>

<script>
import { getClassInfo } from '@/api/class.js'
export default {
  name: 'ClassInfoIndex',
  data() {
    return {
      classInfo: {}
    }
  },
  mounted() {
    this.getClassInfo()
    console.log('进入正常使用的路由', this.$router)
  },
  methods: {
    getClassInfo() {
      getClassInfo({}).then(({ data }) => {
        this.classInfo = data
      })
    }
  }

}

</script>

<style lang="scss" scoped>
.my-page {
  width: 100%;
  height: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
  .card-box {
    width: 60%;
    min-height: 500px;
    .body-box {
      padding: 0 20px;
      .top-box {
        height: 40px;
        display: flex;
        align-items: center;
        .info-box {
          width: 33%;
          span:first-child {
            font-weight: bold;
            margin-right: 16px;
          }
        }
      }
      .content-box {
        .title-box {
          font-weight: bold;
          height: 40px;
          line-height: 40px;
        }
        .text-box {
          padding: 10px;
          text-indent: 2em;
          line-height: 1.5;
        }
      }
    }
  }
}
</style>
