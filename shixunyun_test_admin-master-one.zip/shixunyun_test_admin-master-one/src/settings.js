// const path = 'http://192.168.43.55:8888'
const path = 'http://localhost:8084'
// const path = 'http://192.168.43.57:8888'
module.exports = {
  target: `${path}`,
  uploadPath: `${path}/file/upload`
}
