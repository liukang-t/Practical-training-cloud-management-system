<template>
  <div id="app">

    <!-- <keep-alive include="News" :include="['home','login']">
    </keep-alive> -->
    <router-view />
  </div>
</template>

<script>
export default {
  name: 'App',
  created() {
    console.log('初始进入的路由', this.$router)
  }
}
</script>

<style lang="scss">
#app {
  width: 100%;
  height: 100%;
}
</style>
