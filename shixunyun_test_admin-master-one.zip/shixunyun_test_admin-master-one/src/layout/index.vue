<template>
  <div class="layout-box">
    <NavBar />
    <SideBar />
    <div :class="['app-big-box',{showSideBar: $store.state.layout.showSideBar}]">
      <AppMain />
    </div>
  </div>
</template>

<script>
import SideBar from './sideBar/index.vue'
import NavBar from './navBar/index.vue'
import AppMain from './appMain/index.vue'
export default {
  name: 'Layout',
  components: {
    SideBar,
    NavBar,
    AppMain
  },
  mounted() {
    // var flag = true
    // setInterval(() => {
    //   flag = !flag
    //   this.$store.dispatch('layout/sidebarControl', flag)
    // }, 2000)
  }
}
</script>

<style lang="scss" scoped>
@import '@/styles/layout.scss';
.layout-box {
  width: 100%;
  height: 100vh;
  .app-big-box {
    width: 100%;
    height: 100%;
    padding-top: $navbarHeight;
    &.showSideBar {
      padding-left: $sidebarWidth;
    }
  }
}
</style>
