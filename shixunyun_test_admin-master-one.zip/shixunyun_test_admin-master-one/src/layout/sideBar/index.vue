<template>
  <div v-if="$store.state.layout.showSideBar" class="sidebar">
    <div class="logo-box">
      <img src="@/assets/icons/logo.png" alt="">
      <span>实训云</span>
    </div>
    <el-scrollbar class="my-scrollbar">
      <div class="menu-box">
        <el-menu
          :default-active="activePath"
          class="el-menu-vertical-demo"
          background-color="#5C6666"
          text-color="#fff"
          active-text-color="#12B3B3"
        >
          <el-menu-item v-for="(item,index) in menuModel" :key="index" :index="item.path" @click="goToPage(item)">{{ item.children[0].meta.title }}</el-menu-item>
        </el-menu>
      </div>
    </el-scrollbar>
  </div>
</template>

<script>
export default {
  name: 'SideBar',
  data() {
    return {
    }
  },
  computed: {
    menuModel() {
      return this.$store.state.user.menuModel
    },
    activePath() {
      return '/' + this.$route.path.split('/')[1]
    }
  },
  methods: {
    goToPage(item) {
      // fix:修复原地跳转的报错 NavigationDuplicated 23/11/28
      console.log(this.$router.currentRoute.path)
      console.log(item.path)
      if (!this.$router.currentRoute.path.includes(item.path)) {
        this.$jumpPage(item.path)
      }
    }
  }
}
</script>

<style lang="scss" scoped>
@import '@/styles/layout.scss';
.sidebar {
  position: fixed;
  left: 0;
  top: 0;
  width: $sidebarWidth;
  height: 100vh;
  background-color: #5C6666;
  .logo-box {
    width: $sidebarWidth;
    height: $navbarHeight;
    display: flex;
    justify-content: center;
    align-items: center;
    background-color: #5C6666;
    img {
      width: 42px;
      height: 28px;
      margin: 12px;
    }
    span {
      color: #FFF;
      font-size: 20px;
      line-height: 28px;
      font-weight: bold;
    }
  }
  .my-scrollbar {
    width: 100%;
    height: calc(100% - #{$navbarHeight});
    /deep/ .el-scrollbar__wrap {
      overflow-x: hidden;
    }
    .menu-box {
      padding: 0 2px;
    }
  }
}
</style>
