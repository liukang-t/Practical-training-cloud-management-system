<template>
  <div class="appMain">
    <router-view />
  </div>
</template>

<script>
export default {
  name: 'AppMain'
}
</script>

<style lang="scss" scoped>
.appMain {
  width: 100%;
  height: 100%;
  background-color: #FFF;
}
</style>
