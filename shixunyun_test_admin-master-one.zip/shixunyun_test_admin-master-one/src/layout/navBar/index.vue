<template>
  <div :class="['navbar',{showSideBar: $store.state.layout.showSideBar}]">
    <div v-if="!$store.state.layout.showSideBar" class="logo-box">
      <img src="@/assets/icons/logo.png" alt="">
      <span>实训云</span>
    </div>
    <div class="nav-main">
      <div class="left-box">
        <span v-if="$store.state.user.userInfo.teacherInfo" class="role-box">『 教师端 』</span>
        <span v-else class="role-box">『 学生端 』</span>
        <div class="select-box" @click="goSelect">
          <span>{{ $store.state.user.selectClassName }}</span>
          <i class="el-icon-refresh" />
        </div>
      </div>
      <div class="menu-box">
        <el-dropdown>
          <div class="el-dropdown-link user-box">
            <img
              v-if="!$store.state.user.userInfo.userAva"
              src="@/assets/image/default_avatar.jpg"
              class="avatar"
            >
            <el-image
              v-else
              :src="$store.state.user.userInfo.userAva"
              fit="cover"
              class="avatar"
            />
            <span>
              {{ $store.state.user.userInfo.user_nick }}<i class="el-icon-caret-bottom el-icon--right" />
            </span>
          </div>
          <el-dropdown-menu slot="dropdown">
            <el-dropdown-item icon="el-icon-picture-outline-round" @click.native="openAvatarEdit">修改头像</el-dropdown-item>
            <el-dropdown-item icon="el-icon-user" @click.native="openUserInfoEdit">修改个人资料</el-dropdown-item>
            <el-dropdown-item icon="el-icon-lock" @click.native="openPasswordEdit">修改密码</el-dropdown-item>
            <el-dropdown-item icon="el-icon-setting" divided @click.native="logout">退出</el-dropdown-item>
          </el-dropdown-menu>
        </el-dropdown>
      </div>
    </div>
    <el-dialog
      title="修改密码"
      :visible.sync="showPasswordEdit"
      width="40%"
      append-to-body
      :close-on-click-modal="false"
      custom-class="my-dialog"
      destroy-on-close
    >
      <PasswordEdit @close="showPasswordEdit = false" />
    </el-dialog>
    <el-dialog
      title="修改头像"
      :visible.sync="showAvatarEdit"
      width="40%"
      append-to-body
      :close-on-click-modal="false"
      custom-class="my-dialog"
      destroy-on-close
    >
      <AvatarEdit @close="showAvatarEdit = false" />
    </el-dialog>
    <el-dialog
      title="修改个人资料"
      :visible.sync="showUserInfoEdit"
      width="40%"
      append-to-body
      :close-on-click-modal="false"
      custom-class="my-dialog"
      destroy-on-close
    >
      <UserInfoEdit v-if="showUserInfoEdit" @close="showUserInfoEdit = false" />
    </el-dialog>
  </div>
</template>

<script>
import AvatarEdit from './components/avatarEdit.vue'
import PasswordEdit from './components/passwordEdit.vue'
import UserInfoEdit from './components/userInfoEdit.vue'
export default {
  name: 'NavBar',
  components: {
    PasswordEdit,
    AvatarEdit,
    UserInfoEdit
  },
  data() {
    return {
      showPasswordEdit: false,
      showAvatarEdit: false,
      showUserInfoEdit: false
    }
  },
  methods: {
    logout() {
      this.$store.dispatch('user/logout').then(() => {
        location.reload()
      })
    },
    openAvatarEdit() {
      this.showAvatarEdit = true
    },
    openPasswordEdit() {
      this.showPasswordEdit = true
    },
    openUserInfoEdit() {
      this.showUserInfoEdit = true
    },
    goSelect() {
      console.log(124554545)
      if (this.$route.path === '/selectClass/index') {
        console.log(1111111122223333)
        return
      }
      this.$jumpPage('/selectClass/index')
    }
  }
}
</script>

<style lang="scss" scoped>
@import '@/styles/layout.scss';
.navbar {
  position: fixed;
  top: 0;
  right: 0;
  width: 100%;
  height: $navbarHeight;
  background-color: #12B3B3;
  display: flex;
  justify-items: center;
  &.showSideBar {
    width: calc(100% - #{$sidebarWidth});
  }
  .logo-box {
    width: $sidebarWidth;
    height: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
    background-color: #5C6666;
    img {
      width: 42px;
      height: 28px;
      margin: 12px;
    }
    span {
      color: #FFF;
      font-size: 20px;
      line-height: 28px;
      font-weight: bold;
    }
  }
  .nav-main {
    flex: 1;
    height: 100%;
    padding: 0 90px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    .left-box {
      display: flex;
      align-items: center;
      .role-box {
        font-size: 18px;
        font-weight: bold;
        color: #FFF;
      }
      .select-box {
        cursor: pointer;
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-left: 60px;
        padding: 0 30px;
        width: 520px;
        height: 32px;
        background: #008080;
        border-radius: 4px;
        color: #FFF;
        font-size: 16px;
        i {
          font-size: 18px;
        }
      }
    }
    .menu-box {
      .user-box {
        cursor: pointer;
        display: flex;
        align-items: center;
        .avatar {
          width: 36px;
          height: 36px;
          border-radius: 50%;
          margin-right: 8px;
        }
        span {
          font-size: 14px;
          color: #FFF;
          i {
            margin-left: 6px;
          }
        }
      }
    }
  }
}
/deep/ .my-dialog {
  border-radius: 6px !important;
  .el-dialog__body {
    padding: 20px 30px;
  }
}
</style>
