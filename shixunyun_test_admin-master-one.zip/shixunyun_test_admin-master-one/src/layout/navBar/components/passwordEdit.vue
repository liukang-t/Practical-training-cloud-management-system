<template>
  <div class="main-box">
    <el-form
      ref="changePasswordForm"
      :model="changePasswordForm"
      :rules="changePasswordRules"
      class="form-box"
      label-position="left"
      label-width="80px"
    >
      <el-form-item label="原密码" prop="oldPassword">
        <el-input v-model="changePasswordForm.oldPassword" size="small" placeholder="请输原密码" prefix-icon="el-icon-user" autocomplete="off" class="my-input" />
      </el-form-item>
      <el-form-item label="新密码" prop="newPassword">
        <el-input v-model="changePasswordForm.newPassword" size="small" placeholder="请输入新密码" prefix-icon="el-icon-lock" show-password autocomplete="off" class="my-input" />
      </el-form-item>
      <el-form-item label="确认密码" prop="confirmPassword">
        <el-input v-model="changePasswordForm.confirmPassword" size="small" placeholder="请确认新密码" prefix-icon="el-icon-lock" show-password autocomplete="off" class="my-input" />
      </el-form-item>
    </el-form>
    <div class="btn-box">
      <el-button size="small" @click="$emit('close')">取消</el-button>
      <el-button type="primary" size="small" :loading="submitting" @click="handleSubmit">确定</el-button>
    </div>
  </div>
</template>

<script>
import { changePassword } from '@/api/user.js'
export default {
  data() {
    const validateConfirmPassword = (rule, value, callback) => {
      if (this.changePasswordForm.newPassword !== value) {
        callback(new Error('确认密码与新密码不相同'))
      } else {
        callback()
      }
    }
    return {
      changePasswordForm: {
        newPassword: '',
        oldPassword: '',
        confirmPassword: ''
      },
      changePasswordRules: {
        oldPassword: [
          { required: true, message: '密码不能为空', trigger: 'blur' },
          { pattern: /^.{6,20}$/, message: '密码必须由6-20位组成', trigger: 'blur' }
        ],
        newPassword: [
          { required: true, message: '密码不能为空', trigger: 'blur' },
          { pattern: /^.{6,20}$/, message: '密码必须由6-20位组成', trigger: 'blur' }
        ],
        confirmPassword: [
          { required: true, message: '确认密码不能为空', trigger: 'blur' },
          { validator: validateConfirmPassword, trigger: 'blur' }
        ]
      },
      submitting: false
    }
  },
  methods: {
    handleSubmit() {
      this.$refs.changePasswordForm.validate((flag) => {
        if (flag) {
          this.submitting = true
          const formData = {
            oldPassword: this.changePasswordForm.oldPassword,
            newPassword: this.changePasswordForm.newPassword
          }
          changePassword(formData).then(() => {
            this.submitting = false
            this.$emit('close')
            this.$message.success('修改密码成功')
            this.$store.dispatch('user/resetToken')
            this.$alert('您已成功修改密码，请重新登录', '提示', {
              showClose: false
            }).then(() => {
              this.$emit('close')
              location.reload()
            })
          }).catch(() => {
            this.submitting = false
          })
        }
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.main-box {
  .btn-box {
    text-align: right;
  }
}
</style>
