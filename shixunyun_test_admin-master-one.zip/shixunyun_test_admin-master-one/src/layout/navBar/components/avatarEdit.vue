<template>
  <div class="main-box">
    <div class="row-box">
      <div class="label-box">头像</div>
      <div class="value-box">
        <!-- :on-preview="handlePreview"
        :on-remove="handleRemove"
        :file-list="fileList"
        :on-exceed="handleExceed"
        :before-remove="beforeRemove" -->
        <el-upload
          class="my-upload"
          :action="action"
          name="file"
          :headers="{
            token: $store.state.user.token
          }"
          :show-file-list="false"
          accept=".jpg,.png,.gif,.jpeg"
          :before-upload="beforeUpload"
          :on-success="handleSuccess"
          :on-error="handleError"
        >
          <div class="upload-image-box">
            <el-image v-if="formData.avatar" :src="formData.avatar" class="image-box" fit="cover" />
            <i v-if="formData.avatar" class="el-icon-delete icons-a" @click.stop="closeImage" />
            <i v-else class="el-icon-plus icons-b" />
          </div>
        </el-upload>
      </div>
    </div>
    <div class="btn-box">
      <el-button @click="$emit('close')">取消</el-button>
      <el-button type="primary" :loading="submitting" @click="handleSubmit">确定</el-button>
    </div>
  </div>
</template>

<script>
import settings from '@/settings.js'
import { changeAvatar } from '@/api/user.js'
export default {
  data() {
    return {
      formData: {
        avatar: ''
      },
      submitting: false,
      action: settings.uploadPath
    }
  },
  methods: {
    beforeUpload(file) {
      const suffixList = ['jpg', 'jpeg', 'png', 'gif']
      const suffix = file.name.slice(file.name.lastIndexOf('.') + 1)
      console.log('suffix', suffix)
      if (suffixList.indexOf(suffix) === -1) {
        this.$message.error('图片格式不正确，请重新上传')
        return false
      }
      if (file.size >= 20 * 1024 * 1024) {
        this.$message.error('图片过大，请压缩后上传')
        return false
      }
      return true
    },
    handleSuccess({ code, data }, file) {
      if (code === 200) {
        this.$message.success('头像上传成功')
        this.formData.avatar = data
      } else if (code === 401 || code === 403) {
        this.$message.error('身份认证过期请重新登录')
        this.$store.dispatch('user/resetToken')
        location.reload()
      } else {
        this.$message.error('图片上传失败')
      }
    },
    handleError() {
      this.$message.error('图片上传失败')
    },
    closeImage() {
      this.formData.avatar = ''
    },
    handleSubmit() {
      if (!this.formData.avatar) {
        this.$message.error('请确认上传头像后在提交')
      } else {
        const formData = this.$copy(this.formData)
        changeAvatar(formData).then(() => {
          this.$store.dispatch('user/getUserInfo').then(() => {
            this.$emit('close')
            this.$message.success('头像修改成功')
          })
        })
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.main-box {
  .row-box {
    display: flex;
    align-items: center;
    .label-box {
      width: 100px;
      text-align: right;
      font-size: 16px;
      margin-right: 20px;
    }
    .value-box {
      .upload-image-box {
        width: 120px;
        height: 120px;
        border: 1px dashed #CCC;
        border-radius: 50%;
        display: flex;
        justify-content: center;
        align-items: center;
        overflow: hidden;
        position: relative;
        .image-box {
          width: 100%;
          height: 100%;
        }
        .icons-b {
          font-size: 20px;
          //   color: pink;
        }
        .icons-a {
          position: absolute;
          width: 100%;
          height: 100%;
          top: 0;
          left: 0;
          display: flex;
          justify-content: center;
          align-items: center;
          font-size: 20px;
          background-color: rgba(0, 0, 0, .3);
          opacity: 0;
          transition: all .3s;
          &:hover {
            opacity: 1;
          }
        }
      }
    }
  }
  .btn-box {
    margin-top: 20px;
    text-align: right;
  }
}
</style>
