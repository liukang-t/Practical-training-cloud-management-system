<template>
  <div class="main-box">
    <el-form
      class="form-box"
      label-position="left"
      label-width="80px"
    >
      <el-form-item label="姓名">
        <el-input v-model="formData.nick" placeholder="请输入姓名" autocomplete="off" class="my-input" />
      </el-form-item>
      <el-form-item label="性别">
        <el-select v-model="formData.gender" style="width: 100%;" placeholder="请选择性别">
          <el-option
            v-for="genderItem in genderOptions"
            :key="genderItem.value"
            :label="genderItem.label"
            :value="genderItem.value"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="手机号">
        <el-input v-model="formData.userPhone" placeholder="请输入手机号" autocomplete="off" class="my-input" />
      </el-form-item>
      <el-form-item label="邮箱">
        <el-input v-model="formData.userEmail" placeholder="请输入邮箱" autocomplete="off" class="my-input" />
      </el-form-item>
    </el-form>
    <div class="btn-box">
      <el-button @click="$emit('close')">取消</el-button>
      <el-button type="primary" :loading="submitting" @click="handleSubmit">确定</el-button>
    </div>
  </div>
</template>

<script>
import { changeUserInfo } from '@/api/user.js'
export default {
  data() {
    return {
      formData: {},
      genderOptions: [
        {
          label: '男',
          value: 1
        },
        {
          label: '女',
          value: 2
        }
      ],
      submitting: false
    }
  },
  computed: {
    userInfo() {
      console.log(this.$store.state.user.userInfo)
      return this.$store.state.user.userInfo
    }
  },
  mounted() {
    this.formData = {
      nick: this.userInfo.nick || '',
      gender: this.userInfo.studentInfo !== null ? this.userInfo.studentInfo.gender : this.userInfo.teacherInfo.gender,
      userPhone: this.userInfo.userPhone || '',
      userEmail: this.userInfo.userEmail || ''
    }
  },
  methods: {
    handleSubmit() {
      if (!this.formData.nick) {
        this.$message.error('姓名不能为空')
        return
      }
      if (this.formData.gender !== 2 && this.formData.gender !== 1) {
        this.$message.error('性别不能为空')
        return
      }
      this.submitting = true
      const formData = this.$copy(this.formData)
      changeUserInfo(formData).then(() => {
        this.submitting = false
        this.$message.success('个人资料修改成功')
        this.$store.dispatch('user/getUserInfo')
        this.$emit('close')
      }).catch(() => {
        this.submitting = false
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.main-box {
  .btn-box {
    text-align: right;
  }
}
</style>
