import VueRouter from 'vue-router'
import Vue from 'vue'

import Layout from '@/layout/index.vue'


Vue.use(VueRouter)

// 基础路由

export const baseRoutes = [
  {
    path: '/',
    redirect: '/login'
  },
  {
    path: '/login',
    name: 'Login',
    meta: { title: '登录' },
    component: () => import('@/views/login/index.vue')
  },
  {
    path: '/404',
    component: () => import('@/views/404/index.vue')
  }
]

export const managerRoutes = [
  {
    path: '/classManager',
    component: Layout,
    redirect: '/classManager/index',
    children: [{
      path: 'index',
      name: 'ClassManagerIndex',
      meta: { title: '班级管理' },
      component: () => import('@/views/classManager/index.vue')
    }]
  },
  {
    path: '/studentManager',
    component: Layout,
    redirect: '/studentManager/index',
    children: [{
      path: 'index',
      name: 'StudentManagerIndex',
      meta: { title: '学生管理' },
      component: () => import('@/views/studentManager/index.vue')
    }]
  },
  {
    path: '/resourceManager',
    component: Layout,
    redirect: '/resourceManager/index',
    children: [{
      path: 'index',
      name: 'ResourceManagerIndex',
      meta: { title: '资源管理' },
      component: () => import('@/views/resourceManager/index.vue')
    }]
  },
  {
    path: '/dailyManager',
    component: Layout,
    redirect: '/dailyManager/index',
    children: [{
      path: 'index',
      name: 'DailyManagerIndex',
      meta: { title: '日报管理' },
      component: () => import('@/views/dailyManager/index.vue')
    }]
  },
  {
    path: '/taskManager',
    component: Layout,
    redirect: '/taskManager/index',
    children: [{
      path: 'index',
      name: 'TaskManagerIndex',
      meta: { title: '任务管理' },
      component: () => import('@/views/taskManager/index.vue')
    }, {
      path: 'detail',
      name: 'TaskManagerDetail',
      meta: { title: '任务管理' },
      component: () => import('@/views/taskManager/detaile.vue')
    }]
  },
  {
    path: '/discuss',
    component: Layout,
    redirect: '/discuss/index',
    children: [{
      path: 'index',
      name: 'DiscussIndex',
      meta: { title: '答疑' },
      component: () => import('@/views/discuss/index.vue')
    }]
  },
  {
    path: '/videoManager',
    component: Layout,
    redirect: '/videoManager/index',
    children: [{
      path: 'index',
      name: 'VideoManagerIndex',
      meta: { title: '视频管理' },
      component: () => import('@/views/videoManager/index.vue')
    }, {
      path: 'videoList',
      name: 'VideoList',
      meta: { title: '视频管理' },
      component: () => import('@/views/videoManager/videoList.vue')
    }]
  }
]

export const mainRoutes = [
  {
    path: '/classInfo',
    component: Layout,
    redirect: '/classInfo/index',
    children: [{
      path: 'index',
      name: 'ClassInfoIndex',
      meta: { title: '班级信息' },
      component: () => import('@/views/classInfo/index.vue')
    }]
  },
  {
    path: '/resourceManager',
    component: Layout,
    redirect: '/resourceManager/index',
    children: [{
      path: 'index',
      name: 'ResourceManagerIndex',
      meta: { title: '资源管理' },
      component: () => import('@/views/resourceManager/index.vue')
    }]
  },
  {
    path: '/dailyManager',
    component: Layout,
    redirect: '/dailyManager/index',
    children: [{
      path: 'index',
      name: 'DailyManagerIndex',
      meta: { title: '日报管理' },
      component: () => import('@/views/student/dailyManager/index.vue')
    }]
  },
  {
    path: '/taskManager',
    component: Layout,
    redirect: '/taskManager/index',
    children: [{
      path: 'index',
      name: 'TaskManagerIndex',
      meta: { title: '任务管理' },
      component: () => import('@/views/taskManager/index.vue')
    }, {
      path: 'detail',
      name: 'TaskManagerDetail',
      meta: { title: '任务管理' },
      component: () => import('@/views/taskManager/detaile.vue')
    }]
  },
  {
    path: '/discuss',
    component: Layout,
    redirect: '/discuss/index',
    children: [{
      path: 'index',
      name: 'DiscussIndex',
      meta: { title: '答疑' },
      component: () => import('@/views/discuss/index.vue')
    }]
  },
  {
    path: '/videoManager',
    component: Layout,
    redirect: '/videoManager/index',
    children: [{
      path: 'index',
      name: 'VideoManagerIndex',
      meta: { title: '视频管理' },
      component: () => import('@/views/student/videoManager/index.vue')
    }]
  }
]

function createRouter() {
  return new VueRouter({
    scrollBehavior: () => ({ y: 0 }),
    routes: baseRoutes
  })
}
const router = createRouter()


export function resetRouter() {
  const newRouter = createRouter()
  // 替换路由规则
  router.matcher = newRouter.matcher
}


export default router
