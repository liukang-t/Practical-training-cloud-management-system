import { login, getUserInfo, logout } from '@/api/user'
import router, { managerRoutes, mainRoutes, resetRouter } from '@/router'
var state = {
  token: localStorage.getItem('token') || '',
  userInfo: {},
  selectClassId: -1, // -1 游客 0 管理  其他 教师查看对应班级
  selectClassName: '',
  permission: 'base',
  menuModel: []
}

var actions = {
  login({ commit }, params) {
    return new Promise((resolve, reject) => {
      console.log('登录参数', params)
      login(params).then(({ data }) => {
        commit('SET_TOKEN', data.token)
        localStorage.setItem('token', data.token)
        resolve()
      }).catch((err) => {
        reject(err)
      })
    })
  },
  getUserInfo({ dispatch, commit }) {
    return new Promise((resolve, reject) => {
      getUserInfo({}).then(({ data }) => {
        console.log('个人信息', data)
        commit('SET_USERINFO', data)
        // commit('SET_SELECTCLASSID', data.selectClassId)
        // commit('SET_SELECTCLASSNAME', data.selectClassName)
        dispatch('generateRouter')
        resolve()
      }).catch((err) => {
        reject(err)
      })
    })
  },
  resetToken({ dispatch, commit }) {
    commit('SET_TOKEN', '')
    localStorage.removeItem('token')
    commit('SET_SELECTCLASSID', -1)
    dispatch('generateRouter')
  },
  logout({ dispatch, commit }) {
    return new Promise((resolve, reject) => {
      logout({}).then((res) => {
        dispatch('resetToken')
        resolve()
      }).catch(() => {
        reject()
      })
    })
  },
  generateRouter({ state, commit }) {
    console.log('动态路由')
    if (state.userInfo === null) {
      resetRouter()
      commit('SET_PERMISSION', 'base')
      commit('SET_MENUMODEL', [])
      console.log('触发了初始路由')
    } else if (state.userInfo.userType === 1) {
      resetRouter()
      router.addRoutes(managerRoutes.concat({
        path: '*',
        redirect: '/404'
      }))
      commit('SET_PERMISSION', 'manager')
      commit('SET_MENUMODEL', managerRoutes)
      console.log('触发了管理路路由')
    } else if (state.userInfo.userType === 2) {
      resetRouter()
      router.addRoutes(mainRoutes.concat({
        path: '*',
        redirect: '/404'
      }))
      commit('SET_PERMISSION', 'main')
      commit('SET_MENUMODEL', mainRoutes)
      console.log('触发了主路由')
      console.log('路由信息', router)
    }
  }
}

var mutations = {
  SET_TOKEN(state, params) {
    state.token = params
  },
  SET_USERINFO(state, params) {
    state.userInfo = params
  },
  SET_SELECTCLASSID(state, params) {
    state.selectClassId = params
  },
  SET_SELECTCLASSNAME(state, params) {
    state.selectClassName = params
  },
  SET_PERMISSION(state, params) {
    state.permission = params
  },
  SET_MENUMODEL(state, params) {
    state.menuModel = params
  }
}

var getters = {

}

export default {
  namespaced: true,
  state,
  actions,
  mutations,
  getters
}


