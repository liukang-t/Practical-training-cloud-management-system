var state = {
  showSideBar: true
}

var actions = {
  sidebarControl({ commit }, params) {
    commit('SET_SHOWSIDEBAR', params)
  }
}

var mutations = {
  SET_SHOWSIDEBAR(state, params) {
    state.showSideBar = params
  }
}


export default {
  namespaced: true,
  state,
  actions,
  mutations
}


