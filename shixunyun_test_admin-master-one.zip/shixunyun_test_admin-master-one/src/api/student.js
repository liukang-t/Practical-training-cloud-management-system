import request from '@/utils/request'

// 添加学生
export function addStudent(data) {
  return request({
    url: '/studentInfo/addStudent',
    method: 'post',
    data
  })
}

// 获取学生列表
export function getStudentList(data) {
  return request({
    url: '/studentInfo/getStudentList',
    method: 'get',
    data
  })
}

// 编辑学生信息
export function modifyStudent(data) {
  return request({
    url: '/studentInfo/modifyStudent',
    method: 'post',
    data
  })
}

// 删除学生
export function deleteStudent(data) {
  return request({
    url: '/studentInfo/deleteStudent',
    method: 'post',
    data
  })
}
