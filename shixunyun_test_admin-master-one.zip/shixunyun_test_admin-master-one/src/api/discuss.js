import request from '@/utils/request'

// 发布讨论
export function addDiscuss(data) {
  return request({
    url: '/discussInfo/addDiscuss',
    method: 'post',
    data
  })
}

// 发布回复
export function addDiscussReply(data) {
  return request({
    url: '/discussComment/addDiscussComment',
    method: 'post',
    data
  })
}

// 获取评论列表
export function getDiscussList(data) {
  return request({
    url: '/discussInfo/getDiscussList',
    method: 'get',
    data
  })
}

// 删除评论
export function deleteDiscuss(data) {
  return request({
    url: '/discussInfo/deleteDiscuss',
    method: 'post',
    data
  })
}

