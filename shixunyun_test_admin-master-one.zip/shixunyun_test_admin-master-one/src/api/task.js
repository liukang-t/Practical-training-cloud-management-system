import request from '@/utils/request'

// 添加任务
export function addTask(data) {
  return request({
    url: '/taskInfo/addTask',
    method: 'post',
    data
  })
}

// 获取任务列表
export function getTaskList(data) {
  return request({
    url: '/taskInfo/getTaskList',
    method: 'get',
    data
  })
}

// 修改任务
export function modifyTask(data) {
  return request({
    url: '/taskInfo/modifyTask',
    method: 'post',
    data
  })
}

// 删除任务
export function deleteTask(data) {
  return request({
    url: '/taskInfo/deleteTask',
    method: 'post',
    data
  })
}

// 获取任务详情
export function getTaskDetail(data) {
  return request({
    url: '/taskInfo/getTaskDetail',
    method: 'get',
    data
  })
}

// 获取任务评分列表
export function getTaskScoreList(data) {
  return request({
    url: '/taskGrade/getTaskScoreList',
    method: 'get',
    data
  })
}

// 修改任务评分
export function modifyTaskScore(data) {
  return request({
    url: '/taskGrade/modifyTaskScore',
    method: 'post',
    data
  })
}
