import request from '@/utils/request'

// 添加资源
export function addResource(data) {
  return request({
    url: '/resourceInfo/addResource',
    method: 'post',
    data
  })
}

// 获取资源列表
export function getResourceList(data) {
  return request({
    url: '/resourceInfo/getResourceList',
    method: 'get',
    data
  })
}

// 编辑资源
export function modifyResource(data) {
  return request({
    url: '/resourceInfo/modifyResource',
    method: 'post',
    data
  })
}


// 删除资源
export function deleteResource(data) {
  return request({
    url: '/resourceInfo/deleteResource',
    method: 'post',
    data
  })
}






