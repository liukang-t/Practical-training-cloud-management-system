import request from '@/utils/request'

// 获取日报列表
export function getDailyList(data) {
  return request({
    url: '/dailyReport/getDailyReportList',
    method: 'get',
    data
  })
}

// 学生日报列表
export function getStudentDailyList(data) {
  return request({
    url: '/dailyReport/getStudentDailyList',
    method: 'get',
    data
  })
}

// 评论日报
export function commentDaily(data) {
  return request({
    url: '/dailyReport/commentOnDailyReport',
    method: 'post',
    data
  })
}

// 添加日报
export function addDailyReport(data) {
  return request({
    url: '/dailyReport/addDailyReport',
    method: 'post',
    data
  })
}
