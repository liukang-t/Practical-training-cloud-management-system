import request from '@/utils/request'

// 视频列表
export function getVideoList(data) {
  return request({
    url: '/videoInfo/getVideoList',
    method: 'get',
    data
  })
}

// 学生视频列表
export function getStudentVideoList(data) {
  return request({
    url: '/videoInfo/getStudentVideoList',
    method: 'get',
    data
  })
}

// 上传视频
export function addVideoInfo(data) {
  return request({
    url: '/videoInfo/addVideoInfo',
    method: 'post',
    data })
}

// 删除视频
export function deleteVideoInfo(data) {
  return request({
    url: '/videoInfo/deleteVideoInfo',
    method: 'post',
    data })
}
