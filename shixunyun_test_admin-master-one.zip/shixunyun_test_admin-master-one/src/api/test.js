import request from '@/utils/request'

export function testGet(data) {
  return request({
    url: '/api/testGet',
    method: 'get',
    data
  })
}
