import request from '@/utils/request'

// 注册
export function register(data) {
  return request({
    url: '/userInfo/register',
    method: 'post',
    data
  })
}

// 登录
export function login(data) {
  return request({
    url: '/userInfo/login',
    method: 'post',
    data
  })
}

// 获取个人信息
export function getUserInfo(data) {
  return request({
    url: '/userInfo/getUserByToken',
    method: 'get',
    data
  })
}

// 退出登录
export function logout(data) {
  return request({
    url: '/userInfo/logout',
    method: 'post',
    data
  })
}

// 修改密码
export function changePassword(data) {
  return request({
    url: '/userInfo/changePassword',
    method: 'post',
    data
  })
}

// 修改头像
export function changeAvatar(data) {
  return request({
    url: '/userInfo/changeAvatar',
    method: 'post',
    data
  })
}

// 修改个人资料
export function changeTeacherInfo(data) {
  return request({
    url: '/teacherInfo/changeTeacherInfo',
    method: 'post',
    data
  })
}

export function changeUserInfo(data) {
  return request({
    url: '/userInfo/changeUserInfo',
    method: 'post',
    data
  })
}
