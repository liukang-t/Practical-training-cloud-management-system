import request from '@/utils/request'

// 选择班级
export function selectClass(data) {
  return request({
    url: '/classInfo/selectClass',
    method: 'post',
    data
  })
}

// 获取班级列表
export function getClassList(data) {
  return request({
    url: '/classInfo/getClassList',
    method: 'get',
    data
  })
}

// 添加班级
export function addClass(data) {
  return request({
    url: '/classInfo/add',
    method: 'post',
    data
  })
}

// 修改班级
export function modifyClass(data) {
  return request({
    url: '/classInfo/modify',
    method: 'post',
    data
  })
}

// 删除班级
export function deleteClass(data) {
  return request({
    url: '/classInfo/deleted',
    method: 'post',
    data
  })
}

// 获取班级详情
export function getClassInfo(data) {
  return request({
    url: '/classInfo/getClassInfo',
    method: 'get',
    data
  })
}
