import router from '@/router/index.js'

export function copy(obj) {
  console.log('copy调用了')
  return JSON.parse(JSON.stringify(obj))
}

export function add(a, b) {
  console.log('add调用了')
  return a + b
}

export function jumpPage(data) {
  if (typeof (data) === 'string') {
    router.push({
      path: data
    })
  } else if (typeof (data) === 'number') {
    router.go(data)
  } else {
    router.push(data)
  }
}


export function parseTime(time, format = '{y}-{m}-{d} {h}:{i}') {
  let date
  if (time instanceof Date) {
    date = time
  } else {
    if (time) {
      date = new Date(time)
    } else {
      date = new Date()
    }
  }
  const formatObj = {
    y: date.getFullYear(),
    m: date.getMonth() + 1,
    d: date.getDate(),
    h: date.getHours(),
    i: date.getMinutes(),
    s: date.getSeconds(),
    a: date.getDay()
  }
  const timeStr = format.replace(/{(y|m|d|h|i|s|a)+}/g, (result, key) => {
    let value = formatObj[key]
    if (key === 'a') { return ['日', '一', '二', '三', '四', '五', '六'][value] }
    if (result.length > 0 && value < 10) {
      value = '0' + value
    }
    return value || 0
  })
  return timeStr
}

// // 下载文件
// export function downloadFile(url, fileName) {
//   fetch(url, { mode: 'no-cors' }).then((res) => {
//     res.blob().then((blob) => {
//       const blobUrl = window.URL.createObjectURL(blob)
//       // 这里的文件名根据实际情况从响应头或者url里获取
//       const file_name = fileName || new Date().getTime()
//       const a = document.createElement('a')
//       a.href = blobUrl
//       a.download = file_name
//       a.click()
//       window.URL.revokeObjectURL(blobUrl)
//       a.remove()
//     })
//   })
// }

// 下载文件
// export function downloadFile(url, fileName) {
//   fetch(url).then(response => {
//     const contentDisposition = response.headers.get('Content-disposition')
//     console.log(response)
//     console.log(contentDisposition)
//     let fileName
//     if (contentDisposition && contentDisposition.indexOf('attachment') !== -1) {
//       const fileNameRegex = /filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/
//       const matches = fileNameRegex.exec(contentDisposition)
//       if (matches != null && matches[1]) {
//         fileName = matches[1].replace(/['"]/g, '')
//       }
//     }
//     return response.blob().then(blob => ({ blob, fileName }))
//   }).then(({ blob, fileName }) => {
//     const url = window.URL.createObjectURL(new Blob([blob]))
//     const link = document.createElement('a')
//     link.href = url
//     link.setAttribute('download', fileName) // 使用从响应头中获取的文件名
//     document.body.appendChild(link)
//     link.click()
//   })
// }

export function downloadFile(url, fileName) {
  window.location.href = url
}
