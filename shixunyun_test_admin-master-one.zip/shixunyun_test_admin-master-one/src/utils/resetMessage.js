import { Message } from 'element-ui'

let instances = null

var resetMessage = function(option) {
  if (instances) {
    instances.close()
  }
  instances = Message(option)
  return instances
}
const typeArr = ['error', 'success', 'info', 'warning']
typeArr.forEach(type => {
  resetMessage[type] = (options) => {
    if (typeof options === 'string') {
      options = {
        message: options
      }
    }
    options.type = type
    return resetMessage(options)
  }
})

export default resetMessage
