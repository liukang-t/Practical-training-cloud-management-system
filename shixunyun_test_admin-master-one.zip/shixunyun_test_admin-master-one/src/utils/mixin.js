import store from '@/store/index.js'

export default {
  computed: {
    userInfo() {
      return store.state.cka.userInfo
    }
  }
}
