import settings from '@/settings'
import axios from 'axios'
import { MessageBox } from 'element-ui'
import Message from '@/utils/resetMessage.js'
import store from '@/store/index.js'
// 配置传输cookies
axios.defaults.withCredentials = true

var service = axios.create({
  baseURL: settings.target,
  timeout: 30000
})


service.interceptors.request.use((config) => {
  config.headers['token'] = store.state.user.token
  return config
})

service.interceptors.response.use((res) => {
  const data = res.data
  if (data.code !== 200) {
    if (data.code === 401 || data.code === 403) {
      store.dispatch('user/resetToken')
      MessageBox.alert('身份认证以过期', '提示', {
        type: 'warning',
        showClose: false
      }).then(() => {
        location.reload()
      })
    } else {
      Message.error({ message: data.msg })
    }
    return Promise.reject(data.msg)
  } else {
    return data
  }
}, (err) => {
  Message.error({ message: err.message })
})

export default function request(data) {
  if (data.method.toLowerCase() === 'get') {
    data.params = data.data
    delete data.data
  }
  return service(data)
}

