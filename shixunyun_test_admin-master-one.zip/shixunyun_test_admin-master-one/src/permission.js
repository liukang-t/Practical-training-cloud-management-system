import router from '@/router/index.js'
import store from '@/store/index.js'
import NProgress from 'nprogress'
import 'nprogress/nprogress.css'


router.beforeEach((to, from, next) => {
  NProgress.start()
  const witeList = ['/login']
  const token = store.state.user.token
  if (token) {
    if (!store.state.user.userInfo.id) {
      if (to.path === '/' || to.path === '/login') {
        next()
      } else {
        store.dispatch('user/getUserInfo').then(() => {
          next({ ...to, replace: true })
        })
      }
    } else {
      if (to.path === '/login') {
        if (from.path === '/selectClass/index') {
          NProgress.done()
        }
        next('/selectClass/index')
      } else {
        next()
      }
    }
  } else {
    if (witeList.indexOf(to.path) !== -1) {
      next()
    } else {
      next('/login')
    }
  }
})

router.afterEach((to, from) => {
  NProgress.done()
  document.title = to.meta.title || '实训云'
})
