<template>
  <div class="outer-box">
    <el-pagination
      :layout="layout"
      :page-size="size"
      :total="totalCount"
      :current-page="page"
      :page-sizes="sizes"
      :pager-count="pagerCount"
      background
      @current-change="pageChange"
      @size-change="sizeChange"
    />
  </div>
</template>

<script>
export default {
  props: {
    page: {
      type: Number,
      default: 1
    },
    size: {
      type: Number,
      default: 20
    },
    totalCount: {
      type: Number,
      default: 0
    },
    sizes: {
      type: Array,
      default: () => ([5, 10, 15, 20])
    },
    pagerCount: {
      type: Number,
      default: 5
    },
    pageHeight: {
      type: String,
      default: '60px'
    },
    layout: {
      type: String,
      default: 'sizes, prev, pager, next, jumper'
    }
  },
  methods: {
    pageChange(e) {
      this.$emit('pageChange', e)
    },
    sizeChange(e) {
      this.$emit('sizeChange', e)
    }
  }
}
</script>

<style lang="scss" scoped>
.outer-box {
  text-align: right;
}
</style>
