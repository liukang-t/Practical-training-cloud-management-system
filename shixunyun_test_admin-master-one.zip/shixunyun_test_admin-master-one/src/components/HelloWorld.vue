<template>
  <div>
    <div class="box-2">
      我是2号组件
      <div>
        <div>aaa:{{ $store.state.cka.aaa }}</div>
        <div>bbb:{{ $store.state.ckb.bbb }}</div>
        <div
          style="width: 50px; height: 50px; background-color: green;"
          @click="add(2)"
        >aaa+2</div>
        <div
          style="width: 50px; height: 50px; background-color: green;"
          @click="addB(2)"
        >bbb+2</div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'HelloWorld',
  methods: {
    add(params) {
      this.$store.dispatch('cka/aaaAdd', params)
    },
    addB(params) {
      this.$store.dispatch('ckb/bbbAdd', params)
    }
  }
}
</script>


<style scoped>
.box-2 {
  width: 500px;
  height: 500px;
  background-color: skyblue;
}
</style>
