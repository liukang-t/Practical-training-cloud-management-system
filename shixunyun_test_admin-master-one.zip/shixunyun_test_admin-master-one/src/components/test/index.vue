<template>
  <div>
    <div class="box-1">
      我是1号组件
      <div>
        <div>aaa:{{ $store.state.cka.aaa }}</div>
        <div>bbb:{{ $store.state.ckb.bbb }}</div>
        <!-- <div>bigAaa: {{ $store.getters.bigAaa }}</div> -->
        <div
          style="width: 50px; height: 50px; background-color: green;"
          @click="add(1)"
        >+1</div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Test',
  methods: {
    add(params) {
      this.$store.dispatch('aaaAdd', params)
    }
  }
}
</script>

<style>
.box-1 {
  width: 500px;
  height: 500px;
  background-color: pink;
}
</style>
